import SwiftUI
import Combine

@MainActor
final class BackgroundManager: ObservableObject {
    static let shared = BackgroundManager()

    @Published var customImage: UIImage? = nil
    @AppStorage("customBackgroundURL") var customURL: String = ""

    private let fileName = "custom_background_v1.jpg"

    private init() {
        loadLocalCache()
    }

    func updateBackground(with urlString: String) async {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        customURL = clean

        if clean.isEmpty {
            clearBackground()
            return
        }

        guard let url = URL(string: clean) else {
            // FIX: notify user about invalid URL instead of silently ignoring
            ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let image = UIImage(data: data) {
                customImage = image
                saveToDisk(data: data)
            } else {
                ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
            }
        } catch {
            // FIX: show error to user (was silent empty catch)
            ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
        }
    }

    func clearBackground() {
        customURL = ""
        customImage = nil
        if let fileURL = getFileURL() {
            try? FileManager.default.removeItem(at: fileURL)
        }
    }

    private func loadLocalCache() {
        guard !customURL.isEmpty else { return }
        if let fileURL = getFileURL(),
           let data = try? Data(contentsOf: fileURL),
           let image = UIImage(data: data) {
            customImage = image
        } else {
            Task { await updateBackground(with: customURL) }
        }
    }

    private func saveToDisk(data: Data) {
        guard let fileURL = getFileURL() else { return }
        try? data.write(to: fileURL)
    }

    private func getFileURL() -> URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            .first?.appendingPathComponent(fileName)
    }
}
