import SwiftUI

struct ArchiveView: View {
    let channel: Channel
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var epgManager: EPGManager
    @Environment(\.dismiss) var dismiss
    
    @StateObject private var lm = LanguageManager.shared

    @State private var selectedDate: Date = Date()
    @State private var cachedProgramsByDay: [Date: [EPGProgram]] = [:]
    @FocusState private var focusedArea: FocusArea?

    enum FocusArea: Hashable {
        case dates
        case programs
    }

    private var normalizedToday: Date {
        Calendar.current.startOfDay(for: Date())
    }

    var dates: [Date] {
        var days: [Date] = []
        let cal = Calendar.current
        let daysCount = max(1, Int(channel.catchupDays ?? "5") ?? 5)

        for i in 0..<daysCount {
            if let date = cal.date(byAdding: .day, value: -i, to: normalizedToday) {
                days.append(date)
            }
        }
        return days
    }

    var currentPrograms: [EPGProgram] {
        let key = Calendar.current.startOfDay(for: selectedDate)
        return cachedProgramsByDay[key] ?? []
    }

    var body: some View {
        ZStack {
            Color.black.opacity(0.6)
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
                .onTapGesture { dismiss() }

            HStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 20) {
                    Text(lm.strings.metaArchive)
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.leading, 30)
                        .padding(.top, 40)

                    List(dates, id: \.self) { date in
                        Button {
                            selectedDate = date
                        } label: {
                            ArchiveDateRow(
                                date: date,
                                isSelected: Calendar.current.isDate(date, inSameDayAs: selectedDate)
                            )
                        }
                        .buttonStyle(.glass)
                        .listRowInsets(EdgeInsets(top: 0, leading: 12, bottom: 0, trailing: 12))
                        .focused($focusedArea, equals: .dates)
                    }
                    .listStyle(.plain)
                    .environment(\.defaultMinListRowHeight, 32)
                }
                .frame(width: 400)
                .background(Color.black.opacity(0.2))

                VStack(alignment: .leading) {
                    Text(formatFullDate(selectedDate))
                        .font(.system(size: 32, weight: .medium))
                        .foregroundColor(.white.opacity(0.7))
                        .padding(.top, 40)
                        .padding(.bottom, 20)
                        .padding(.leading, 20)

                    if currentPrograms.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "archivebox")
                                .font(.system(size: 60))
                                .foregroundColor(.white.opacity(0.3))
                            
                            Text(lm.strings.archiveEmptyDay)
                                .font(.title3)
                                .foregroundColor(.white.opacity(0.5))
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        List(currentPrograms) { program in
                            Button {
                                if let url = ArchiveURLBuilder.build(channel: channel, program: program) {
                                    // ИСПРАВЛЕНИЕ: передаём channel для корректной передачи заголовков (User-Agent, Referer)
                                    playerManager.loadArchive(
                                        url: url,
                                        title: program.title,
                                        description: program.desc,
                                        channel: channel
                                    )
                                    dismiss()
                                }
                            } label: {
                                ArchiveProgramRow(program: program)
                            }
                            .buttonStyle(.glass)
                            .listRowInsets(EdgeInsets(top: 0, leading: 12, bottom: 0, trailing: 12))
                            .focused($focusedArea, equals: .programs)
                            .id(program.id)
                        }
                        .listStyle(.plain)
                        .environment(\.defaultMinListRowHeight, 32)
                    }
                }
                .frame(maxWidth: .infinity)
            }
        }
        .onAppear {
            if let first = dates.first {
                selectedDate = first
            }
            rebuildProgramsCache()
        }
        .onChange(of: channel.id) { _, _ in
            rebuildProgramsCache()
        }
        .onExitCommand {
            dismiss()
        }
    }

    private func rebuildProgramsCache() {
        let allPrograms = epgManager.getPrograms(for: channel)
        let cal = Calendar.current
        let now = Date()

        var bucket: [Date: [EPGProgram]] = [:]
        for prog in allPrograms where prog.start < now {
            let key = cal.startOfDay(for: prog.start)
            bucket[key, default: []].append(prog)
        }

        for key in bucket.keys {
            bucket[key]?.sort { $0.start > $1.start }
        }

        cachedProgramsByDay = bucket
    }

    private func formatFullDate(_ date: Date) -> String {
        let df = DateFormatter()
        df.locale = Locale.current
        df.dateFormat = "d MMMM, EEEE"
        return df.string(from: date).capitalized
    }
}

struct ArchiveDateRow: View {
    let date: Date
    let isSelected: Bool
    
    private var dateString: String {
        let df = DateFormatter()
        df.locale = Locale.current
        df.dateFormat = "d MMMM"
        return df.string(from: date)
    }
    
    var body: some View {
        HStack(spacing: 20) {
            Image(systemName: "chevron.right")
                .font(.caption)
                .opacity(isSelected ? 1 : 0)
            
            Text(dateString)
                .font(.system(size: 24, weight: isSelected ? .bold : .medium))
            
            Spacer()
        }
    }
}

struct ArchiveProgramRow: View {
    let program: EPGProgram
    @Environment(\.isFocused) var isFocused
    
    private var timeString: String {
        let df = DateFormatter()
        df.dateFormat = "HH:mm"
        return df.string(from: program.start)
    }
    
    var body: some View {
        HStack(spacing: 20) {
            Image(systemName: "play")
                .font(.system(size: 26))
                .foregroundColor(.black)
                .opacity(isFocused ? 1 : 0)
            
            Text(timeString)
                .font(.system(size: 26, weight: .bold, design: .monospaced))
                .foregroundColor(isFocused ? .black : .white.opacity(0.8))
                .frame(width: 90, alignment: .leading)
            
            Text(program.title)
                .font(.system(size: 26, weight: .medium))
                .lineLimit(1)
                .foregroundColor(isFocused ? .black : .white)
            
            Spacer()
        }
    }
}
