import SwiftUI

@main
struct ECHO_TV_PLUSApp: App {
    @StateObject private var memoryHandler = MemoryPressureHandler.shared
    
    @Environment(\.scenePhase) private var scenePhase
    
    var body: some Scene {
        WindowGroup {
            MainTabView()
                .withGlobalErrorBanner()
        }
        .onChange(of: scenePhase) { oldPhase, newPhase in
            handleScenePhaseChange(newPhase)
        }
    }
    
    private func handleScenePhaseChange(_ phase: ScenePhase) {
        switch phase {
        case .background:
            break
        case .inactive:
            break
        case .active:
            break
        @unknown default:
            break
        }
    }
}
