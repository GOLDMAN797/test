import SwiftUI
import Combine

struct MainTabView: View {
    @StateObject private var playlistManager = PlaylistManager()
    @StateObject private var playerManager = PlayerManager()
    @StateObject private var favoritesManager = FavoritesManager()
    @StateObject private var lm = LanguageManager.shared
    @StateObject private var localServerStore = LocalServerStore()
    @StateObject private var bgManager = BackgroundManager.shared

    @State private var selectedTab = 0
    @State private var playlistsViewID = UUID()
    @State private var searchViewID = UUID()

    @State private var isManualRefreshing = false
    @State private var refreshStartedAt: Date?

    var body: some View {
        ZStack(alignment: .topTrailing) {
            backgroundView

            TabView(selection: $selectedTab) {
                NavigationView {
                    PlaylistsView(
                        playlistManager: playlistManager,
                        playerManager: playerManager,
                        favoritesManager: favoritesManager
                    )
                    .id(playlistsViewID)
                }
                .tabItem { Label(lm.strings.tabPlaylists, systemImage: "list.and.film") }
                .tag(0)

                NavigationView {
                    SettingsView(
                        playlistManager: playlistManager,
                        onRefreshAll: {
                            playlistManager.refreshAllPlaylists()
                            searchViewID = UUID()
                        }
                    )
                }
                .tabItem { Label(lm.strings.tabSettings, systemImage: "gear") }
                .tag(1)
                .onExitCommand {
                    selectedTab = 0
                }

                NavigationView {
                    LocalServersView()
                        .environmentObject(localServerStore)
                }
                .tabItem { Label(lm.strings.tabLocal, systemImage: "externaldrive") }
                .tag(2)

                NavigationView {
                    SearchView(
                        playlistManager: playlistManager,
                        playerManager: playerManager,
                        favoritesManager: favoritesManager
                    )
                    .id(searchViewID)
                }
                .tabItem { Image(systemName: "magnifyingglass") }
                .tag(3)
                .onExitCommand {
                    selectedTab = 0
                }

                Color.clear
                    .tabItem { Image(systemName: "arrow.clockwise") }
                    .tag(4)
            }
            .onChange(of: selectedTab) { _, newTab in
                guard newTab == 4 else { return }

                selectedTab = 0
                isManualRefreshing = true
                refreshStartedAt = Date()

                if playlistManager.playlists.isEmpty {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        isManualRefreshing = false
                        refreshStartedAt = nil
                    }
                    return
                }

                playlistManager.refreshAllPlaylists()
                searchViewID = UUID()
            }
            .onChange(of: playlistManager.isLoading) { oldValue, newValue in
                if oldValue && !newValue {
                    playlistsViewID = UUID()
                    isManualRefreshing = false
                    refreshStartedAt = nil
                }
            }
            .disabled(playerManager.showPlayer)

            if (playlistManager.isLoading || isManualRefreshing) && !playerManager.showPlayer {
                ZStack {
                    Rectangle()
                        .fill(.regularMaterial)
                        .ignoresSafeArea()

                    VStack(spacing: 16) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(1.2)

                        Text(lm.strings.loading)
                            .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                    }
                }
                .zIndex(10)
            }

            if !playerManager.showPlayer {
                DigitalClockView()
                    .padding(.trailing, 50)
                    .padding(.top, 5)
                    .zIndex(1)

                logoView
            }
        }
        .environmentObject(playlistManager.epgManager)
        .fullScreenCover(isPresented: $playerManager.showPlayer) {
            NavigationStack {
                PlayerView(
                    playerManager: playerManager,
                    epgManager: playlistManager.epgManager,
                    favoritesManager: favoritesManager
                )
                .navigationBarHidden(true)
            }
        }
    }

    private var backgroundView: some View {
        ZStack {
            GeometryReader { proxy in
                if let customImage = bgManager.customImage {
                    Image(uiImage: customImage)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .overlay(Color.black.opacity(0.4))
                        .transition(.opacity.animation(.easeInOut))
                } else {
                    Image("DefaultBackground")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .overlay(Color.black.opacity(0.4))
                        .transition(.opacity.animation(.easeInOut))
                }
            }
            .ignoresSafeArea()

            RadialGradient(
                colors: [Color.white.opacity(0.05), Color.clear],
                center: .center,
                startRadius: 0,
                endRadius: 900
            )
            .ignoresSafeArea()
        }
    }

    private var logoView: some View {
        VStack {
            HStack {
                Text(lm.strings.appTitle)
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.leading, 50)
                    .padding(.top, 5)
                Spacer()
            }
            Spacer()
        }
        .allowsHitTesting(false)
        .zIndex(1)
    }
}
