import SwiftUI

struct LocalFolderView: View {
    @EnvironmentObject private var servers: LocalServerStore
    @ObservedObject private var lm = LanguageManager.shared
    @ObservedObject private var historyService = LocalPlaybackHistoryService.shared

    let serverId: UUID
    let path: String
    let title: String

    @State private var items: [LocalLibraryItem] = []
    @State private var isLoading = false
    @State private var errorText: String?

    @State private var pendingItem: LocalLibraryItem?
    @State private var resumeStartSeconds: Double?
    @State private var showResumePrompt = false
    @State private var playbackRequest: LocalPlaybackRequest?
    @State private var movieInfoChannel: Channel?

    private static let movieColumns = [GridItem(.adaptive(minimum: 250), spacing: 50)]
    private static let folderColumns = [GridItem(.adaptive(minimum: 250), spacing: 50)]

    private var server: LocalServer? {
        servers.servers.first(where: { $0.id == serverId })
    }

    var body: some View {
        ZStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 55) {
                    foldersSection
                    filesSection
                }
                .padding(.top, 40)
                .padding(.bottom, 80)
            }
            .onAppear { Task { await load() } }
            .alert(lm.strings.alertPlaybackTitle, isPresented: $showResumePrompt) {
                Button(lm.strings.btnResume + " \(formatTime(resumeStartSeconds ?? 0))") {
                    startPlayback(startAt: resumeStartSeconds)
                }
                Button(lm.strings.btnStartOver) { startPlayback(startAt: nil) }
                Button(lm.strings.cancel, role: .cancel) { clearPending() }
            } message: {
                Text(lm.strings.alertResumeMessage)
            }
            .sheet(item: $movieInfoChannel) { channel in
                MovieInfoSheet(channel: channel)
            }
            .fullScreenCover(item: $playbackRequest) { req in
                LocalPlayerScreen(request: req)
            }

            if isLoading {
                ZStack {
                    Rectangle().fill(.regularMaterial).ignoresSafeArea()
                    VStack(spacing: 16) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(1.2)
                        Text(lm.strings.loading)
                            .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                    }
                }
                .zIndex(10)
            }

            if let errorText {
                VStack {
                    Spacer()
                    Text(errorText)
                        .foregroundColor(.red.opacity(0.9))
                        .font(.system(size: 22, weight: .medium))
                        .padding(.bottom, 40)
                }
                .allowsHitTesting(false)
            }
        }
    }

    private var foldersSection: some View {
        let folders = items.filter { $0.isDirectory }
        return Group {
            if !folders.isEmpty {
                LazyVGrid(columns: Self.folderColumns, spacing: 50) {
                    ForEach(folders) { item in
                        NavigationLink(
                            destination: LocalFolderView(
                                serverId: serverId,
                                path: item.path,
                                title: item.displayTitle
                            ).environmentObject(servers)
                        ) {
                            LocalFolderCard(title: item.displayTitle)
                        }
                        .buttonStyle(.glass)
                    }
                }
                .padding(.horizontal, 80)
            }
        }
    }

    private var filesSection: some View {
        let files = items.filter { !$0.isDirectory }
        return Group {
            if !files.isEmpty {
                LazyVGrid(columns: Self.movieColumns, spacing: 70) {
                    ForEach(files) { item in
                        Button { handleTap(item) } label: {
                            LocalMoviePosterCard(title: item.displayTitle)
                        }
                        .buttonStyle(.card)
                        .contextMenu {
                            Text(item.displayTitle)
                                .font(.system(size: 20, weight: .semibold))
                            Divider()
                            Button {
                                movieInfoChannel = Channel(
                                    name: item.displayTitle, url: item.path, group: "Movie"
                                )
                            } label: {
                                Label(lm.strings.actionInfoMovie, systemImage: "info.circle")
                            }
                            Button {
                                startDirectPlayback(item: item, startAt: nil)
                            } label: {
                                Label(lm.strings.btnStartOver, systemImage: "play.fill")
                            }
                            Divider()
                            Button(role: .destructive) {
                                if let s = server {
                                    historyService.remove(mediaId: makeMediaId(serverId: s.id, share: s.share, item: item))
                                }
                            } label: {
                                Label(lm.strings.ctxRemoveWatchLater, systemImage: "clock.badge.xmark")
                            }
                        }
                    }
                }
                .padding(.horizontal, 80)
            }
        }
    }

    private func load() async {
        guard !isLoading else { return }
        guard let server else {
            await MainActor.run { errorText = lm.strings.localNoServers }
            return
        }
        guard let password = LocalKeychainStore.shared.getPassword(for: server.id) else {
            await MainActor.run { errorText = lm.strings.localErrorMissingCredentials }
            return
        }
        await MainActor.run { isLoading = true; errorText = nil }
        do {
            let cfg = LocalSMBConnectionConfig(host: server.host, share: server.share,
                                               username: server.username, password: password)
            let client = LocalSMBClient(config: cfg)
            try await client.connect()
            let list = try await client.list(path: path)
            await MainActor.run { items = list; isLoading = false }
        } catch {
            await MainActor.run { isLoading = false; errorText = lm.strings.localErrorLoadFailed }
        }
    }

    private func handleTap(_ item: LocalLibraryItem) {
        pendingItem = item; resumeStartSeconds = nil
        guard let server else { return }
        let mediaId = makeMediaId(serverId: server.id, share: server.share, item: item)
        if let saved = historyService.getItem(for: mediaId), saved.time > 10 {
            resumeStartSeconds = saved.time
            showResumePrompt = true
            return
        }
        startPlayback(startAt: nil)
    }

    private func startPlayback(startAt: Double?) {
        guard let item = pendingItem else { return }
        startDirectPlayback(item: item, startAt: startAt)
        clearPending()
    }

    private func startDirectPlayback(item: LocalLibraryItem, startAt: Double?) {
        guard let server else { return }
        guard let password = LocalKeychainStore.shared.getPassword(for: server.id) else { return }
        let mediaId = makeMediaId(serverId: server.id, share: server.share, item: item)
        guard let url = LocalSMBURLBuilder.build(host: server.host, share: server.share,
                                                  username: server.username, password: password,
                                                  path: item.path) else { return }
        playbackRequest = LocalPlaybackRequest(id: mediaId, serverId: server.id, path: item.path,
                                               name: item.displayTitle, smbURL: url,
                                               startAtSeconds: startAt)
    }

    private func playHistory(entry: LocalSavedPlayback, resume: Bool) {
        guard let server, server.id == entry.serverId else { return }
        guard let password = LocalKeychainStore.shared.getPassword(for: server.id) else { return }
        guard let url = LocalSMBURLBuilder.build(host: server.host, share: server.share,
                                                  username: server.username, password: password,
                                                  path: entry.path) else { return }
        playbackRequest = LocalPlaybackRequest(id: entry.id, serverId: entry.serverId,
                                               path: entry.path,
                                               name: LocalTitleCleaner.clean(entry.name),
                                               smbURL: url,
                                               startAtSeconds: resume ? entry.time : nil)
    }

    private func makeMediaId(serverId: UUID, share: String, item: LocalLibraryItem) -> String {
        LocalPlaybackHistoryService.makeMediaId(serverId: serverId, path: item.path, share: share)
    }

    private func clearPending() { pendingItem = nil; resumeStartSeconds = nil }

    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "0:00" }
        let s = Int(seconds.rounded(.down))
        let h = s / 3600; let m = (s % 3600) / 60; let sec = s % 60
        if h > 0 { return "\(h):" + String(format: "%02d:%02d", m, sec) }
        return "\(m):" + String(format: "%02d", sec)
    }
}
