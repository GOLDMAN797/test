import SwiftUI
import UIKit

struct LocalVLCPlayerView: UIViewRepresentable {
    @ObservedObject var controller: LocalVLCPlayerController

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .black
        controller.attachDrawable(view)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}

    static func dismantleUIView(_ uiView: UIView, coordinator: ()) {}
}
