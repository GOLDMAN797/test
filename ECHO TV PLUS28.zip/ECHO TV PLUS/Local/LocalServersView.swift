import SwiftUI

struct LocalServersView: View {
    @EnvironmentObject private var store: LocalServerStore
    @ObservedObject private var lm = LanguageManager.shared

    @State private var showConnectSheet = false
    @State private var serverToEdit: LocalServer?
    @State private var serverToDelete: LocalServer?

    @State private var showCleanupDialog = false

    private static let titleFontSize: CGFloat = 22
    private static let columns = [
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40)
    ]

    var body: some View {
        ZStack {
            ScrollView {
                VStack(spacing: 55) {
                    topButtons

                    if !store.servers.isEmpty {
                        LazyVGrid(columns: Self.columns, spacing: 60) {
                            ForEach(store.servers) { server in
                                NavigationLink(
                                    destination: LocalLibraryView(serverId: server.id)
                                        .environmentObject(store)
                                ) {
                                    LocalServerCard(server: server)
                                }
                                .buttonStyle(.card)
                                .contextMenu {
                                    Button { serverToEdit = server } label: {
                                        Label(lm.strings.btnEdit, systemImage: "pencil")
                                    }
                                    Button(role: .destructive) { serverToDelete = server } label: {
                                        Label(lm.strings.btnDelete, systemImage: "trash")
                                    }
                                }
                                .task {
                                    if server.status == .unknown {
                                        _ = try? await store.checkStatus(serverId: server.id)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 80)
                        .padding(.top, 20)
                        .padding(.bottom, 80)
                    } else {
                        emptyState
                    }
                }
            }

            if store.isBusy {
                ZStack {
                    Rectangle()
                        .fill(.regularMaterial)
                        .ignoresSafeArea()

                    VStack(spacing: 16) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(1.2)

                        Text(lm.strings.loading)
                            .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                    }
                }
                .zIndex(10)
            }
        }
        .fullScreenCover(isPresented: $showConnectSheet) {
            LocalConnectServerSheet(mode: .add)
                .environmentObject(store)
        }
        .fullScreenCover(item: $serverToEdit) { server in
            LocalConnectServerSheet(mode: .edit(server))
                .environmentObject(store)
        }
        .alert(item: $serverToDelete) { server in
            Alert(
                title: Text(lm.strings.localDeleteServerTitle),
                message: Text("\(lm.strings.localDeleteServerMessage) '\(server.share)'?"),
                primaryButton: .destructive(Text(lm.strings.deleteConfirm)) {
                    store.deleteServer(id: server.id)
                },
                secondaryButton: .cancel(Text(lm.strings.cancel))
            )
        }
    }

    private var topButtons: some View {
        HStack(spacing: 70) {
            Button(action: { showConnectSheet = true }) {
                HStack(spacing: 12) {
                    Image(systemName: "externaldrive.fill.badge.plus")
                        .font(.system(size: 38))
                    Text(lm.strings.localConnectBtn)
                        .font(.system(size: Self.titleFontSize, weight: .semibold))
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .buttonStyle(.glass)
            .frame(height: 70)

            NavigationLink(
                destination: LocalHistoryView()
                    .environmentObject(store)
            ) {
                HStack(spacing: 12) {
                    Image(systemName: "clock")
                        .font(.system(size: 38))
                    Text(lm.strings.continueWatching)
                        .font(.system(size: Self.titleFontSize, weight: .semibold))
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .buttonStyle(.glass)
            .frame(height: 70)

            Button(action: { showCleanupDialog = true }) {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 38))
                    Text(lm.strings.localCleanupBtn)
                        .font(.system(size: Self.titleFontSize, weight: .semibold))
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .buttonStyle(.glass)
            .frame(height: 70)

            Button(action: { Task { await store.refreshAllStatuses() } }) {
                HStack(spacing: 12) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 38))
                    Text(lm.strings.localRefreshBtn)
                        .font(.system(size: Self.titleFontSize, weight: .semibold))
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .buttonStyle(.glass)
            .frame(height: 70)
        }
        // Match SettingsView button row width (Settings has an extra outer horizontal padding)
        .padding(.horizontal, 80)
        .padding(.top, 60)
        .confirmationDialog(lm.strings.localCleanupTitle, isPresented: $showCleanupDialog, titleVisibility: .visible) {
            Button(lm.strings.localCleanupClearPosterCache) {
                TMDBService.shared.clearCache()
            }
            Button(lm.strings.localCleanupClearContinue, role: .destructive) {
                LocalPlaybackHistoryService.shared.clearAll()
            }
            Button(lm.strings.cancel, role: .cancel) { }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 30) {
            Image(systemName: "externaldrive.badge.questionmark")
                .font(.system(size: 100))
                .foregroundColor(.white.opacity(0.2))
            Text(lm.strings.localNoServers)
                .font(.title3)
                .foregroundColor(.white.opacity(0.4))
        }
        .padding(.top, 100)
    }
}
