import Foundation
import AMSMB2

actor LocalSMBClient {
    private let config: LocalSMBConnectionConfig
    private let manager: SMB2Manager

    init(config: LocalSMBConnectionConfig) {
        self.config = config
        let serverURL = URL(string: "smb://\(config.host)")!
        let credential = URLCredential(user: config.username, password: config.password, persistence: .forSession)
        self.manager = SMB2Manager(url: serverURL, credential: credential)!
    }

    func connect() async throws {
        try await manager.connectShare(name: config.share)
    }

    func list(path: String) async throws -> [LocalLibraryItem] {
        // FIX: guard against path traversal attacks
        guard !path.contains("..") else { throw URLError(.badURL) }
        let entries = try await manager.contentsOfDirectory(atPath: normalize(path))
        return entries.compactMap { dict in
            guard let name = dict[.nameKey] as? String else { return nil }
            let itemPath = (dict[.pathKey] as? String) ?? join(path, name)
            let type = dict[.fileResourceTypeKey] as? URLFileResourceType
            let isDir = (type == .directory)
            let size = (dict[.fileSizeKey] as? Int64) ?? 0
            let modified = dict[.contentModificationDateKey] as? Date

            let id = "\(itemPath)|\(size)|\(modified?.timeIntervalSince1970 ?? 0)"
            return LocalLibraryItem(id: id, name: name, path: itemPath, isDirectory: isDir, size: size, modified: modified)
        }
        .sorted { a, b in
            if a.isDirectory != b.isDirectory { return a.isDirectory && !b.isDirectory }
            return a.name.localizedCaseInsensitiveCompare(b.name) == .orderedAscending
        }
    }

    private func normalize(_ path: String) -> String {
        if path.isEmpty { return "/" }
        return path.hasPrefix("/") ? path : "/" + path
    }

    private func join(_ base: String, _ name: String) -> String {
        let b = base.hasSuffix("/") ? String(base.dropLast()) : base
        return b.isEmpty ? "/" + name : b + "/" + name
    }
}
