import SwiftUI

struct LocalHistoryView: View {
    @EnvironmentObject private var store: LocalServerStore
    @ObservedObject private var lm = LanguageManager.shared
    @ObservedObject private var historyService = LocalPlaybackHistoryService.shared
    @Environment(\.dismiss) private var dismiss

    @FocusState private var focusedTarget: FocusTarget?
    private enum FocusTarget: Hashable { case back }

    @State private var playbackRequest: LocalPlaybackRequest?
    @State private var movieInfoChannel: Channel?

    // ContinueWatching cards here use the same wide "plaque" layout as in LocalLibraryView
    // Keep adaptive wrapping, but lock card width so spacing is visible and consistent.
    private static let cardWidth: CGFloat = 360
    private static let gridSpacing: CGFloat = 100
    private static let columns = [
        GridItem(.adaptive(minimum: cardWidth, maximum: cardWidth), spacing: gridSpacing)
    ]

    private var entries: [LocalSavedPlayback] {
        historyService.items.values
            .filter { $0.duration <= 0 || $0.progress < 0.95 }
            .sorted { $0.updatedAt > $1.updatedAt }
    }

    var body: some View {
        ZStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .center, spacing: 30) {
                    header

                    if entries.isEmpty {
                        VStack(spacing: 18) {
                            Image(systemName: "clock")
                                .font(.system(size: 90))
                                .foregroundColor(.white.opacity(0.2))
                            Text(lm.strings.localContinueEmpty)
                                .font(.title3)
                                .foregroundColor(.white.opacity(0.4))
                        }
                        .padding(.top, 120)
                    } else {
                        LazyVGrid(columns: Self.columns, spacing: Self.gridSpacing) {
                            ForEach(entries) { entry in
                                LocalContinueWatchingCard(entry: entry) {
                                    play(entry: entry, resume: true)
                                }
                                .contextMenu {
                                    Text(LocalTitleCleaner.clean(entry.name))
                                        .font(.system(size: 20, weight: .semibold))
                                    Divider()

                                    Button {
                                        movieInfoChannel = Channel(
                                            name: LocalTitleCleaner.clean(entry.name),
                                            url: entry.path,
                                            group: "Movie"
                                        )
                                    } label: {
                                        Label(lm.strings.actionInfoMovie, systemImage: "info.circle")
                                    }

                                    Button {
                                        play(entry: entry, resume: false)
                                    } label: {
                                        Label(lm.strings.btnStartOver, systemImage: "play.fill")
                                    }

                                    Button(role: .destructive) {
                                        historyService.remove(mediaId: entry.id)
                                    } label: {
                                        Label(lm.strings.ctxRemoveWatchLater, systemImage: "clock.badge.xmark")
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 80)
                        .padding(.bottom, 80)
                    }
                }
            }
            .sheet(item: $movieInfoChannel) { channel in
                MovieInfoSheet(channel: channel)
            }
            .fullScreenCover(item: $playbackRequest) { req in
                LocalPlayerScreen(request: req)
            }
        }
        .onAppear { applyDefaultFocusIfNeeded() }
        .onChange(of: entries.isEmpty) { _ in applyDefaultFocusIfNeeded() }

    }

    private var header: some View {
        HStack(spacing: 0) {
            if entries.isEmpty {
                Button {
                    dismiss()
                } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .semibold))
                        Text(backTitle)
                            .font(.system(size: 24, weight: .bold))
                    }
                    .padding(.vertical, 6)
                    .padding(.horizontal, 10)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(focusedTarget == .back ? .white.opacity(0.14) : .clear)
                    )
                }
                .buttonStyle(.glass)
                .focused($focusedTarget, equals: .back)
            } else {
                Text(lm.strings.continueWatching)
                    .font(.system(size: 38, weight: .bold))
                    .foregroundColor(.white)
            }
            Spacer(minLength: 0)
        }
        .padding(.leading, 60)
        .padding(.top, 30)
    }

    private var backTitle: String {
        lm.current == .ru ? "Назад" : "Back"
    }

    private func applyDefaultFocusIfNeeded() {
        guard entries.isEmpty else { return }
        DispatchQueue.main.async {
            focusedTarget = .back
        }
    }

    private func play(entry: LocalSavedPlayback, resume: Bool) {
        guard let server = store.servers.first(where: { $0.id == entry.serverId }) else { return }
        guard let password = LocalKeychainStore.shared.getPassword(for: server.id) else { return }
        guard let url = LocalSMBURLBuilder.build(
            host: server.host,
            share: server.share,
            username: server.username,
            password: password,
            path: entry.path
        ) else { return }

        playbackRequest = LocalPlaybackRequest(
            id: entry.id,
            serverId: entry.serverId,
            path: entry.path,
            name: LocalTitleCleaner.clean(entry.name),
            smbURL: url,
            startAtSeconds: resume ? entry.time : nil
        )
    }
}
