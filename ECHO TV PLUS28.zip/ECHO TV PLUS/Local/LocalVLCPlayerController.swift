import Foundation
import Combine
import VLCKitSPM

@MainActor
final class LocalVLCPlayerController: NSObject, ObservableObject, VLCMediaPlayerDelegate {
    struct Track: Identifiable, Equatable {
        let id: Int32
        let name: String
    }

    enum AspectMode: String, CaseIterable, Identifiable {
        case `default` = "Default"
        case sixteenNine = "16:9"
        case fourThree = "4:3"
        case oneOne = "1:1"

        var id: String { rawValue }
    }

    @Published private(set) var isPlaying: Bool = false
    @Published private(set) var isBuffering: Bool = false

    @Published private(set) var timeSeconds: Double = 0
    @Published private(set) var durationSeconds: Double = 0

    @Published private(set) var audioTracks: [Track] = []
    @Published private(set) var subtitleTracks: [Track] = []
    @Published private(set) var selectedAudioTrack: Int32?
    @Published private(set) var selectedSubtitleTrack: Int32?

    @Published private(set) var isMuted: Bool = false
    @Published private(set) var aspectMode: AspectMode = .default

    let player = VLCMediaPlayer()

    private var didSeek = false
    private var startAtSeconds: Double?
    private var lastProgressSaveAt: TimeInterval = 0

    private var mediaId: String = ""
    private var serverId: UUID?
    private var mediaPath: String = ""
    private var mediaName: String = ""

    private var aspectCString: UnsafeMutablePointer<CChar>?

    override init() {
        super.init()
        player.delegate = self
    }

    deinit {
        if let aspectCString {
            free(aspectCString)
        }
    }

    func attachDrawable(_ view: Any) {
        player.drawable = view
    }

    func start(
        url: URL,
        mediaId: String,
        serverId: UUID?,
        path: String,
        name: String,
        startAtSeconds: Double?
    ) {
        self.mediaId = mediaId
        self.serverId = serverId
        self.mediaPath = path
        self.mediaName = name
        self.startAtSeconds = startAtSeconds
        self.didSeek = false

        player.media = VLCMedia(url: url)
        player.play()
    }

    func stop() {
        // Save last known progress before stopping (VLC may reset time to 0 after stop).
        saveProgress(force: true)
        player.stop()
    }

    func togglePlayPause() {
        if isPlaying { pause() } else { play() }
    }

    func play() {
        player.play()
    }

    func pause() {
        player.pause()
    }

    func jump(by seconds: Double) {
        guard durationSeconds > 0 else { return }
        let target = max(0, min(durationSeconds, timeSeconds + seconds))
        seek(to: target)
    }

    func seek(to seconds: Double) {
        let ms = Int32(max(0, seconds) * 1000)
        player.time = VLCTime(int: ms)
    }

    func toggleMute() {
        let newValue = !isMuted
        isMuted = newValue
        player.audio?.isMuted = newValue
    }

    func setAudioTrack(_ id: Int32) {
        player.currentAudioTrackIndex = id
        selectedAudioTrack = id
    }

    func setSubtitleTrack(_ id: Int32) {
        player.currentVideoSubTitleIndex = id
        selectedSubtitleTrack = id
    }

    func setAspect(_ mode: AspectMode) {
        aspectMode = mode

        if let aspectCString {
            free(aspectCString)
            self.aspectCString = nil
        }

        switch mode {
        case .default:
            player.videoAspectRatio = nil
        case .sixteenNine:
            aspectCString = strdup("16:9")
            player.videoAspectRatio = aspectCString
        case .fourThree:
            aspectCString = strdup("4:3")
            player.videoAspectRatio = aspectCString
        case .oneOne:
            aspectCString = strdup("1:1")
            player.videoAspectRatio = aspectCString
        }
    }

    func mediaPlayerStateChanged(_ aNotification: Notification) {
        isPlaying = player.isPlaying
        isBuffering = (player.state == .buffering || player.state == .opening)

        if !didSeek, let startAtSeconds, startAtSeconds > 0 {
            if player.state == .playing || player.state == .buffering || player.state == .opening {
                seek(to: startAtSeconds)
                didSeek = true
            }
        }

        refreshTracksIfNeeded()
        syncMuteFlag()
    }

    func mediaPlayerTimeChanged(_ aNotification: Notification) {
        timeSeconds = Double(player.time.intValue) / 1000.0
        durationSeconds = Double(player.media?.length.intValue ?? 0) / 1000.0

        let now = Date().timeIntervalSince1970
        if now - lastProgressSaveAt >= 10 {
            lastProgressSaveAt = now
            saveProgress(force: false)
        }
    }

    private func refreshTracksIfNeeded() {
        let audioIndexes = (player.audioTrackIndexes as? [NSNumber])?.map { $0.int32Value } ?? []
        let audioNames = (player.audioTrackNames as? [String]) ?? []
        if audioIndexes.count == audioNames.count, !audioIndexes.isEmpty {
            audioTracks = zip(audioIndexes, audioNames).map { Track(id: $0.0, name: $0.1) }
        }

        let subIndexes = (player.videoSubTitlesIndexes as? [NSNumber])?.map { $0.int32Value } ?? []
        let subNames = (player.videoSubTitlesNames as? [String]) ?? []
        if subIndexes.count == subNames.count, !subIndexes.isEmpty {
            subtitleTracks = zip(subIndexes, subNames).map { Track(id: $0.0, name: $0.1) }
        }

        selectedAudioTrack = Int32(player.currentAudioTrackIndex)
        selectedSubtitleTrack = Int32(player.currentVideoSubTitleIndex)
    }

    private func syncMuteFlag() {
        if let muted = player.audio?.isMuted {
            isMuted = muted
        }
    }

    private func saveProgress(force: Bool) {
        guard let serverId else { return }
        let t = timeSeconds
        let d = durationSeconds

        // Match IPTV behavior: don't spam history, but allow saving on stop.
        if !force, t <= 10 { return }

        LocalPlaybackHistoryService.shared.saveProgress(
            mediaId: mediaId,
            serverId: serverId,
            path: mediaPath,
            name: mediaName,
            time: t,
            duration: d
        )
    }

    var timeText: String { formatTime(timeSeconds) }
    var durationText: String { formatTime(durationSeconds) }

    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "0:00" }
        let s = Int(seconds.rounded(.down))
        let h = s / 3600
        let m = (s % 3600) / 60
        let sec = s % 60
        if h > 0 { return "\(h):" + String(format: "%02d:%02d", m, sec) }
        return "\(m):" + String(format: "%02d", sec)
    }
}
