import Foundation

enum LocalSMBURLBuilder {
    static func build(host: String, share: String, username: String, password: String, path: String) -> URL? {
        let h = host.trimmingCharacters(in: .whitespacesAndNewlines)
        let s = share.trimmingCharacters(in: .whitespacesAndNewlines)
        let u = username.trimmingCharacters(in: .whitespacesAndNewlines)

        let userEnc = u.addingPercentEncoding(withAllowedCharacters: .urlUserAllowed) ?? u
        let passEnc = password.addingPercentEncoding(withAllowedCharacters: .urlPasswordAllowed) ?? password

        let cleanPath = path.hasPrefix("/") ? String(path.dropFirst()) : path
        let str = "smb://\(userEnc):\(passEnc)@\(h)/\(s)/\(cleanPath)"
        return URL(string: str)
    }
}
