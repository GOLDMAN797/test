import Foundation
import Combine

struct LocalSavedPlayback: Codable, Identifiable, Equatable, Sendable {
    let id: String
    let serverId: UUID
    let path: String
    let name: String
    let time: Double
    let duration: Double
    let updatedAt: Date

    var progress: Double {
        guard duration > 0 else { return 0 }
        return min(1.0, max(0.0, time / duration))
    }

    var remainingMinutesText: String {
        guard duration > 0 else { return "" }
        let remaining = max(0, duration - time)
        let mins = Int(ceil(remaining / 60))
        return "\(mins) \(LanguageManager.shared.strings.minutesLeft)"
    }
}

@MainActor
final class LocalPlaybackHistoryService: ObservableObject {
    static let shared = LocalPlaybackHistoryService()

    private let key = "echotv.local.playback.v2"

    @Published private(set) var items: [String: LocalSavedPlayback] = [:]

    private init() {
        load()
    }

    // MARK: - Media ID (stable)

    /// Stable ID used across sessions and SMB listing variations.
    /// Format: "<serverUUID>|<normalizedPath>"
    static func makeMediaId(serverId: UUID, path: String, share: String? = nil) -> String {
        "\(serverId.uuidString)|\(normalizePath(path, share: share))"
    }

    /// Normalizes paths for ID matching (does NOT change the actual SMB request path).
    /// - Removes leading slashes
    /// - Converts backslashes to slashes
    /// - Collapses duplicate slashes
    /// - Optionally strips a leading share segment if present
    static func normalizePath(_ path: String, share: String? = nil) -> String {
        var p = path.trimmingCharacters(in: .whitespacesAndNewlines)
        p = p.replacingOccurrences(of: "\\", with: "/")
        while p.hasPrefix("/") { p.removeFirst() }
        while p.contains("//") { p = p.replacingOccurrences(of: "//", with: "/") }

        if let share, !share.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let s = share.trimmingCharacters(in: .whitespacesAndNewlines)
            let lower = p.lowercased()
            let sLower = s.lowercased()
            if lower == sLower {
                p = ""
            } else if lower.hasPrefix(sLower + "/") {
                p = String(p.dropFirst(s.count + 1))
            }
        }
        return p
    }

    // MARK: – Persist: простой UserDefaults + JSONEncoder (без Task.detached)

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([String: LocalSavedPlayback].self, from: data)
        else { return }

        // Migration: older builds used unstable IDs with extra segments (size/modified).
        // New stable format is "serverUUID|path".
        var migrated: [String: LocalSavedPlayback] = [:]
        for (k, v) in decoded {
            let stableKey = migrateKeyIfNeeded(k, value: v)
            if let existing = migrated[stableKey] {
                migrated[stableKey] = existing.updatedAt >= v.updatedAt ? existing : v.withId(stableKey)
            } else {
                migrated[stableKey] = v.withId(stableKey)
            }
        }

        items = migrated

        if migrated.count != decoded.count || Set(migrated.keys) != Set(decoded.keys) {
            persist()
        }
    }

    private func migrateKeyIfNeeded(_ key: String, value: LocalSavedPlayback) -> String {
        let parts = key.split(separator: "|", omittingEmptySubsequences: false)
        if parts.count >= 2 {
            let serverPart = String(parts[0])
            let pathPart = String(parts[1])
            return serverPart + "|" + Self.normalizePath(pathPart)
        }
        return Self.makeMediaId(serverId: value.serverId, path: value.path)
    }

    private func persist() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    // MARK: – Public API

    func getItem(for mediaId: String) -> LocalSavedPlayback? {
        items[mediaId]
    }

    func remove(mediaId: String) {
        items.removeValue(forKey: mediaId)
        persist()
    }

    func clearAll() {
        items.removeAll()
        persist()
    }

    func saveProgress(
        mediaId: String,
        serverId: UUID,
        path: String,
        name: String,
        time: Double,
        duration: Double
    ) {
        guard time > 10 else { return }
        let stableId = Self.makeMediaId(serverId: serverId, path: path)

        // If duration is known, drop nearly-finished items from history
        if duration > 0, time / duration >= 0.95 {
            items.removeValue(forKey: stableId)
            persist()
            return
        }

        items[stableId] = LocalSavedPlayback(
            id: stableId,
            serverId: serverId,
            path: path,
            name: name,
            time: time,
            duration: duration,
            updatedAt: Date()
        )
        persist()

        // Чистим если накопилось больше 25 записей для этого сервера
        if items.values.filter({ $0.serverId == serverId }).count > 25 {
            cleanup(serverId: serverId)
        }
    }

    func continueWatching(serverId: UUID) -> [LocalSavedPlayback] {
        items.values
            .filter { $0.serverId == serverId }
            .filter { $0.duration <= 0 || $0.progress < 0.95 }
            .sorted { $0.updatedAt > $1.updatedAt }
            .prefix(12)
            .map { $0 }
    }

    private func cleanup(serverId: UUID) {
        let sorted = items.values
            .filter { $0.serverId == serverId }
            .sorted { $0.updatedAt > $1.updatedAt }
        guard sorted.count > 20 else { return }
        let keep = Set(sorted.prefix(20).map { $0.id })
        items = items.filter { keep.contains($0.key) || $0.value.serverId != serverId }
        persist()
    }
}

private extension LocalSavedPlayback {
    func withId(_ newId: String) -> LocalSavedPlayback {
        LocalSavedPlayback(
            id: newId,
            serverId: serverId,
            path: path,
            name: name,
            time: time,
            duration: duration,
            updatedAt: updatedAt
        )
    }
}
