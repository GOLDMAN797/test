import Foundation
import Combine

@MainActor
final class LocalServerStore: ObservableObject {
    @Published private(set) var servers: [LocalServer] = []
    @Published var activeServerId: UUID?

    @Published private(set) var isBusy: Bool = false

    private let serversKey = "echotv.local.servers.v1"
    private let activeKey = "echotv.local.activeServerId.v1"

    var activeServer: LocalServer? {
        guard let id = activeServerId else { return nil }
        return servers.first(where: { $0.id == id })
    }

    init() {
        load()
    }

    func load() {
        let defaults = UserDefaults.standard

        if let data = defaults.data(forKey: serversKey),
           let decoded = try? JSONDecoder().decode([LocalServer].self, from: data) {
            servers = decoded
        } else {
            servers = []
        }

        if let str = defaults.string(forKey: activeKey),
           let uuid = UUID(uuidString: str) {
            activeServerId = uuid
        } else {
            activeServerId = servers.first?.id
        }
    }

    func persist() {
        let defaults = UserDefaults.standard
        if let data = try? JSONEncoder().encode(servers) {
            defaults.set(data, forKey: serversKey)
        }
        defaults.set(activeServerId?.uuidString, forKey: activeKey)
    }

    func setActive(_ id: UUID) {
        activeServerId = id
        persist()
    }

    func addServer(host: String, share: String, username: String, password: String) async throws {
        isBusy = true
        defer { isBusy = false }

        let server = LocalServer(host: host, share: share, username: username, status: .unknown, lastChecked: nil)
        guard LocalKeychainStore.shared.setPassword(password, for: server.id) else {
            throw NSError(domain: "echotv.local.keychain", code: -1)
        }

        servers.insert(server, at: 0)
        activeServerId = server.id
        persist()

        _ = try await checkStatus(serverId: server.id)
    }

    func updateServer(id: UUID, host: String, share: String, username: String, password: String?) async throws {
        isBusy = true
        defer { isBusy = false }

        guard let index = servers.firstIndex(where: { $0.id == id }) else { return }
        servers[index].host = host
        servers[index].share = share
        servers[index].username = username
        servers[index].status = .unknown
        servers[index].lastChecked = nil

        if let password {
            _ = LocalKeychainStore.shared.setPassword(password, for: id)
        }

        persist()
        _ = try await checkStatus(serverId: id)
    }

    func deleteServer(id: UUID) {
        servers.removeAll { $0.id == id }
        _ = LocalKeychainStore.shared.deletePassword(for: id)

        if activeServerId == id {
            activeServerId = servers.first?.id
        }

        persist()
    }

    func refreshAllStatuses() async {
        guard !servers.isEmpty else { return }
        isBusy = true
        defer { isBusy = false }

        for s in servers {
            _ = try? await checkStatus(serverId: s.id)
        }
    }

    func checkStatus(serverId: UUID) async throws -> LocalServer.Status {
        guard let server = servers.first(where: { $0.id == serverId }) else { return .unknown }
        guard let password = LocalKeychainStore.shared.getPassword(for: serverId) else {
            setServerStatus(serverId, status: .offline)
            return .offline
        }

        let config = LocalSMBConnectionConfig(host: server.host, share: server.share, username: server.username, password: password)
        let client = LocalSMBClient(config: config)

        do {
            try await client.connect()
            _ = try await client.list(path: "/")
            setServerStatus(serverId, status: .online)
            return .online
        } catch {
            setServerStatus(serverId, status: .offline)
            throw error
        }
    }

    private func setServerStatus(_ id: UUID, status: LocalServer.Status) {
        guard let index = servers.firstIndex(where: { $0.id == id }) else { return }
        servers[index].status = status
        servers[index].lastChecked = Date()
        persist()
    }
}
