import SwiftUI

// Точно такой же дизайн как PlaylistChannelCard (height 140, шрифты, структура)
struct LocalFolderCard: View {
    let title: String
    @ObservedObject private var lm = LanguageManager.shared
    var body: some View {
        ZStack {
            // Иконка по центру — как лого канала
            Image(systemName: "folder.fill")
                .font(.system(size: 40))
                .foregroundColor(.secondary)
                .padding(EdgeInsets(top: 35, leading: 0, bottom: 35, trailing: 0))
                .blur(radius: 0.1)

            // Текстовый оверлей — структура 1-в-1 как PlaylistChannelCard
            VStack(spacing: 0) {
                HStack(alignment: .top) {
                    Text(title)
                        .font(.system(size: 18, weight: .bold))
                        .lineLimit(1)
                    Spacer()
                }
                .padding(.top, 4)
                .padding(.horizontal, 4)

                Spacer()

                HStack(alignment: .bottom, spacing: 4) {
                    Text(lm.strings.localFolderLabel)
                        .font(.system(size: 15, weight: .regular))
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.bottom, 4)
                .padding(.horizontal, 4)
            }
        }
        .frame(width: 250, height: 140 )
    }
}
