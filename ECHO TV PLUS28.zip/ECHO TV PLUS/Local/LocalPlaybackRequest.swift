import Foundation

struct LocalPlaybackRequest: Identifiable, Equatable {
    let id: String
    let serverId: UUID
    let path: String
    let name: String
    let smbURL: URL
    let startAtSeconds: Double?
}
