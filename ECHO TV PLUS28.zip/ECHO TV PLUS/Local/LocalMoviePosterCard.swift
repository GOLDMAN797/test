import SwiftUI

// Постеры ищутся по очищенному имени файла через TMDBService.
// Чтобы постер нашёлся — имя файла должно быть читаемым названием фильма.
// Примеры которые РАБОТАЮТ:
//   "Interstellar.2014.mkv"       → ищет "Interstellar"
//   "The.Dark.Knight.2008.mkv"    → ищет "The Dark Knight"
//   "Аватар [2009] 4K.mkv"        → ищет "Аватар"
//   "Game.of.Thrones.S01E01.mkv"  → ищет "Game of Thrones"
// LocalTitleCleaner убирает расширение, качество, теги в скобках, год.

struct LocalMoviePosterCard: View {
    let title: String   // уже очищенное название (displayTitle)
    let titleLineLimit: Int

    @State private var posterURL: URL?

    private var safeTitle: String {
        title
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")
            .replacingOccurrences(of: "\t", with: " ")
            .replacingOccurrences(of: "\u{2028}", with: " ")
            .replacingOccurrences(of: "\u{2029}", with: " ")
            .replacingOccurrences(of: "\u{00A0}", with: " ")
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    init(title: String, titleLineLimit: Int = 1) {
        self.title = title
        self.titleLineLimit = titleLineLimit
    }

    var body: some View {
        Color.clear
            .aspectRatio(2 / 3, contentMode: .fit)
            .overlay {
                ZStack {
                    Color.white.opacity(0.1)

                    if let url = posterURL {
                        GeometryReader { geo in
                            OptimizedPosterView(
                                url: url,
                                width: geo.size.width,
                                height: geo.size.height
                            )
                            .position(x: geo.size.width / 2, y: geo.size.height / 2)
                            .transaction { $0.animation = nil }
                        }
                    } else {
                        fallbackView
                    }

                    VStack {
                        Spacer()
                        ZStack(alignment: .bottom) {
                            LinearGradient(
                                colors: [.black.opacity(0.9), .clear],
                                startPoint: .bottom,
                                endPoint: .top
                            )
                            .frame(height: 30)

                            Text(safeTitle)
                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                                .lineLimit(titleLineLimit)
                                .multilineTextAlignment(.center)
                                .truncationMode(.tail)
                                .frame(maxWidth: .infinity)
                                .padding(.horizontal, 8)
                                .padding(.bottom, 12)
                                .shadow(radius: 2)
                        }
                    }
                }
                .clipped()
            }
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .contentShape(Rectangle())
            .animation(nil, value: posterURL)
            // task(id: title) — перезапускается если название изменилось
            .task(id: title) {
                // Сначала проверяем кэш — без задержки
                if let cached = TMDBService.shared.getCachedURL(for: title) {
                    posterURL = cached
                    return
                }

                posterURL = nil

                // Небольшая задержка чтобы не спамить API при быстром скролле
                try? await Task.sleep(nanoseconds: 150_000_000)
                if Task.isCancelled { return }

                // Ищем постер по очищенному названию
                if let url = await TMDBService.shared.getPosterURL(for: title) {
                    posterURL = url
                }
            }
    }

    private var fallbackView: some View {
        ZStack {
            Color.white.opacity(0.05)
            VStack(spacing: 10) {
                Image(systemName: "film")
                    .font(.system(size: 40))
                    .foregroundColor(.white.opacity(0.2))
                Text(safeTitle)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.4))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .lineLimit(1)
                    .truncationMode(.tail)
            }
        }
    }
}
