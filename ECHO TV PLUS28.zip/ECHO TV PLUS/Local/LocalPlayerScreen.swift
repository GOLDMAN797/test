import SwiftUI

struct LocalPlayerScreen: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.resetFocus) private var resetFocus

    let request: LocalPlaybackRequest

    @StateObject private var controller = LocalVLCPlayerController()

    @State private var overlayVisible: Bool = true
    @State private var showAudioDialog: Bool = false
    @State private var showSubsDialog: Bool = false
    @State private var showAspectDialog: Bool = false

    @State private var scrubValue: Double = 0
    @State private var scrubberFocused: Bool = false

    @State private var hideWorkItem: DispatchWorkItem?

    @Namespace private var overlayFocusNamespace
    @Namespace private var playerFocusNamespace
    @FocusState private var playerCatcherFocused: Bool

    var body: some View {
        ZStack {
            LocalVLCPlayerView(controller: controller)
                .ignoresSafeArea()

            if overlayVisible {
                LocalPlayerOverlayView(
                    controller: controller,
                    title: request.name,
                    focusNamespace: overlayFocusNamespace,
                    scrubValue: $scrubValue,
                    scrubRange: 0...max(controller.durationSeconds, 1),
                    onScrubSeek: { value in
                        controller.seek(to: value)
                        scheduleAutoHide()
                    },
                    onScrubberFocusChanged: { focused in
                        scrubberFocused = focused
                        // Когда скраббер в фокусе — не скрываем оверлей
                        if focused {
                            cancelAutoHide()
                        } else {
                            scheduleAutoHide()
                        }
                    },
                    showAudioDialog: $showAudioDialog,
                    showSubsDialog: $showSubsDialog,
                    showAspectDialog: $showAspectDialog
                )
                .onAppear {
                    DispatchQueue.main.async { resetFocus(in: overlayFocusNamespace) }
                    scheduleAutoHide()
                }
            } else {
                // Когда оверлей скрыт — ловим нажатия:
                // влево/вправо = перемотка (БЕЗ показа оверлея сразу)
                // вверх/вниз / play-pause = показываем оверлей
                PlayerFocusCatcher(
                    focused: $playerCatcherFocused,
                    focusNamespace: playerFocusNamespace,
                    onPlayPause: {
                        controller.togglePlayPause()
                        showOverlay()
                    },
                    onJump: { delta in
                        // Перемотка работает молча — оверлей не показываем,
                        // только обновляем scrubValue чтобы скраббер был актуален
                        controller.jump(by: delta)
                    },
                    onShowOverlay: { showOverlay() }
                )
                .onAppear {
                    DispatchQueue.main.async { resetFocus(in: playerFocusNamespace) }
                }
            }
        }
        .onAppear {
            scrubValue = request.startAtSeconds ?? 0
            controller.start(
                url: request.smbURL,
                mediaId: request.id,
                serverId: request.serverId,
                path: request.path,
                name: request.name,
                startAtSeconds: request.startAtSeconds
            )
            overlayVisible = true
            DispatchQueue.main.async { resetFocus(in: overlayFocusNamespace) }
            scheduleAutoHide()
        }
        .onDisappear {
            cancelAutoHide()
            controller.stop()
        }
        .onPlayPauseCommand {
            controller.togglePlayPause()
            showOverlay()
        }
        .onExitCommand {
            if overlayVisible {
                overlayVisible = false
            } else {
                dismiss()
            }
        }
        .confirmationDialog("Audio Track", isPresented: $showAudioDialog, titleVisibility: .visible) {
            ForEach(controller.audioTracks) { t in
                Button(t.name) { controller.setAudioTrack(t.id) }
            }
        }
        .confirmationDialog("Subtitles", isPresented: $showSubsDialog, titleVisibility: .visible) {
            Button("Off") { controller.setSubtitleTrack(-1) }
            ForEach(controller.subtitleTracks) { t in
                Button(t.name) { controller.setSubtitleTrack(t.id) }
            }
        }
        .confirmationDialog("Aspect Ratio", isPresented: $showAspectDialog, titleVisibility: .visible) {
            ForEach(LocalVLCPlayerController.AspectMode.allCases) { m in
                Button(m.rawValue) { controller.setAspect(m) }
            }
        }
        // Синхронизируем scrubber с реальным временем (только когда он не в фокусе)
        .onChange(of: controller.timeSeconds) { _, newValue in
            if !scrubberFocused { scrubValue = newValue }
        }
    }

    private func showOverlay() {
        overlayVisible = true
        DispatchQueue.main.async { resetFocus(in: overlayFocusNamespace) }
        scheduleAutoHide()
    }

    private func scheduleAutoHide() {
        cancelAutoHide()
        guard overlayVisible else { return }
        let work = DispatchWorkItem {
            // Не скрываем если скраббер в фокусе или открыт диалог
            if !self.scrubberFocused && !self.showAudioDialog
                && !self.showSubsDialog && !self.showAspectDialog {
                self.overlayVisible = false
            }
        }
        hideWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 4, execute: work)
    }

    private func cancelAutoHide() {
        hideWorkItem?.cancel()
        hideWorkItem = nil
    }
}

// MARK: – PlayerFocusCatcher
// Перехватывает пульт когда оверлей скрыт.
// Влево/вправо = тихая перемотка, вверх/вниз/Play = показать оверлей

private struct PlayerFocusCatcher: View {
    let focused: FocusState<Bool>.Binding
    let focusNamespace: Namespace.ID

    let onPlayPause: () -> Void
    let onJump: (Double) -> Void
    let onShowOverlay: () -> Void

    var body: some View {
        Color.clear
            .focusScope(focusNamespace)
            .focusSection()
            .focusable(true)
            .focused(focused)
            .onPlayPauseCommand {
                onPlayPause()
            }
            .onMoveCommand { dir in
                switch dir {
                case .left:
                    // Тихая перемотка назад — оверлей не показываем
                    onJump(-10)
                case .right:
                    // Тихая перемотка вперёд — оверлей не показываем
                    onJump(10)
                case .up, .down:
                    onShowOverlay()
                @unknown default:
                    break
                }
            }
            .onLongPressGesture(minimumDuration: 0.3) {
                onShowOverlay()
            }
    }
}
