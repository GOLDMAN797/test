import Foundation

struct LocalServer: Identifiable, Codable, Equatable {
    enum Status: String, Codable {
        case unknown
        case online
        case offline
    }

    var id: UUID
    var host: String
    var share: String
    var username: String
    var status: Status
    var lastChecked: Date?

    init(
        id: UUID = UUID(),
        host: String,
        share: String,
        username: String,
        status: Status = .unknown,
        lastChecked: Date? = nil
    ) {
        self.id = id
        self.host = host
        self.share = share
        self.username = username
        self.status = status
        self.lastChecked = lastChecked
    }
}

struct LocalSMBConnectionConfig: Equatable {
    var host: String
    var share: String
    var username: String
    var password: String
}

// MARK: - Series Info

struct LocalSeriesInfo: Equatable {
    let season: Int?
    let episode: Int?
    let episodeEnd: Int?

    var badge: String {
        switch (season, episode) {
        case let (s?, e?):
            return "S\(s) E\(e)"
        case let (s?, nil):
            return "Season \(s)"
        case let (nil, e?):
            return "Episode \(e)"
        default:
            return ""
        }
    }
}

// MARK: - Library Item

struct LocalLibraryItem: Identifiable, Hashable {
    let id: String
    let name: String
    let path: String
    let isDirectory: Bool
    let size: Int64
    let modified: Date?

    var seriesInfo: LocalSeriesInfo? { LocalSeriesParser.parse(name) }
    var displayTitle: String { LocalTitleCleaner.clean(name) }
    var isSeasonFolder: Bool { LocalSeriesParser.isSeasonFolder(name) }
    var isSeriesRelated: Bool { seriesInfo != nil || isSeasonFolder }
}

// MARK: - Series Parser

enum LocalSeriesParser {
    private static let episodePatterns: [NSRegularExpression] = [
        try! NSRegularExpression(pattern: #"[Ss](\d{1,2})[Ee](\d{1,3})(?:[Ee-](\d{1,3}))?"#),
        try! NSRegularExpression(pattern: #"(\d{1,2})[xX](\d{1,3})"#),
        try! NSRegularExpression(pattern: #"(?:[Сс]езон|[Ss]eason)\s*(\d{1,2}).*?(?:[Сс]ерия|[Ee]pisode)\s*(\d{1,3})"#),
        try! NSRegularExpression(pattern: #"(?<![Ss]\d{0,2})[Ee](\d{1,3})(?!\d)"#)
    ]

    private static let seasonFolderPatterns: [NSRegularExpression] = [
        try! NSRegularExpression(pattern: #"(?i)^s(?:eason|)\s*0*(\d{1,2})$"#),
        try! NSRegularExpression(pattern: #"(?i)^(?:сезон)\s*0*(\d{1,2})$"#),
        try! NSRegularExpression(pattern: #"(?i)^s0*(\d{1,2})$"#)
    ]

    static func parse(_ name: String) -> LocalSeriesInfo? {
        let nsName = name as NSString
        let range = NSRange(location: 0, length: nsName.length)

        if let m = episodePatterns[0].firstMatch(in: name, range: range) {
            let season = Int(nsName.substring(with: m.range(at: 1)))
            let episode = Int(nsName.substring(with: m.range(at: 2)))
            let episodeEnd: Int? = m.range(at: 3).location != NSNotFound
                ? Int(nsName.substring(with: m.range(at: 3)))
                : nil
            return LocalSeriesInfo(season: season, episode: episode, episodeEnd: episodeEnd)
        }

        if let m = episodePatterns[1].firstMatch(in: name, range: range) {
            let season = Int(nsName.substring(with: m.range(at: 1)))
            let episode = Int(nsName.substring(with: m.range(at: 2)))
            return LocalSeriesInfo(season: season, episode: episode, episodeEnd: nil)
        }

        if let m = episodePatterns[2].firstMatch(in: name, range: range) {
            let season = Int(nsName.substring(with: m.range(at: 1)))
            let episode = Int(nsName.substring(with: m.range(at: 2)))
            return LocalSeriesInfo(season: season, episode: episode, episodeEnd: nil)
        }

        if let m = episodePatterns[3].firstMatch(in: name, range: range) {
            let episode = Int(nsName.substring(with: m.range(at: 1)))
            return LocalSeriesInfo(season: nil, episode: episode, episodeEnd: nil)
        }

        return nil
    }

    static func isSeasonFolder(_ name: String) -> Bool {
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        let range = NSRange(trimmed.startIndex..., in: trimmed)
        return seasonFolderPatterns.contains { $0.firstMatch(in: trimmed, range: range) != nil }
    }
}

// MARK: - Title Cleaner

enum LocalTitleCleaner {
    private static let garbagePatterns: [NSRegularExpression] = {
        let patterns = [
            #"\.(mkv|mp4|avi|ts|m2ts|mov|wmv|flv)$"#,
            #"(?i)^\s*(?!19\d{2}\b)(?!20\d{2}\b)\d{1,3}\s*[-.)]?\s+"#,
            #"(?i)\b(sdr|rhs)\b"#,
            #"(?i)\bS\d{1,2}E\d{1,3}(?:E\d{1,3}|-E\d{1,3})?\b"#,
            #"(?i)\b\d{1,2}x\d{1,3}\b"#,
            #"(?i)\b[Ee]\d{1,3}\b"#,
            #"(?i)\b(4k|hdr|hdr10|dv|fhd|uhd|1080p|720p|480p|2160p|hevc|x264|x265|h\.264|h\.265|avc|xvid|divx)\b"#,
            #"(?i)\b(web-dl|webrip|bluray|bdrip|brrip|dvdrip|hdtv|pdtv|remux|proper)\b"#,
            #"(?i)\b(rus|eng|dub|sub|multi|atmos|truehd|dts|aac|ac3|dd5\.1|dd7\.1|flac)\b"#,
            #"\[.*?\]"#,
            #"\(.*?\)"#
        ]
        return patterns.compactMap { try? NSRegularExpression(pattern: $0) }
    }()

    static func clean(_ name: String) -> String {
        var s = name
        for regex in garbagePatterns {
            s = regex.stringByReplacingMatches(in: s, range: NSRange(s.startIndex..., in: s), withTemplate: "")
        }
        s = s.replacingOccurrences(of: ".", with: " ")
            .replacingOccurrences(of: "_", with: " ")
        while s.contains("  ") { s = s.replacingOccurrences(of: "  ", with: " ") }
        return s.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
