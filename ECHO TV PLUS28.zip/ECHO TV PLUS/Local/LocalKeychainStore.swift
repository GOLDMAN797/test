import Foundation
import Security

final class LocalKeychainStore {
    static let shared = LocalKeychainStore()

    private let service = "echotv.local.keychain"

    // FIX: kSecAttrAccessibleWhenUnlockedThisDeviceOnly — doesn't migrate to iCloud Backup
    // and is only accessible when the device is unlocked (more secure than default)
    private let accessibility = kSecAttrAccessibleWhenUnlockedThisDeviceOnly

    func setPassword(_ password: String, for serverId: UUID) -> Bool {
        let account = serverId.uuidString
        let data = Data(password.utf8)

        let query: [String: Any] = [
            kSecClass as String:           kSecClassGenericPassword,
            kSecAttrService as String:     service,
            kSecAttrAccount as String:     account
        ]

        let attributes: [String: Any] = [
            kSecValueData as String:       data,
            kSecAttrAccessible as String:  accessibility
        ]

        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecSuccess { return true }

        if status == errSecItemNotFound {
            var add = query
            add[kSecValueData as String]    = data
            add[kSecAttrAccessible as String] = accessibility
            return SecItemAdd(add as CFDictionary, nil) == errSecSuccess
        }

        return false
    }

    func getPassword(for serverId: UUID) -> String? {
        let query: [String: Any] = [
            kSecClass as String:        kSecClassGenericPassword,
            kSecAttrService as String:  service,
            kSecAttrAccount as String:  serverId.uuidString,
            kSecReturnData as String:   true,
            kSecMatchLimit as String:   kSecMatchLimitOne
        ]

        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    func deletePassword(for serverId: UUID) -> Bool {
        let query: [String: Any] = [
            kSecClass as String:        kSecClassGenericPassword,
            kSecAttrService as String:  service,
            kSecAttrAccount as String:  serverId.uuidString
        ]
        let status = SecItemDelete(query as CFDictionary)
        return status == errSecSuccess || status == errSecItemNotFound
    }
}
