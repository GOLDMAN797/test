import SwiftUI

struct LocalPlayerOverlayView: View {
    enum FocusItem: Hashable {
        case scrubber
        case playPause
        case back10
        case fwd10
        case audio
        case subs
        case aspect
        case mute
    }

    @ObservedObject var controller: LocalVLCPlayerController

    let title: String
    let focusNamespace: Namespace.ID

    @Binding var scrubValue: Double
    let scrubRange: ClosedRange<Double>
    let onScrubSeek: (Double) -> Void
    let onScrubberFocusChanged: (Bool) -> Void

    @Binding var showAudioDialog: Bool
    @Binding var showSubsDialog: Bool
    @Binding var showAspectDialog: Bool

    @FocusState private var focus: FocusItem?

    var body: some View {
        VStack(spacing: 0) {
            topBar
            Spacer()
            bottomBar
        }
        .focusScope(focusNamespace)
        .focusSection()
        .onAppear {
            DispatchQueue.main.async { focus = .playPause }
            onScrubberFocusChanged(false)
        }
        .onChange(of: focus) { _, v in
            onScrubberFocusChanged(v == .scrubber)
        }
        .transition(.opacity)
    }

    private var topBar: some View {
        HStack(spacing: 16) {
            Text(title)
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(1)
            Spacer()
        }
        .padding(.horizontal, 40)
        .padding(.top, 30)
        .padding(.bottom, 16)
        .background(.ultraThinMaterial)
    }

    private var bottomBar: some View {
        VStack(spacing: 14) {
            // Прогресс-бар с перемоткой
            HStack(spacing: 14) {
                Text(controller.timeText)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.9))
                    .frame(width: 90, alignment: .leading)

                ScrubberBar(
                    value: $scrubValue,
                    range: scrubRange,
                    onSeek: { value in
                        onScrubSeek(value)
                    }
                )
                .focused($focus, equals: .scrubber)

                Text(controller.durationText)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.9))
                    .frame(width: 90, alignment: .trailing)
            }
            .padding(.horizontal, 26)

            // Кнопки управления
            HStack(spacing: 14) {
                Button { controller.jump(by: -10) } label: {
                    Image(systemName: "gobackward.10")
                        .font(.system(size: 26, weight: .semibold))
                }
                .focused($focus, equals: .back10)
                .buttonStyle(.bordered)

                Button { controller.togglePlayPause() } label: {
                    Image(systemName: controller.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 26, weight: .bold))
                        .frame(width: 44)
                }
                .focused($focus, equals: .playPause)
                .prefersDefaultFocus(in: focusNamespace)
                .buttonStyle(.borderedProminent)

                Button { controller.jump(by: 10) } label: {
                    Image(systemName: "goforward.10")
                        .font(.system(size: 26, weight: .semibold))
                }
                .focused($focus, equals: .fwd10)
                .buttonStyle(.bordered)

                Spacer()

                Button { showAudioDialog = true } label: {
                    Label("Audio", systemImage: "waveform")
                        .font(.system(size: 20, weight: .semibold))
                }
                .focused($focus, equals: .audio)
                .buttonStyle(.bordered)

                Button { showSubsDialog = true } label: {
                    Label("Subtitles", systemImage: "captions.bubble")
                        .font(.system(size: 20, weight: .semibold))
                }
                .focused($focus, equals: .subs)
                .buttonStyle(.bordered)

                Button { showAspectDialog = true } label: {
                    Label("Aspect", systemImage: "aspectratio")
                        .font(.system(size: 20, weight: .semibold))
                }
                .focused($focus, equals: .aspect)
                .buttonStyle(.bordered)

                Button { controller.toggleMute() } label: {
                    Image(systemName: controller.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                        .font(.system(size: 22, weight: .semibold))
                        .frame(width: 44)
                }
                .focused($focus, equals: .mute)
                .buttonStyle(.bordered)
            }
            .padding(.horizontal, 26)
            .padding(.bottom, 18)
        }
        .padding(.top, 16)
        .background(.ultraThinMaterial)
    }
}

// MARK: – ScrubberBar
// Фокусируемый прогресс-бар. Влево/вправо — перемотка по 10 сек.
// Визуально: трек + заполнение + белый кружок.

private struct ScrubberBar: View {
    @Binding var value: Double
    let range: ClosedRange<Double>
    let onSeek: (Double) -> Void

    @Environment(\.isFocused) private var isFocused

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let frac = fraction

            ZStack(alignment: .leading) {
                // Трек
                Capsule()
                    .fill(Color.white.opacity(0.22))
                    .frame(height: isFocused ? 12 : 8)

                // Заполнение
                Capsule()
                    .fill(Color.white.opacity(0.9))
                    .frame(width: max(0, min(w, w * frac)), height: isFocused ? 12 : 8)

                // Кружок-позиция
                Circle()
                    .fill(Color.white)
                    .frame(width: isFocused ? 22 : 14, height: isFocused ? 22 : 14)
                    .shadow(color: .black.opacity(0.4), radius: isFocused ? 8 : 2)
                    .offset(x: max(0, min(w - (isFocused ? 22 : 14),
                                         w * frac - (isFocused ? 11 : 7))))
                    .animation(.easeOut(duration: 0.1), value: isFocused)
            }
            .animation(.easeOut(duration: 0.15), value: frac)
        }
        .frame(height: 32)
        .padding(.vertical, 4)
        .padding(.horizontal, 14)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(Color.white.opacity(isFocused ? 0.5 : 0.14), lineWidth: isFocused ? 2 : 1)
        )
        .contentShape(Rectangle())
        .focusable(true)
        .onMoveCommand { dir in
            guard isFocused else { return }
            // 10 сек за нажатие, 60 сек за долгое удержание (tvOS repeat)
            let step: Double = 10
            switch dir {
            case .left:
                let newVal = max(range.lowerBound, value - step)
                value = newVal
                onSeek(newVal)
            case .right:
                let newVal = min(range.upperBound, value + step)
                value = newVal
                onSeek(newVal)
            default:
                break
            }
        }
        // Клик по центру (select) — пауза/воспроизведение не нужна здесь,
        // handled in parent via prefersDefaultFocus on playPause
    }

    private var fraction: CGFloat {
        let total = max(range.upperBound - range.lowerBound, 1)
        let v = max(range.lowerBound, min(range.upperBound, value))
        return CGFloat((v - range.lowerBound) / total)
    }
}
