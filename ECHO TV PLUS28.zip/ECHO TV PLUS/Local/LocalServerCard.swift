import SwiftUI

struct LocalServerCard: View {
    let server: LocalServer
    @ObservedObject var lm = LanguageManager.shared

    private static let cardHeight: CGFloat = 260

    private var statusText: String {
        switch server.status {
        case .online: return lm.strings.localStatusOnline
        case .offline: return lm.strings.localStatusOffline
        case .unknown: return lm.strings.localStatusUnknown
        }
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Color.clear
                .background(.ultraThinMaterial)
                .cornerRadius(12)

            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top) {
                    Image(systemName: "externaldrive.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.white)

                    Spacer()

                    HStack(spacing: 6) {
                        LocalStatusDot(status: server.status)
                        Text(statusText)
                    }
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(.white.opacity(0.4))
                }
                .padding(24)

                Spacer()

                VStack(alignment: .leading, spacing: 6) {
                    Text(server.share.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? lm.strings.tabLocal : server.share)
                        .font(.system(size: 33, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 1)

                    HStack(spacing: 6) {
                        Image(systemName: "network")
                            .font(.system(size: 26))
                        Text(server.host)
                            .font(.system(size: 26, weight: .medium))
                    }
                    .foregroundColor(.white.opacity(0.4))
                    .lineLimit(1)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .frame(height: Self.cardHeight)
    }
}

struct LocalStatusDot: View {
    let status: LocalServer.Status

    var body: some View {
        Circle()
            .fill(color)
            .frame(width: 10, height: 10)
            .shadow(radius: status == .online ? 8 : 0)
    }

    private var color: Color {
        switch status {
        case .online: return .green
        case .offline: return .red
        case .unknown: return .gray.opacity(0.6)
        }
    }
}
