import SwiftUI

struct LocalConnectServerSheet: View {
    enum Mode {
        case add
        case edit(LocalServer)

        var serverId: UUID? {
            switch self {
            case .add: return nil
            case .edit(let s): return s.id
            }
        }
    }

    let mode: Mode

    @EnvironmentObject private var store: LocalServerStore
    @ObservedObject private var lm = LanguageManager.shared
    @Environment(\.dismiss) private var dismiss

    @State private var host: String = ""
    @State private var share: String = ""
    @State private var username: String = ""
    @State private var password: String = ""

    @State private var errorText: String?

    enum Field: Hashable { case host, share, username, password }
    @FocusState private var focusedField: Field?

    private static let headerFontSize: CGFloat = 40
    private static let windowWidth: CGFloat = 1000

    private var headerTitle: String {
        switch mode {
        case .add: return lm.strings.localConnectTitle
        case .edit: return lm.strings.localEditTitle
        }
    }

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                Text(headerTitle)
                    .font(.system(size: Self.headerFontSize, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 50)
                    .padding(.bottom, 30)

                VStack(spacing: 30) {
                    LabeledInputBlock(
                        label: lm.strings.localHostLabel,
                        placeholder: lm.strings.localHostPlaceholder,
                        text: $host,
                        isActive: focusedField == .host
                    )
                    .focused($focusedField, equals: .host)

                    LabeledInputBlock(
                        label: lm.strings.localShareLabel,
                        placeholder: lm.strings.localSharePlaceholder,
                        text: $share,
                        isActive: focusedField == .share
                    )
                    .focused($focusedField, equals: .share)

                    LabeledInputBlock(
                        label: lm.strings.localUsernameLabel,
                        placeholder: lm.strings.localUsernamePlaceholder,
                        text: $username,
                        isActive: focusedField == .username
                    )
                    .focused($focusedField, equals: .username)

                    LabeledSecureInputBlock(
                        label: lm.strings.localPasswordLabel,
                        placeholder: lm.strings.localPasswordPlaceholder,
                        text: $password,
                        isActive: focusedField == .password
                    )
                    .focused($focusedField, equals: .password)

                    if let errorText {
                        Text(errorText)
                            .font(.system(size: 22, weight: .medium))
                            .foregroundColor(.red.opacity(0.9))
                            .padding(.top, 10)
                    }
                }
                .padding(.horizontal, 60)
                .padding(.bottom, 40)

                HStack(spacing: 40) {
                    Button(action: { Task { await onSave() } }) {
                        Text(lm.strings.save).padding(.horizontal, 20)
                    }

                    Button(action: { dismiss() }) {
                        Text(lm.strings.cancel).padding(.horizontal, 20)
                    }
                }
                .padding(.horizontal, 60)
                .padding(.bottom, 50)
            }
            .frame(width: Self.windowWidth)
            .background(.ultraThinMaterial)
            .cornerRadius(16)

            if store.isBusy {
                ZStack {
                    Rectangle().fill(.regularMaterial)
                        .cornerRadius(16)
                    VStack(spacing: 16) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(1.2)
                        Text(lm.strings.loading)
                            .font(.title3)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                    }
                }
                .frame(width: Self.windowWidth)
            }
        }
        .onAppear {
            switch mode {
            case .add:
                host = ""
                share = ""
                username = ""
                password = ""
            case .edit(let s):
                host = s.host
                share = s.share
                username = s.username
                password = ""
            }
        }
    }

    private func onSave() async {
        errorText = nil

        let h = host.trimmingCharacters(in: .whitespacesAndNewlines)
        let s = share.trimmingCharacters(in: .whitespacesAndNewlines)
        let u = username.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !h.isEmpty, !s.isEmpty else {
            errorText = lm.strings.localErrorFillRequired
            return
        }

        do {
            switch mode {
            case .add:
                try await store.addServer(host: h, share: s, username: u, password: password)
                dismiss()
            case .edit(let existing):
                let passToSave: String? = password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : password
                try await store.updateServer(id: existing.id, host: h, share: s, username: u, password: passToSave)
                dismiss()
            }
        } catch {
            errorText = lm.strings.localErrorConnectFailed
        }
    }
}

private struct LabeledSecureInputBlock: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    var isActive: Bool

    private static let labelFontSize: CGFloat = 20
    private static let fieldFontSize: CGFloat = 32

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(label.uppercased())
                .font(.system(size: Self.labelFontSize, weight: .medium))
                .foregroundColor(.white.opacity(0.4))
                .padding(.leading, 4)

            SecureField(placeholder, text: $text)
                .padding(.horizontal, 5)
                .padding(.vertical, 5)
                .font(.system(size: Self.fieldFontSize, weight: .medium))
        }
    }
}
