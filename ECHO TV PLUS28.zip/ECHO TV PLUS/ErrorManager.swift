import SwiftUI
import Combine

@MainActor
final class ErrorManager: ObservableObject {
    static let shared = ErrorManager()
    
    @Published var isShowing = false
    @Published var message = ""
    
    private var hideTask: Task<Void, Never>?
    
    private init() {}
    
    func showError(_ msg: String, duration: TimeInterval = 4.0) {
        hideTask?.cancel()
        
        self.message = msg
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
            self.isShowing = true
        }
        
        hideTask = Task {
            try? await Task.sleep(nanoseconds: UInt64(duration * 1_000_000_000))
            guard !Task.isCancelled else { return }
            withAnimation(.easeInOut(duration: 0.3)) {
                self.isShowing = false
            }
        }
    }
}

struct ErrorBannerModifier: ViewModifier {
    @ObservedObject var errorManager = ErrorManager.shared
    
    func body(content: Content) -> some View {
        ZStack(alignment: .top) {
            content
            
            if errorManager.isShowing {
                HStack(spacing: 16) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 32))
                        .foregroundColor(.white)
                    
                    Text(errorManager.message)
                        .font(.system(size: 28, weight: .medium))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                }
                .padding(.vertical, 16)
                .padding(.horizontal, 32)
                .background(Color.red.opacity(0.85))
                .cornerRadius(16)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(.ultraThinMaterial)
                )
                .padding(.top, 60)
                .transition(.move(edge: .top).combined(with: .opacity))
                .zIndex(10)
            }
        }
    }
}

extension View {
    func withGlobalErrorBanner() -> some View {
        self.modifier(ErrorBannerModifier())
    }
}
