import SwiftUI
import UIKit

final class LogoImageCache {
    static let shared = LogoImageCache()
    private init() {}

    func image(for url: URL) async -> UIImage? {
        await ImageLoader.shared.load(url: url)
    }

    func clearMemory() {
        Task { await ImageLoader.shared.clearMemory() }
    }
}

struct OptimizedPosterView: View {
    let url: URL?
    let width: CGFloat
    let height: CGFloat

    @State private var loadedImage: UIImage?
    @State private var loadFailed = false

    var body: some View {
        ZStack {
            if let img = loadedImage {
                Image(uiImage: img)
                    .resizable()
                    .interpolation(.high)
                    .scaledToFill()
                    .frame(width: width, height: height)
                    .clipped()
            } else if loadFailed {
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: width, height: height)
                    .overlay(
                        Image(systemName: "film")
                            .foregroundColor(.white.opacity(0.5))
                    )
            } else {
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: width, height: height)
            }
        }
        .frame(width: width, height: height)
        .task(id: url) {
            await loadImage()
        }
    }

    private func loadImage() async {
        guard let url else {
            loadFailed = true
            return
        }
        loadedImage = nil
        loadFailed = false

        if let img = await LogoImageCache.shared.image(for: url) {
            loadedImage = img
        } else {
            loadFailed = true
        }
    }
}
