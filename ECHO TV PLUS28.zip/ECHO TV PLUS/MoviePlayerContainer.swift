import SwiftUI
import AVKit

struct MoviePlayerContainer: UIViewControllerRepresentable {
    let player: AVPlayer?
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var favoritesManager: FavoritesManager
    @Binding var showArchive: Bool

    func makeUIViewController(context: Context) -> NativeMoviePlayerViewController {
        let controller = playerManager.obtainMovieController()
        controller.player = player
        controller.showsPlaybackControls = true
        controller.allowsPictureInPicturePlayback = true
        controller.requiresLinearPlayback = false
        controller.transportBarIncludesTitleView = true
        controller.playerManager = playerManager

        updateCustomControls(controller)
        return controller
    }

    func updateUIViewController(_ uiViewController: NativeMoviePlayerViewController, context: Context) {
        if uiViewController.player != player {
            uiViewController.player = player
        }
        uiViewController.playerManager = playerManager
        uiViewController.allowsPictureInPicturePlayback = true
        updateCustomControls(uiViewController)
    }

    func updateCustomControls(_ controller: AVPlayerViewController) {
        let lm = LanguageManager.shared
        var actions: [UIAction] = []

        if playerManager.mode == .archive {
            let listAction = UIAction(
                title: lm.strings.btnArchiveMenu,
                image: UIImage(systemName: "list.bullet")
            ) { _ in
                self.showArchive = true
            }
            actions.append(listAction)
        } else {
            if let current = playerManager.currentChannel {
                let isFav = favoritesManager.isFavorite(current)
                let favAction = UIAction(
                    title: isFav ? lm.strings.ctxRemoveFav : lm.strings.ctxAddFav,
                    image: UIImage(systemName: isFav ? "heart.fill" : "heart")
                ) { [weak favoritesManager] _ in
                    favoritesManager?.toggleFavorite(current)
                    self.updateCustomControls(controller)
                }
                actions.append(favAction)
            }

            let muteAction = UIAction(
                title: playerManager.isMuted ? lm.strings.ctxUnmute : lm.strings.ctxMute,
                image: UIImage(systemName: playerManager.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
            ) { [weak playerManager] _ in
                playerManager?.toggleMute()
                self.updateCustomControls(controller)
            }
            actions.append(muteAction)
        }

        controller.transportBarCustomMenuItems = actions
    }
}

final class NativeMoviePlayerViewController: AVPlayerViewController {
    weak var playerManager: PlayerManager?

    override func pressesBegan(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        guard let manager = playerManager else {
            super.pressesBegan(presses, with: event)
            return
        }

        for press in presses where press.type == .menu {
            if manager.mode == .archive {
                manager.returnToLive()
                return
            }

            if !showsPlaybackControls {
                manager.dismissPlayerUI()
                return
            }
        }
        super.pressesBegan(presses, with: event)
    }
}
