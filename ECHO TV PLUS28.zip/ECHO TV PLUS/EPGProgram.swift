import Foundation

struct EPGProgram: Identifiable, Codable, Equatable {
    var id = UUID()
    let title: String
    let desc: String?
    let start: Date
    let stop: Date

    private static let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        f.locale = Locale(identifier: "en_US_POSIX")
        return f
    }()

    var timeRange: String {
        "\(Self.formatter.string(from: start)) - \(Self.formatter.string(from: stop))"
    }
}
