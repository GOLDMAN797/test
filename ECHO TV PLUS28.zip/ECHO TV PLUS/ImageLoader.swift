import UIKit

actor ImageLoader {
    static let shared = ImageLoader()

    private var activeCount = 0
    private let maxConcurrent = 5
    private var waiting: [CheckedContinuation<Void, Never>] = []

    private let cache = NSCache<NSURL, UIImage>()

    private init() {
        cache.countLimit = 400
        // FIX: adaptive memory limit — 200 MB on Apple TV 4K (3 GB RAM), 120 MB on older models
        let physicalMemory = ProcessInfo.processInfo.physicalMemory
        cache.totalCostLimit = physicalMemory > 2_000_000_000 ? 200 * 1024 * 1024 : 120 * 1024 * 1024
    }

    func load(url: URL) async -> UIImage? {
        if let cached = cache.object(forKey: url as NSURL) {
            return cached
        }

        await waitForSlot()
        defer { Task { await releaseSlot() } }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard let image = UIImage(data: data) else { return nil }
            cache.setObject(image, forKey: url as NSURL)
            return image
        } catch {
            return nil
        }
    }

    func clearCache() {
        cache.removeAllObjects()
    }

    func clearMemory() {
        clearCache()
    }

    private func waitForSlot() async {
        if activeCount < maxConcurrent {
            activeCount += 1
            return
        }

        await withCheckedContinuation { continuation in
            waiting.append(continuation)
        }
        activeCount += 1
    }

    private func releaseSlot() {
        activeCount = max(0, activeCount - 1)

        if !waiting.isEmpty {
            let first = waiting.removeFirst()
            first.resume()
        }
    }
}
