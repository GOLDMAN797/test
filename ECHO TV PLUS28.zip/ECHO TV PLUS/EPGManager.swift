import Foundation
import Combine
import UIKit
import zlib

@MainActor
final class EPGManager: NSObject, ObservableObject {
    @Published var programs: [String: [EPGProgram]] = [:]
    @Published var channelLogos: [String: String] = [:]
    @Published var minuteTick: Int = Int(Date().timeIntervalSince1970 / 60)
    @Published var epgDataTick: Int = 0

    private var epgCache: [String: Date] = [:]
    private var channelNameMap: [String: String] = [:]
    private var normalizedNameCache: [String: String] = [:]
    private var strippedNameCache: [String: String] = [:]

    private var fuzzySearchDidRun: Set<String> = []
    private var fuzzyMatchCache: [String: String] = [:]

    private var inFlight: [String: Task<Void, Never>] = [:]
    private var requestIDs: [String: UUID] = [:]

    private var updateDebouncer: Task<Void, Never>?
    private var pendingUpdates: (programs: [String: [EPGProgram]], logos: [String: String], names: [String: String])?

    private var memoryWarningCancellable: AnyCancellable?
    private var minuteTickerTask: Task<Void, Never>?
    private var minuteTickerCancellable: AnyCancellable?

    private let cacheTTL: TimeInterval = 3600
    private let windowPast: TimeInterval = 7 * 86400
    private let windowFuture: TimeInterval = 2 * 86400

    private static let downloadLimiter = AsyncSemaphore(permits: 2)
    private static let parseLimiter = AsyncSemaphore(permits: 1)

    private lazy var session: URLSession = {
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 30
        cfg.timeoutIntervalForResource = 240
        cfg.waitsForConnectivity = true
        cfg.requestCachePolicy = .returnCacheDataElseLoad
        cfg.urlCache = URLCache.shared
        return URLSession(configuration: cfg)
    }()

    override init() {
        super.init()
        setupMemoryWarningObserver()
        startMinuteTicker()
    }

    deinit {
        minuteTickerTask?.cancel()
        minuteTickerCancellable?.cancel()
        memoryWarningCancellable?.cancel()
        inFlight.values.forEach { $0.cancel() }
    }

    private func setupMemoryWarningObserver() {
        memoryWarningCancellable = NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)
            .sink { [weak self] _ in
                Task { @MainActor in
                    self?.handleMemoryWarning()
                }
            }
    }

    private func startMinuteTicker() {
        minuteTickerTask?.cancel()
        minuteTickerCancellable?.cancel()

        minuteTickerTask = Task { [weak self] in
            guard let self else { return }

            let now = Date()
            let nextMinute = Calendar.current.nextDate(
                after: now,
                matching: DateComponents(second: 0),
                matchingPolicy: .nextTimePreservingSmallerComponents
            ) ?? now.addingTimeInterval(60)

            let delay = max(0, nextMinute.timeIntervalSince(now))
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard !Task.isCancelled else { return }

            await MainActor.run {
                self.minuteTick = Int(Date().timeIntervalSince1970 / 60)
                self.minuteTickerCancellable = Timer.publish(every: 60, on: .main, in: .common)
                    .autoconnect()
                    .sink { [weak self] _ in
                        guard let self else { return }
                        self.minuteTick = Int(Date().timeIntervalSince1970 / 60)
                    }
            }
        }
    }

    private func handleMemoryWarning() {
        let now = Date()
        let cutoffPast = now.addingTimeInterval(-windowPast)
        let cutoffFuture = now.addingTimeInterval(windowFuture)

        for (channelId, list) in programs {
            let freshPrograms = list.filter { $0.stop > cutoffPast && $0.start < cutoffFuture }
            if freshPrograms.isEmpty {
                programs.removeValue(forKey: channelId)
            } else {
                programs[channelId] = freshPrograms
            }
        }

        fuzzyMatchCache.removeAll()
        normalizedNameCache.removeAll()
        strippedNameCache.removeAll()
        fuzzySearchDidRun.removeAll()
    }

    func clearAll() {
        programs = [:]
        channelLogos = [:]
        channelNameMap = [:]
        epgCache = [:]
        normalizedNameCache = [:]
        strippedNameCache = [:]
        fuzzySearchDidRun = []
        fuzzyMatchCache = [:]

        inFlight.values.forEach { $0.cancel() }
        inFlight = [:]
        requestIDs = [:]
        updateDebouncer?.cancel()
        pendingUpdates = nil
    }

    func fetchEPG(url urlString: String, forceRefresh: Bool = false) {
        let urls = urlString.components(separatedBy: ",")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        guard !urls.isEmpty else { return }

        for u in urls {
            fetchSingleEPG(url: u, forceRefresh: forceRefresh)
        }
    }

    private func fetchSingleEPG(url urlString: String, forceRefresh: Bool) {
        let key = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }

        if !forceRefresh,
           let last = epgCache[key],
           Date().timeIntervalSince(last) < cacheTTL {
            return
        }

        if !forceRefresh, inFlight[key] != nil {
            return
        }

        if forceRefresh, let running = inFlight[key] {
            running.cancel()
            inFlight[key] = nil
            fuzzyMatchCache.removeAll()
        }

        let candidates = urlCandidates(for: key)
        guard !candidates.isEmpty else { return }

        let requestID = UUID()
        requestIDs[key] = requestID

        let task = Task { [weak self] in
            guard let self else { return }
            defer {
                if self.requestIDs[key] == requestID {
                    self.inFlight[key] = nil
                }
            }

            for candidate in candidates {
                guard !Task.isCancelled else { return }
                guard self.requestIDs[key] == requestID else { return }

                do {
                    try await EPGManager.downloadLimiter.acquire()
                    let localURL: URL
                    let response: URLResponse
                    do {
                        var req = URLRequest(url: candidate, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 240)
                        req.setValue("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36", forHTTPHeaderField: "User-Agent")
                        (localURL, response) = try await self.session.download(for: req)
                    } catch {
                        await EPGManager.downloadLimiter.release()
                        throw error
                    }
                    await EPGManager.downloadLimiter.release()

                    defer { try? FileManager.default.removeItem(at: localURL) }

                    if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                        throw URLError(.badServerResponse)
                    }

                    let parsed = try await Task.detached(priority: .userInitiated) { () async throws -> ParsedEPG in
                        await EPGManager.parseLimiter.acquire()
                        defer { Task { await EPGManager.parseLimiter.release() } }

                        return try autoreleasepool {
                            let now = Date()
                            let cutoffPast = now.addingTimeInterval(-self.windowPast)
                            let cutoffFuture = now.addingTimeInterval(self.windowFuture)

                            let xmlURL = try EPGManager.prepareXMLFile(from: localURL, hintedBy: candidate)
                            if try EPGManager.looksLikeHTML(xmlURL) {
                                throw URLError(.cannotParseResponse)
                            }

                            guard let parser = XMLParser(contentsOf: xmlURL) else {
                                throw URLError(.cannotParseResponse)
                            }

                            let delegate = EPGParserDelegate(cutoffPast: cutoffPast, cutoffFuture: cutoffFuture, now: now)
                            parser.delegate = delegate

                            let ok = parser.parse()
                            if !ok {
                                throw parser.parserError ?? NSError(domain: "EPGParser", code: -1, userInfo: [NSLocalizedDescriptionKey: "XML parse failed"])
                            }

                            return delegate.makeResult()
                        }
                    }.value

                    guard !Task.isCancelled else { return }
                    guard self.requestIDs[key] == requestID else { return }

                    await self.applyBatchedUpdate(parsed: parsed, sourceURL: key)
                    return
                } catch {
                    continue
                }
            }
        }

        inFlight[key] = task
    }

    private func urlCandidates(for urlString: String) -> [URL] {
        guard let url = URL(string: urlString) else { return [] }
        if url.scheme?.lowercased() == "http" {
            if var comps = URLComponents(url: url, resolvingAgainstBaseURL: false) {
                comps.scheme = "https"
                if let https = comps.url { return [https, url] }
            }
        }
        return [url]
    }

    private func applyBatchedUpdate(parsed: ParsedEPG, sourceURL: String) async {
        if pendingUpdates == nil {
            pendingUpdates = ([:], [:], [:])
        }

        pendingUpdates?.programs.merge(parsed.programs) { _, new in new }
        pendingUpdates?.logos.merge(parsed.logos) { old, _ in old }
        pendingUpdates?.names.merge(parsed.names) { old, _ in old }

        updateDebouncer?.cancel()

        updateDebouncer = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 120_000_000)
            guard !Task.isCancelled else { return }
            guard let self, let pending = self.pendingUpdates else { return }

            var newPrograms = self.programs
            var newLogos = self.channelLogos
            var newNames = self.channelNameMap

            newPrograms.merge(pending.programs) { _, new in new }
            newLogos.merge(pending.logos) { old, _ in old }

            newNames.merge(pending.names) { oldId, newId in
                let oldHasLogo = newLogos[oldId] != nil
                let newHasLogo = newLogos[newId] != nil
                if oldHasLogo && !newHasLogo { return oldId }
                if !oldHasLogo && newHasLogo { return newId }
                return oldId
            }

            self.programs = newPrograms
            self.channelLogos = newLogos
            self.channelNameMap = newNames
            self.epgCache[sourceURL] = Date()

            self.fuzzySearchDidRun.removeAll()
            self.fuzzyMatchCache.removeAll()

            self.pendingUpdates = nil
            self.epgDataTick &+= 1
        }
    }

    func getPrograms(for channel: Channel) -> [EPGProgram] {
        if let id = channel.epgId, !id.isEmpty, let list = programs[id] { return list }

        let normalizedName = getCachedNormalizedName(channel.name)
        if let mappedId = channelNameMap[normalizedName], let list = programs[mappedId] { return list }

        let strippedName = getCachedStrippedName(channel.name)
        if let mappedId = channelNameMap[strippedName], let list = programs[mappedId] { return list }

        return []
    }

    func getCurrentAndNextProgram(for channel: Channel) -> (current: String, next: String) {
        let finalPrograms = getPrograms(for: channel)
        let lm = LanguageManager.shared
        guard !finalPrograms.isEmpty else { return (lm.strings.epgNoInfo, "") }

        let now = Date()
        var currentText = lm.strings.epgNoProgram
        var nextText = ""

        if let currentProg = finalPrograms.first(where: { $0.start <= now && $0.stop > now }) {
            currentText = "\(currentProg.timeRange) \(currentProg.title)"
        }
        if let nextProg = finalPrograms.first(where: { $0.start > now }) {
            nextText = "\(lm.strings.epgNextPrefix) \(nextProg.timeRange) \(nextProg.title)"
        }
        return (currentText, nextText)
    }

    func getSmartLogo(for channel: Channel) -> String? {
        if let id = channel.epgId, !id.isEmpty, let logo = channelLogos[id] { return logo }

        let normalizedName = getCachedNormalizedName(channel.name)
        if let mappedId = channelNameMap[normalizedName], let logo = channelLogos[mappedId] { return logo }

        let strippedName = getCachedStrippedName(channel.name)
        if let mappedId = channelNameMap[strippedName], let logo = channelLogos[mappedId] { return logo }

        if let fuzzyId = performFuzzySearch(for: strippedName), let logo = channelLogos[fuzzyId] { return logo }
        return nil
    }

    private func performFuzzySearch(for strippedName: String) -> String? {
        guard strippedName.count > 3 else { return nil }
        if let cached = fuzzyMatchCache[strippedName] { return cached }
        if fuzzySearchDidRun.contains(strippedName) { return nil }

        fuzzySearchDidRun.insert(strippedName)

        let keys = channelNameMap.keys.sorted()
        var bestId: String?
        var bestLen: Int = -1
        var secondBestLen: Int = -1

        for k in keys {
            guard k.count > 3 else { continue }
            if strippedName.contains(k) || k.contains(strippedName) {
                let len = min(k.count, strippedName.count)
                if len > bestLen {
                    secondBestLen = bestLen
                    bestLen = len
                    bestId = channelNameMap[k]
                } else if len > secondBestLen {
                    secondBestLen = len
                }
            }
        }

        guard let id = bestId else { return nil }
        guard bestLen >= 6 else { return nil }
        if secondBestLen >= 0, bestLen <= secondBestLen + 1 { return nil }

        fuzzyMatchCache[strippedName] = id
        return id
    }

    private func getCachedNormalizedName(_ name: String) -> String {
        if let cached = normalizedNameCache[name] { return cached }
        let normalized = EPGNameNormalizer.normalize(name)
        normalizedNameCache[name] = normalized
        return normalized
    }

    private func getCachedStrippedName(_ name: String) -> String {
        if let cached = strippedNameCache[name] { return cached }
        let stripped = EPGNameNormalizer.safeStrip(name)
        strippedNameCache[name] = stripped
        return stripped
    }

    private nonisolated static func looksLikeHTML(_ url: URL) throws -> Bool {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        let data = try h.read(upToCount: 256) ?? Data()
        if data.isEmpty { return false }
        let s = String(data: data, encoding: .utf8) ?? ""
        return s.contains("<!DOCTYPE html") || s.contains("<html")
    }

    private nonisolated static func isXMLFile(_ url: URL) throws -> Bool {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        let data = try h.read(upToCount: 512) ?? Data()
        if data.isEmpty { return false }

        var i = 0
        while i < data.count {
            let b = data[i]
            if b == 0x20 || b == 0x0A || b == 0x0D || b == 0x09 { i += 1; continue }
            return b == 0x3C
        }
        return false
    }

    private nonisolated static func isGzipMagic(_ url: URL) throws -> Bool {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        let data = try h.read(upToCount: 2) ?? Data()
        return data.count == 2 && data[0] == 0x1f && data[1] == 0x8b
    }

    private nonisolated static func prepareXMLFile(from localURL: URL, hintedBy remoteURL: URL) throws -> URL {
        if try isXMLFile(localURL) { return localURL }

        let outURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("xml")

        let shouldTryGzip = remoteURL.absoluteString.lowercased().hasSuffix(".gz") || ((try? isGzipMagic(localURL)) ?? false)

        if shouldTryGzip {
            if let xml = try? gunzipToTempXML(gzURL: localURL, outURL: outURL) {
                return xml
            }
        }

        return try inflateAutoToTempXML(srcURL: localURL, outURL: outURL)
    }

    private nonisolated static func gunzipToTempXML(gzURL: URL, outURL: URL) throws -> URL {
        guard let gz = gzopen(gzURL.path, "rb") else { throw URLError(.cannotOpenFile) }
        defer { gzclose(gz) }

        guard let out = fopen(outURL.path, "wb") else { throw URLError(.cannotCreateFile) }
        defer { fclose(out) }

        let bufferSize = 64 * 1024
        let buf = UnsafeMutablePointer<UInt8>.allocate(capacity: bufferSize)
        defer { buf.deallocate() }

        var wroteAny = false

        while true {
            let readCount = gzread(gz, buf, UInt32(bufferSize))
            if readCount > 0 {
                wroteAny = true
                _ = fwrite(buf, 1, Int(readCount), out)
            } else if readCount == 0 {
                break
            } else {
                throw URLError(.cannotDecodeContentData)
            }
        }

        if !wroteAny { throw URLError(.cannotDecodeContentData) }
        return outURL
    }

    private nonisolated static func inflateAutoToTempXML(srcURL: URL, outURL: URL) throws -> URL {
        guard let inFile = fopen(srcURL.path, "rb") else { throw URLError(.cannotOpenFile) }
        defer { fclose(inFile) }

        guard let outFile = fopen(outURL.path, "wb") else { throw URLError(.cannotCreateFile) }
        defer { fclose(outFile) }

        var stream = z_stream()
        stream.zalloc = nil
        stream.zfree = nil
        stream.opaque = nil

        let windowBits: Int32 = 47
        let streamSize = Int32(MemoryLayout<z_stream>.size)
        let initResult = inflateInit2_(&stream, windowBits, ZLIB_VERSION, streamSize)
        guard initResult == Z_OK else { throw URLError(.cannotDecodeContentData) }
        defer { inflateEnd(&stream) }

        let inBufSize = 64 * 1024
        let outBufSize = 64 * 1024

        let inBuf = UnsafeMutablePointer<UInt8>.allocate(capacity: inBufSize)
        let outBuf = UnsafeMutablePointer<UInt8>.allocate(capacity: outBufSize)
        defer {
            inBuf.deallocate()
            outBuf.deallocate()
        }

        var wroteAny = false

        while true {
            let readCount = fread(inBuf, 1, inBufSize, inFile)
            if readCount > 0 {
                stream.next_in = inBuf
                stream.avail_in = UInt32(readCount)

                while stream.avail_in > 0 {
                    stream.next_out = outBuf
                    stream.avail_out = UInt32(outBufSize)

                    let status = inflate(&stream, Z_NO_FLUSH)
                    let produced = outBufSize - Int(stream.avail_out)

                    if produced > 0 {
                        wroteAny = true
                        _ = fwrite(outBuf, 1, produced, outFile)
                    }

                    if status == Z_STREAM_END {
                        if !wroteAny { throw URLError(.cannotDecodeContentData) }
                        return outURL
                    }

                    if status != Z_OK {
                        throw URLError(.cannotDecodeContentData)
                    }
                }
            } else {
                break
            }
        }

        if !wroteAny { throw URLError(.cannotDecodeContentData) }
        return outURL
    }
}

actor AsyncSemaphore {
    private var permits: Int
    private var waiters: [CheckedContinuation<Void, Never>] = []

    init(permits: Int) {
        self.permits = max(0, permits)
    }

    func acquire() async {
        if permits > 0 {
            permits -= 1
            return
        }
        await withCheckedContinuation { cont in
            waiters.append(cont)
        }
    }

    func release() async {
        if !waiters.isEmpty {
            let c = waiters.removeFirst()
            c.resume()
            return
        }
        permits += 1
    }
}

struct EPGNameNormalizer {
    nonisolated static func normalize(_ name: String) -> String {
        name.lowercased().filter { $0.isLetter || $0.isNumber || $0 == "+" }
    }

    nonisolated static func safeStrip(_ name: String) -> String {
        var s = name.lowercased()
        if let range = s.range(of: "\\(.*?\\)", options: .regularExpression) {
            s.removeSubrange(range)
        }

        let junk = [
            " hd", " fhd", " uhd", " 4k", " 8k",
            " tv", " channel", " live", " raw",
            " ru", " int", " international",
            " vip", " premium", " backup", " original"
        ]
        for item in junk { s = s.replacingOccurrences(of: item, with: "") }

        return s.filter { $0.isLetter || $0.isNumber || $0 == "+" }
    }
}

struct ParsedEPG: Sendable {
    let programs: [String: [EPGProgram]]
    let logos: [String: String]
    let names: [String: String]
}

final class EPGParserDelegate: NSObject, XMLParserDelegate, @unchecked Sendable {
    private var programs: [String: [EPGProgram]] = [:]
    private var logos: [String: String] = [:]
    private var names: [String: String] = [:]

    private var currentElement = ""
    private var currentChannelId = ""
    private var currentTitle = ""
    private var currentDescription = ""
    private var currentDisplayName = ""
    private var currentStart: Date?
    private var currentStop: Date?

    private let cutoffPast: Date
    private let cutoffFuture: Date
    private let now: Date

    init(cutoffPast: Date, cutoffFuture: Date, now: Date) {
        self.cutoffPast = cutoffPast
        self.cutoffFuture = cutoffFuture
        self.now = now
        super.init()
    }

    private let dateFormatter: DateFormatter = {
        let df = DateFormatter()
        df.dateFormat = "yyyyMMddHHmmss Z"
        df.locale = Locale(identifier: "en_US_POSIX")
        return df
    }()

    func makeResult() -> ParsedEPG {
        for key in programs.keys {
            programs[key]?.sort { $0.start < $1.start }
        }
        return ParsedEPG(programs: programs, logos: logos, names: names)
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        currentElement = elementName
        if elementName == "channel" {
            currentChannelId = attributeDict["id"] ?? ""
        } else if elementName == "icon", !currentChannelId.isEmpty {
            if let src = attributeDict["src"] { logos[currentChannelId] = src }
        } else if elementName == "programme" {
            currentChannelId = attributeDict["channel"] ?? ""
            currentTitle = ""
            currentDescription = ""
            currentStart = nil
            currentStop = nil
            if let startStr = attributeDict["start"], let stopStr = attributeDict["stop"] {
                currentStart = dateFormatter.date(from: startStr)
                currentStop = dateFormatter.date(from: stopStr)
            }
        } else if elementName == "display-name" {
            currentDisplayName = ""
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if currentElement == "title" { currentTitle += string }
        else if currentElement == "desc" { currentDescription += string }
        else if currentElement == "display-name" { currentDisplayName += string }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "programme" {
            let start = currentStart ?? Date.distantPast
            let stop = currentStop ?? Date.distantFuture

            guard stop > cutoffPast, start < cutoffFuture else { return }

            let title = currentTitle.trimmingCharacters(in: .whitespacesAndNewlines)

            let keepDesc = (stop > now.addingTimeInterval(-3600)) && (start < now.addingTimeInterval(6 * 3600))
            let descRaw = keepDesc ? currentDescription.trimmingCharacters(in: .whitespacesAndNewlines) : ""
            let desc = descRaw.isEmpty ? nil : descRaw

            let p = EPGProgram(title: title, desc: desc, start: start, stop: stop)
            programs[currentChannelId, default: []].append(p)
        } else if elementName == "display-name" {
            guard !currentChannelId.isEmpty else { return }

            let dn = currentDisplayName.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !dn.isEmpty else { return }

            let normalized = EPGNameNormalizer.normalize(dn)
            if !normalized.isEmpty { names[normalized] = currentChannelId }

            let stripped = EPGNameNormalizer.safeStrip(dn)
            if !stripped.isEmpty && stripped != normalized { names[stripped] = currentChannelId }

            currentDisplayName = ""
        }
    }
}
