import SwiftUI

struct BackgroundClearView: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        DispatchQueue.main.async { view.superview?.superview?.backgroundColor = .clear }
        return view
    }
    func updateUIView(_ uiView: UIView, context: Context) {}
}

struct NativeChannelListView: View {
    let channels: [Channel]
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var epgManager: EPGManager
    var currentId: String? { playerManager.currentChannel?.id }
    
    var body: some View {
        ScrollViewReader { proxy in
            List(channels) { channel in
                Button {
                    playerManager.playChannel(channel)
                } label: {
                    HStack(spacing: 20) {
                        Image(systemName: "chevron.right")
                            .font(.caption)
                            .opacity(currentId == channel.id ? 1 : 0)
                        Text(channel.name)
                            .font(.body)
                            .lineLimit(1)
                        Text(epgManager.getCurrentAndNextProgram(for: channel).current)
                            .font(.caption)
                            .lineLimit(1)
                            .foregroundColor(.secondary)
                    }
                }
                .buttonStyle(.glass)
                .listRowInsets(EdgeInsets(top: 0, leading: 12, bottom: 0, trailing: 12))
                .id(channel.id)
            }
            .listStyle(.plain)
            .environment(\.defaultMinListRowHeight, 32)
            .onAppear {
                if let id = currentId {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { proxy.scrollTo(id, anchor: .center) }
                }
            }
        }
    }
}
