import SwiftUI

struct PlayerView: View {
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var epgManager: EPGManager
    @ObservedObject var favoritesManager: FavoritesManager
    @ObservedObject var lm = LanguageManager.shared

    @State private var epgUpdateTimer: Timer?
    @State private var showArchive: Bool = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if playerManager.showPlayer {
                Group {
                    if playerManager.isLive {
                        LivePlayerContainer(
                            player: playerManager.player,
                            playerManager: playerManager,
                            favoritesManager: favoritesManager,
                            epgManager: epgManager,
                            showArchive: $showArchive
                        )
                    } else {
                        MoviePlayerContainer(
                            player: playerManager.player,
                            playerManager: playerManager,
                            favoritesManager: favoritesManager,
                            showArchive: $showArchive
                        )
                    }
                }
                .ignoresSafeArea()
            }
        }
        .fullScreenCover(isPresented: $showArchive) {
            if let channel = playerManager.currentChannel {
                ArchiveView(
                    channel: channel,
                    playerManager: playerManager,
                    epgManager: epgManager
                )
                .background(BackgroundClearView())
            }
        }
        .onAppear {
            if playerManager.isLive {
                updateEPG()
                startEPGUpdateTimer()
            }
        }
        .onDisappear {
            stopEPGUpdateTimer()
            if !playerManager.isPiPActive {
                playerManager.stop()
            }
        }
        .onChange(of: playerManager.currentChannel?.id) { _, _ in
            guard playerManager.isLive else { return }
            stopEPGUpdateTimer()
            updateEPG()
            startEPGUpdateTimer()
        }
        .onChange(of: playerManager.isLive) { _, isLiveNow in
            stopEPGUpdateTimer()
            if isLiveNow {
                updateEPG()
                startEPGUpdateTimer()
            }
        }
        .alert(lm.strings.alertPlaybackTitle, isPresented: $playerManager.showResumeAlert) {
            Button("\(lm.strings.btnResume) \(formatTime(playerManager.pendingResumeTime))") {
                playerManager.resumeVideo()
            }
            Button(lm.strings.btnStartOver) {
                playerManager.startOver()
            }
            Button(lm.strings.cancel, role: .cancel) {
                playerManager.stop()
            }
        } message: {
            Text(lm.strings.alertResumeMessage)
        }
    }

    private func updateEPG() {
        guard let channel = playerManager.currentChannel else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { [weak playerManager, weak epgManager] in
            guard let pm = playerManager, let em = epgManager else { return }
            guard pm.isLive, pm.showPlayer else { return }
            guard pm.currentChannel?.id == channel.id else { return }

            let programs = em.getCurrentAndNextProgram(for: channel)
            pm.updateMetadata(
                channelName: channel.name,
                currentProgram: programs.current,
                nextProgram: programs.next
            )
        }
    }

    private func startEPGUpdateTimer() {
        stopEPGUpdateTimer()
        // FIX: reduced from 300s to 60s — getCurrentAndNextProgram is cheap (in-memory lookup)
        let timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak playerManager, weak epgManager] _ in
            guard let pm = playerManager, let em = epgManager else { return }
            guard pm.isLive, pm.showPlayer else { return }
            guard let channel = pm.currentChannel else { return }

            let programs = em.getCurrentAndNextProgram(for: channel)
            pm.updateMetadata(
                channelName: channel.name,
                currentProgram: programs.current,
                nextProgram: programs.next
            )
        }
        epgUpdateTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    private func stopEPGUpdateTimer() {
        epgUpdateTimer?.invalidate()
        epgUpdateTimer = nil
    }

    private func formatTime(_ seconds: Double) -> String {
        let h = Int(seconds) / 3600
        let m = (Int(seconds) % 3600) / 60
        let s = Int(seconds) % 60
        if h > 0 {
            return String(format: "%02d:%02d:%02d", h, m, s)
        }
        return String(format: "%02d:%02d", m, s)
    }
}
