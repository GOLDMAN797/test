import SwiftUI
import AVFoundation

struct PlaylistsView: View {
    @ObservedObject var playlistManager: PlaylistManager
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var favoritesManager: FavoritesManager
    @ObservedObject var lm = LanguageManager.shared
    @ObservedObject private var historyService = PlaybackHistoryService.shared
    
    @State private var playlistToEdit: Playlist?
    @State private var playlistToDelete: Playlist?

    @State private var movieInfoChannel: Channel?
    @State private var selectedChannelForAdd: Channel?
    @State private var showAddToPlaylistDialog = false

    private static let columns = [
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40)
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 55) {
                let continueItems = historyService.getContinueWatching()
                if !continueItems.isEmpty {
                    VStack(alignment: .leading, spacing: 22) {
                        Text(lm.strings.continueWatching)
                            .font(.system(size: 38, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.leading, 60)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            LazyHStack(spacing: 28) {
                                ForEach(continueItems) { movie in
                                    let channel = Channel(
                                        name: movie.title,
                                        url: movie.url,
                                        group: "Movie"
                                    )

                                    ContinueWatchingCard(movie: movie, playerManager: playerManager)
                                        .contextMenu {
                                            ContinueWatchingContextMenuContent(
                                                movie: movie,
                                                channel: channel,
                                                favoritesManager: favoritesManager,
                                                onInfo: { movieInfoChannel = channel },
                                                onAddToPlaylist: {
                                                    selectedChannelForAdd = channel
                                                    showAddToPlaylistDialog = true
                                                },
                                                onRemoveFromWatchLater: {
                                                    historyService.remove(url: movie.url)
                                                }
                                            )
                                        }
                                }
                            }
                            .padding(.horizontal, 80)
                        }
                    }
                }
                
                if !playlistManager.playlists.isEmpty {
                    LazyVGrid(columns: Self.columns, spacing: 60) {
                        ForEach(playlistManager.playlists) { playlist in
                            NavigationLink(destination: PlaylistDetailView(
                                playlist: playlist,
                                playlistManager: playlistManager,
                                playerManager: playerManager,
                                favoritesManager: favoritesManager
                            )) {
                                PlaylistCard(playlist: playlist)
                            }
                            .id(playlist.id)
                            .buttonStyle(.card)
                            .contextMenu {
                                Button { playlistToEdit = playlist } label: {
                                    Label(lm.strings.btnEdit, systemImage: "pencil")
                                }
                                Button(role: .destructive) { playlistToDelete = playlist } label: {
                                    Label(lm.strings.btnDelete, systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 80)
                    .padding(.bottom, 80)
                    .padding(.top, 20)
                } else {
                    emptyStateView
                }
            }
            .padding(.top, 40)
        }
        .onAppear {
            if playlistManager.playlists.isEmpty && !playlistManager.isLoading {
                playlistManager.refreshAllPlaylists()
            }
        }
        .sheet(item: $movieInfoChannel) { channel in
            MovieInfoSheet(channel: channel)
        }
        .confirmationDialog(
            lm.strings.dialogAddChannel,
            isPresented: $showAddToPlaylistDialog,
            titleVisibility: .visible
        ) {
            if let channel = selectedChannelForAdd {
                ForEach(playlistManager.playlists) { pl in
                    Button(pl.name) {
                        playlistManager.addChannel(channel, to: pl.id)
                        selectedChannelForAdd = nil
                    }
                }
            }
            Button(lm.strings.cancel, role: .cancel) {
                selectedChannelForAdd = nil
            }
        }
        .alert(item: $playlistToDelete) { playlist in
            Alert(
                title: Text(lm.strings.deleteTitle),
                message: Text("\(lm.strings.deleteMessage) '\(playlist.name)'?"),
                primaryButton: .destructive(Text(lm.strings.deleteConfirm)) {
                    playlistManager.deletePlaylist(playlist)
                },
                secondaryButton: .cancel(Text(lm.strings.cancel))
            )
        }
        .fullScreenCover(item: $playlistToEdit) { playlist in
            PlaylistFormView(mode: .edit(playlist), playlistManager: playlistManager)
        }
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 30) {
            Image(systemName: "tv.slash")
                .font(.system(size: 100))
                .foregroundColor(.white.opacity(0.2))
            Text(lm.strings.emptyPlaylists)
                .font(.title3)
                .foregroundColor(.white.opacity(0.4))
        }
        .padding(.top, 100)
    }
}

struct PlaylistCard: View {
    let playlist: Playlist
    @ObservedObject var lm = LanguageManager.shared
 
    private static let cardHeight: CGFloat = 260
    
    private var updateDateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        return formatter.string(from: playlist.lastUpdated)
    }
 
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Color.clear
                .background(.ultraThinMaterial)
                .cornerRadius(12)
            
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .top) {
                    ZStack {
                        Image(systemName: "tv")
                            .font(.system(size: 60))
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
 
                    HStack(spacing: 6) {
                        Image(systemName: "arrow.down.to.line.compact")
                        Text(updateDateString)
                    }
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(.white.opacity(0.4))
                }
                .padding(24)
                
                Spacer()
                
                VStack(alignment: .leading, spacing: 6) {
                    Text(playlist.name)
                        .font(.system(size: 33, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 1)
                    
                    HStack(spacing: 6) {
                        Image(systemName: "list.bullet")
                            .font(.system(size: 26))
                        Text("\(playlist.channels.count) \(lm.strings.channelsCount)")
                            .font(.system(size: 26, weight: .medium))
                    }
                    .foregroundColor(.white.opacity(0.4))
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .frame(height: Self.cardHeight)
    }
}

struct ContinueWatchingCard: View {
    let movie: SavedMovie
    @ObservedObject var playerManager: PlayerManager
    
    @State private var posterURL: URL?
    @FocusState private var isFocused: Bool
    
    var body: some View {
        Button {
            let channel = Channel(
                name: movie.title,
                url: movie.url,
                group: "Movie"
            )
            
            playerManager.setup(with: [channel])
            playerManager.playChannel(channel)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.85) {
                guard let player = playerManager.player,
                      let item = player.currentItem else { return }
                let seekTime = CMTime(seconds: movie.watchedTime, preferredTimescale: 600)
                item.seek(to: seekTime)
            }
        } label: {
            VStack(alignment: .leading, spacing: 14) {
                ZStack(alignment: .bottom) {
                    if let url = posterURL {
                        OptimizedPosterView(url: url, width: 360, height: 200)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    } else {
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(.white.opacity(0.06))
                                .frame(width: 360, height: 200)
                            Image(systemName: "film")
                                .font(.system(size: 70))
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    VStack {
                        Spacer()
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(.white.opacity(0.25))
                                    .frame(height: 4.5)
                                
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(Color.red)
                                    .frame(width: geo.size.width * CGFloat(movie.progress ?? 0), height: 4.5)
                            }
                        }
                        .frame(height: 4.5)
                        .padding(.horizontal, 18)
                        .padding(.bottom, 12)
                    }
                }
                .frame(width: 360, height: 200)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(movie.title)
                        .font(.system(size: 19, weight: .semibold))
                        .lineLimit(1)
                    
                    Text(movie.remainingText)
                        .font(.system(size: 15))
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(.vertical, isFocused ? 30 : 20)
        .task {
            posterURL = await TMDBService.shared.getPosterURL(for: movie.title)
        }
        .buttonStyle(.glass)
    }
}

@MainActor
struct ContinueWatchingContextMenuContent: View {
    let movie: SavedMovie
    let channel: Channel
    @ObservedObject var favoritesManager: FavoritesManager
    let onInfo: () -> Void
    let onAddToPlaylist: () -> Void
    let onRemoveFromWatchLater: () -> Void
    @StateObject private var lm = LanguageManager.shared

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(movie.title)
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(.primary)

            Divider()

            Button(action: onInfo) {
                Label(lm.strings.actionInfoMovie, systemImage: "info.circle")
            }

            Button(action: {
                favoritesManager.toggleFavorite(channel)
            }) {
                Label(
                    favoritesManager.isFavorite(channel) ? lm.strings.ctxRemoveFav : lm.strings.ctxAddFav,
                    systemImage: favoritesManager.isFavorite(channel) ? "heart.slash.fill" : "heart.fill"
                )
            }

            Button(action: onAddToPlaylist) {
                Label(lm.strings.ctxAddPlaylist, systemImage: "text.badge.plus")
            }

            Button(role: .destructive, action: onRemoveFromWatchLater) {
                Label(lm.strings.ctxRemoveWatchLater, systemImage: "clock.badge.xmark")
            }
        }
        .padding(8)
    }
}
