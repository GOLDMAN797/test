import Foundation
import Combine

@MainActor
class FavoritesManager: ObservableObject {
    @Published private(set) var favoriteIDs: Set<String> = []

    private let storageFile = "favorites_v1.plist"
    private let legacyKey   = "favorite_channels_v1"    // old UserDefaults key

    init() { loadFavorites() }

    func toggleFavorite(_ channel: Channel) {
        if favoriteIDs.contains(channel.id) {
            favoriteIDs.remove(channel.id)
        } else {
            favoriteIDs.insert(channel.id)
        }
        saveFavorites()
    }

    func add(_ channel: Channel)    { favoriteIDs.insert(channel.id); saveFavorites() }
    func remove(_ channel: Channel) { favoriteIDs.remove(channel.id); saveFavorites() }
    func isFavorite(_ channel: Channel) -> Bool { favoriteIDs.contains(channel.id) }

    // MARK: – Storage

    private func loadFavorites() {
        // New file-based storage
        if let saved = FileStorage.load(Set<String>.self, filename: storageFile) {
            favoriteIDs = saved
            return
        }
        // One-time migration from UserDefaults
        if let data = UserDefaults.standard.data(forKey: legacyKey),
           let decoded = try? JSONDecoder().decode(Set<String>.self, from: data) {
            favoriteIDs = decoded
            saveFavorites()
            UserDefaults.standard.removeObject(forKey: legacyKey)
        }
    }

    private func saveFavorites() {
        // Async background write — no main-thread block
        FileStorage.save(favoriteIDs, filename: storageFile)
    }
}
