import SwiftUI
import Combine

@MainActor
struct PlaylistDetailView: View {
    let playlist: Playlist
    @ObservedObject var playlistManager: PlaylistManager
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var favoritesManager: FavoritesManager
    @StateObject private var lm = LanguageManager.shared

    @State private var selectedGroup: String?
    @State private var displayedChannelsCount = 30
    // FIX: cached filteredChannels result — avoids recompute on every render
    @State private var cachedFilteredChannels: [Channel] = []

    @State private var liveInfoChannel: Channel?
    @State private var movieInfoChannel: Channel?

    @State private var selectedChannelForAdd: Channel?
    @State private var showAddToPlaylistDialog = false

    enum FocusArea: Hashable {
        case sidebar(String?)
        case channel(String)
    }
    @FocusState private var focusedField: FocusArea?

    @Environment(\.dismiss) private var dismiss

    private let favoritesGroupKey = "FAVORITES_UNIQUE_KEY"
    private static let columns = [GridItem(.adaptive(minimum: 250), spacing: 50)]

    private func normalizedGroup(_ value: String?) -> String? {
        guard let value else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    var groups: [String] {
        let values = playlist.channels.compactMap { normalizedGroup($0.group) }
        return Array(Set(values)).sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
    }

    func hasContentInGroup(_ group: String?) -> Bool {
        if group == favoritesGroupKey {
            return playlist.channels.contains { favoritesManager.isFavorite($0) }
        } else if let group {
            return playlist.channels.contains { normalizedGroup($0.group) == group }
        }
        return !playlist.channels.isEmpty
    }

    private func computeFilteredChannels() -> [Channel] {
        if selectedGroup == favoritesGroupKey {
            return playlist.channels.filter { favoritesManager.isFavorite($0) }
        } else if let selectedGroup {
            return playlist.channels.filter { normalizedGroup($0.group) == selectedGroup }
        }
        return playlist.channels
    }

    var paginatedChannels: [Channel] {
        Array(cachedFilteredChannels.prefix(displayedChannelsCount))
    }

    var body: some View {
        NavigationSplitView {
            List {
                Color.clear
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets())
                    .focusable(false)

                SidebarRow(
                    title: lm.strings.sidebarAll,
                    isSelected: selectedGroup == nil,
                    isDisabled: !hasContentInGroup(nil),
                    action: {
                        selectedGroup = nil
                        focusedField = .sidebar(nil)
                        resetPagination()
                    }
                )
                .focused($focusedField, equals: .sidebar(nil))

                SidebarRow(
                    title: lm.strings.sidebarFavorites,
                    isSelected: selectedGroup == favoritesGroupKey,
                    isDisabled: !hasContentInGroup(favoritesGroupKey),
                    action: {
                        selectedGroup = favoritesGroupKey
                        focusedField = .sidebar(favoritesGroupKey)
                        resetPagination()
                    }
                )
                .focused($focusedField, equals: .sidebar(favoritesGroupKey))

                ForEach(groups, id: \.self) { group in
                    SidebarRow(
                        title: group,
                        isSelected: selectedGroup == group,
                        isDisabled: !hasContentInGroup(group),
                        action: {
                            selectedGroup = group
                            focusedField = .sidebar(group)
                            resetPagination()
                        }
                    )
                    .focused($focusedField, equals: .sidebar(group))
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationTitle("")
            .safeAreaInset(edge: .bottom) {
                Button(action: { dismiss() }) {
                    HStack(spacing: 16) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 30))

                        VStack(alignment: .leading, spacing: 4) {
                            Text(playlist.name)
                                .font(.system(size: 30, weight: .bold))
                                .lineLimit(1)
                            Text("\(playlist.channels.count) \(lm.strings.channelsCount)")
                                .font(.system(size: 20))
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.vertical, 20)
                    .padding(.bottom, 20)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        } detail: {
            detailView
        }
        .onAppear { rebuildFilterCache() }
        .onChange(of: selectedGroup) { _, _ in rebuildFilterCache() }
        .onChange(of: favoritesManager.favoriteIDs) { _, _ in rebuildFilterCache() }
        .confirmationDialog(
            lm.strings.dialogAddChannel,
            isPresented: $showAddToPlaylistDialog,
            titleVisibility: .visible
        ) {
            if let channel = selectedChannelForAdd {
                ForEach(playlistManager.playlists) { pl in
                    Button(pl.name) {
                        playlistManager.addChannel(channel, to: pl.id)
                        selectedChannelForAdd = nil
                    }
                }
            }
            Button(lm.strings.cancel, role: .cancel) {
                selectedChannelForAdd = nil
            }
        }
        .defaultFocus($focusedField, .sidebar(selectedGroup))
        .onAppear {
            if let currentGroup = selectedGroup, !hasContentInGroup(currentGroup) {
                if hasContentInGroup(nil) {
                    selectedGroup = nil
                } else if hasContentInGroup(favoritesGroupKey) {
                    selectedGroup = favoritesGroupKey
                } else if let first = groups.first(where: { hasContentInGroup($0) }) {
                    selectedGroup = first
                }
            }
            focusedField = .sidebar(selectedGroup)
        }
        .onExitCommand {
            if playerManager.showPlayer {
                return
            }
            handleExitCommand()
        }
    }


    // Extracted to a separate @ViewBuilder to help the Swift type-checker
    // (avoids "unable to type-check expression in reasonable time" error)
    @ViewBuilder
    private var detailView: some View {
        ScrollView {
            LazyVGrid(columns: Self.columns, spacing: 50) {
                ForEach(paginatedChannels) { channel in
                    channelCard(for: channel)
                }

                if displayedChannelsCount < cachedFilteredChannels.count {
                    Color.clear
                        .frame(height: 1)
                        .onAppear { loadMoreChannels() }
                }
            }
            .padding(.horizontal, 10)
            .padding(.bottom, 10)
            .padding(.top, 20)
        }
        .toolbar(.hidden, for: .navigationBar)
        .navigationTitle("")
        .sheet(item: $liveInfoChannel) { channel in
            LiveInfoSheet(channel: channel, epgManager: playlistManager.epgManager)
        }
        .sheet(item: $movieInfoChannel) { channel in
            MovieInfoSheet(channel: channel)
        }
    }

    @ViewBuilder
    private func channelCard(for channel: Channel) -> some View {
        if channel.isMovie {
            Button(action: {
                playerManager.setup(with: cachedFilteredChannels)
                playerManager.playChannel(channel)
            }) {
                MoviePosterCard(channel: channel)
            }
            .buttonStyle(.card)
            .focused($focusedField, equals: .channel(channel.id))
            .id(channel.id)
            .contextMenu {
                MovieContextMenuContent(
                    channel: channel,
                    favoritesManager: favoritesManager,
                    onInfo: { movieInfoChannel = channel },
                    onAddToPlaylist: {
                        selectedChannelForAdd = channel
                        showAddToPlaylistDialog = true
                    }
                )
            }
        } else {
            Button(action: {
                playerManager.setup(with: cachedFilteredChannels)
                playerManager.playChannel(channel)
            }) {
                PlaylistChannelCard(
                    channel: channel,
                    isFavorite: favoritesManager.isFavorite(channel),
                    epgManager: playlistManager.epgManager
                )
            }
            .buttonStyle(.glass)
            .focused($focusedField, equals: .channel(channel.id))
            .id(channel.id)
            .contextMenu {
                ChannelContextMenuContent(
                    channel: channel,
                    epgManager: playlistManager.epgManager,
                    favoritesManager: favoritesManager,
                    onInfo: { liveInfoChannel = channel },
                    onAddToPlaylist: {
                        selectedChannelForAdd = channel
                        showAddToPlaylistDialog = true
                    }
                )
            }
        }
    }

    private func resetPagination() {
        displayedChannelsCount = 30
        cachedFilteredChannels = computeFilteredChannels()
    }

    private func rebuildFilterCache() {
        cachedFilteredChannels = computeFilteredChannels()
    }

    private func loadMoreChannels() {
        guard displayedChannelsCount < cachedFilteredChannels.count else { return }
        displayedChannelsCount = min(displayedChannelsCount + 30, cachedFilteredChannels.count)
    }

    private func handleExitCommand() {
        switch focusedField {
        case .channel:
            let targetGroup = selectedGroup
            focusedField = nil
            Task {
                try? await Task.sleep(nanoseconds: 10_000_000)
                focusedField = .sidebar(targetGroup)
            }
        case .sidebar:
            dismiss()
        case .none:
            dismiss()
        }
    }
}

@MainActor
struct MovieContextMenuContent: View {
    let channel: Channel
    @ObservedObject var favoritesManager: FavoritesManager
    let onInfo: () -> Void
    let onAddToPlaylist: () -> Void
    let onRemoveFromWatchLater: (() -> Void)?
    @StateObject private var lm = LanguageManager.shared

    init(
        channel: Channel,
        favoritesManager: FavoritesManager,
        onInfo: @escaping () -> Void,
        onAddToPlaylist: @escaping () -> Void,
        onRemoveFromWatchLater: (() -> Void)? = nil
    ) {
        self.channel = channel
        self.favoritesManager = favoritesManager
        self.onInfo = onInfo
        self.onAddToPlaylist = onAddToPlaylist
        self.onRemoveFromWatchLater = onRemoveFromWatchLater
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(channel.name)
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(.primary)

            Divider()

            Button(action: onInfo) {
                Label(lm.strings.actionInfoMovie, systemImage: "info.circle")
            }

            Button(action: {
                favoritesManager.toggleFavorite(channel)
            }) {
                Label(
                    favoritesManager.isFavorite(channel) ? lm.strings.ctxRemoveFav : lm.strings.ctxAddFav,
                    systemImage: favoritesManager.isFavorite(channel) ? "heart.slash.fill" : "heart.fill"
                )
            }

            Button(action: onAddToPlaylist) {
                Label(lm.strings.ctxAddPlaylist, systemImage: "text.badge.plus")
            }

            if let onRemoveFromWatchLater {
                Button(role: .destructive, action: onRemoveFromWatchLater) {
                    Label(lm.strings.ctxRemoveWatchLater, systemImage: "clock.badge.xmark")
                }
            }
        }
        .padding(8)
    }
}

@MainActor
struct ChannelContextMenuContent: View {
    let channel: Channel
    @ObservedObject var epgManager: EPGManager
    @ObservedObject var favoritesManager: FavoritesManager
    let onInfo: () -> Void
    let onAddToPlaylist: () -> Void
    @StateObject private var lm = LanguageManager.shared

    var body: some View {
        Text(channel.name)

        Divider()

        Button(action: onInfo) {
            Label(lm.strings.actionInfoChannel, systemImage: "info.circle")
        }

        Button(action: {
            favoritesManager.toggleFavorite(channel)
        }) {
            Label(
                favoritesManager.isFavorite(channel) ? lm.strings.ctxRemoveFav : lm.strings.ctxAddFav,
                systemImage: favoritesManager.isFavorite(channel) ? "heart.slash.fill" : "heart.fill"
            )
        }

        Button(action: onAddToPlaylist) {
            Label(lm.strings.ctxAddPlaylist, systemImage: "text.badge.plus")
        }
    }
}

@MainActor
struct LiveInfoSheet: View {
    let channel: Channel
    @ObservedObject var epgManager: EPGManager
    @Environment(\.dismiss) var dismiss
    @StateObject private var lm = LanguageManager.shared

    @State private var logoImage: UIImage?
    @State private var isLoadingLogo = false

    var logoURL: URL? {
        if let smartLogo = epgManager.getSmartLogo(for: channel),
           let url = URL(string: smartLogo) {
            return url
        }
        if let playlistLogoStr = channel.logo,
           let url = URL(string: playlistLogoStr) {
            return url
        }
        return nil
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 24) {
                if let image = logoImage {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 120)
                        .cornerRadius(12)
                } else if isLoadingLogo {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .frame(width: 100, height: 120)
                } else {
                    Image(systemName: "tv")
                        .font(.system(size: 40))
                        .foregroundColor(.secondary)
                        .frame(width: 100, height: 120)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(12)
                }

                Text(channel.name)
                    .font(.system(size: 48, weight: .bold))
                
                Spacer()
                
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 40))
                }
                .buttonStyle(.glass)
            }
            .padding(40)
            
            ScrollView {
                let now = Date()
                let allPrograms = epgManager.getPrograms(for: channel)
                let programs = allPrograms.filter { $0.stop > now }
                let displayPrograms = Array(programs.prefix(6))
                
                if displayPrograms.isEmpty {
                    Text(lm.strings.epgNoInfo)
                        .font(.title2)
                        .foregroundColor(.white.opacity(0.6))
                        .padding(40)
                        .frame(maxWidth: .infinity)
                        .background(Color.white.opacity(0.05))
                        .cornerRadius(24)
                        .focusable(true)
                        .padding(.horizontal, 40)
                } else {
                    VStack(spacing: 30) {
                        ForEach(Array(displayPrograms.enumerated()), id: \.element.start) { index, prog in
                            let isCurrent = prog.start <= now && prog.stop > now
                            
                            VStack(alignment: .leading, spacing: 10) {
                                Text("\(timeString(for: prog)) - \(prog.title)")
                                    .font(isCurrent ? .system(size: 32, weight: .bold) : .system(size: 28, weight: .semibold))
                                    .foregroundColor(isCurrent ? .white : .white.opacity(0.8))
                                
                                if index < 3, let desc = prog.desc, !desc.isEmpty {
                                    Text(desc)
                                        .font(.system(size: 22, weight: .regular))
                                        .foregroundColor(isCurrent ? .white.opacity(0.9) : .white.opacity(0.5))
                                        .fixedSize(horizontal: false, vertical: true)
                                        .padding(.top, 4)
                                }
                            }
                            .padding(40)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(24)
                            .focusable(true)
                        }
                    }
                    .padding(.horizontal, 40)
                    .padding(.bottom, 60)
                }
            }
        }
        .frame(width: 1600, height: 950)
        .clipped()
        .task(id: logoURL) {
            guard let url = logoURL else { return }
            isLoadingLogo = true
            defer { isLoadingLogo = false }
            let img = await ImageLoader.shared.load(url: url)
            guard !Task.isCancelled else { return }
            if let img { logoImage = img }
        }
    }
    private static let timeFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f
    }()

    private func timeString(for prog: EPGProgram) -> String {
        Self.timeFormatter.string(from: prog.start)
    }
}

@MainActor
struct SidebarRow: View {
    let title: String
    let isSelected: Bool
    let isDisabled: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 15) {
                Circle()
                    .fill(isSelected ? Color.white : Color.clear)
                    .frame(width: 8, height: 8)

                Text(title)
                    .font(.system(size: 28, weight: .regular))
                    .lineLimit(1)

                Spacer()
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 16)
        }
        .disabled(isDisabled)
        .listRowBackground(Color.clear)
    }
}

@MainActor
struct PlaylistChannelCard: View {
    let channel: Channel
    let isFavorite: Bool
    @ObservedObject var epgManager: EPGManager

    @State private var cachedProgram: String = ""
    @State private var logoImage: UIImage?
    @State private var isLoadingLogo = false

    var logoURL: URL? {
        if let smartLogo = epgManager.getSmartLogo(for: channel),
           let url = URL(string: smartLogo) {
            return url
        }
        if let playlistLogoStr = channel.logo,
           let url = URL(string: playlistLogoStr) {
            return url
        }
        return nil
    }

    var cleanProgramName: String {
        let pattern = "^\\d{2}:\\d{2} - \\d{2}:\\d{2}\\s+"
        if let range = cachedProgram.range(of: pattern, options: .regularExpression) {
            return String(cachedProgram[range.upperBound...])
        }
        return cachedProgram
    }

    var body: some View {
        ZStack {
            if let image = logoImage {
                Image(uiImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(EdgeInsets(top: 35, leading: 0, bottom: 35, trailing: 0))
                    .blur(radius: 0.1)
            } else if isLoadingLogo {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
            } else {
                Image(systemName: "tv")
                    .font(.system(size: 40))
                    .foregroundColor(.secondary)
                    .padding(40)
            }

            VStack(spacing: 0) {
                HStack(alignment: .top) {
                    Text(channel.name)
                        .font(.system(size: 18, weight: .bold))
                        .lineLimit(1)

                    Spacer()

                    if isFavorite {
                        Image(systemName: "heart.fill")
                            .font(.caption2)
                            .padding(.leading, 4)
                    }
                }
                .padding(.top, 4)
                .padding(.horizontal, 4)

                Spacer()

                HStack(alignment: .bottom, spacing: 4) {
                    Text(cleanProgramName.isEmpty ? "" : cleanProgramName)
                        .font(.system(size: 15, weight: .regular))
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    if channel.hasArchive {
                        Image(systemName: "archivebox")
                            .font(.caption2)
                            .padding(.leading, 4)
                    }
                }
                .padding(.bottom, 4)
                .padding(.horizontal, 4)
            }
        }
        .frame(height: 140)
        .onAppear {
            updateCachedProgram()
        }
        .task(id: logoURL) {
            guard let url = logoURL else { return }
            isLoadingLogo = true
            defer { isLoadingLogo = false }
            let img = await ImageLoader.shared.load(url: url)
            guard !Task.isCancelled else { return }
            if let img { logoImage = img }
        }
        .onChange(of: epgManager.minuteTick) { _, _ in
            updateCachedProgram()
        }
        .onChange(of: epgManager.epgDataTick) { _, _ in
            updateCachedProgram()
        }
    }

    private func updateCachedProgram() {
        let programs = epgManager.getCurrentAndNextProgram(for: channel)
        cachedProgram = programs.current
    }
}

@MainActor
struct MovieInfoSheet: View {
    let channel: Channel
    @Environment(\.dismiss) var dismiss
    @StateObject private var lm = LanguageManager.shared

    enum MovieFocus: Hashable {
        case poster
        case title
        case meta
        case cast
        case overview
    }
    @FocusState private var movieFocus: MovieFocus?

    @State private var title: String = ""
    @State private var year: String = ""
    @State private var overview: String = ""
    @State private var cast: String = ""
    @State private var director: String = ""

    @State private var tagline: String = ""
    @State private var genres: String = ""
    @State private var countries: String = ""
    @State private var runtimeText: String = ""
    @State private var ratingText: String = ""

    @State private var cachedImage: UIImage? = nil
    @State private var isLoading = true
    @State private var didSetInitialFocus = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("\(title) \(year.isEmpty ? "" : "(\(year))")")
                        .font(.system(size: 48, weight: .bold))
                        
                    if !tagline.isEmpty {
                        Text(tagline)
                            .font(.system(size: 22, weight: .regular))
                            .foregroundColor(.white.opacity(0.7))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .focusable(true)
                .focused($movieFocus, equals: .title)

                Spacer()

                Button(action: { dismiss() }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 40))
                }
                .buttonStyle(.glass)
            }
            .padding(60)

            if isLoading {
                Spacer()
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    .scaleEffect(1.5)
                Spacer()
            } else {
                ScrollView {
                    HStack(alignment: .top, spacing: 50) {
                        Group {
                            if let img = cachedImage {
                                Image(uiImage: img)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 400)
                                    .cornerRadius(16)
                            } else {
                                Rectangle()
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(width: 400, height: 600)
                                    .cornerRadius(16)
                                    .overlay(
                                        Image(systemName: "film")
                                            .font(.system(size: 80))
                                            .foregroundColor(.gray)
                                    )
                            }
                        }
                        .focusable(true)
                        .focused($movieFocus, equals: .poster)

                        VStack(alignment: .leading, spacing: 20) {
                            
                            VStack(alignment: .leading, spacing: 10) {
                                Text(overview.isEmpty ? lm.strings.metaNoInfo : overview)
                                    .font(.system(size: 26))
                                    .lineSpacing(6)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .padding(28)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(24)
                            .focusable(true)
                            .focused($movieFocus, equals: .overview)

                            VStack(alignment: .leading, spacing: 12) {
                                if !ratingText.isEmpty {
                                    Text(ratingText)
                                        .font(.system(size: 22, weight: .semibold))
                                }
                                if !runtimeText.isEmpty {
                                    Text(runtimeText)
                                        .font(.system(size: 22))
                                }
                                if !genres.isEmpty {
                                    Text(genres)
                                        .font(.system(size: 22))
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                                if !countries.isEmpty {
                                    Text(countries)
                                        .font(.system(size: 22))
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                                if !director.isEmpty {
                                    Text("\(lm.strings.metaDirector) \(director)")
                                        .font(.system(size: 22))
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                            }
                            .padding(28)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.white.opacity(0.05))
                            .cornerRadius(24)
                            .focusable(true)
                            .focused($movieFocus, equals: .meta)

                            if !cast.isEmpty {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text(lm.strings.metaCast)
                                        .font(.system(size: 22, weight: .semibold))
                                    Text(cast)
                                        .font(.system(size: 22))
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                                .padding(28)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(24)
                                .focusable(true)
                                .focused($movieFocus, equals: .cast)
                            }
                        }
                    }
                    .padding(.horizontal, 60)
                    .padding(.bottom, 60)
                }
            }
        }
        .frame(width: 1600, height: 950)
        .clipped()
        .task {
            if !didSetInitialFocus {
                didSetInitialFocus = true
                try? await Task.sleep(nanoseconds: 80_000_000)
                movieFocus = .overview
            }

            if let details = await TMDBService.shared.getMovieDetails(for: channel.name) {
                title = details.title
                year = details.year ?? ""
                overview = details.overview
                director = details.director ?? ""
                cast = details.cast.joined(separator: ", ")
                tagline = details.tagline ?? ""

                genres = details.genres.isEmpty ? "" : "\(lm.strings.metaGenres) " + details.genres.joined(separator: ", ")
                countries = details.countries.isEmpty ? "" : "\(lm.strings.metaCountries) " + details.countries.joined(separator: ", ")

                if let runtime = details.runtimeMinutes, runtime > 0 {
                    runtimeText = "\(lm.strings.metaDuration) \(runtime) \(lm.strings.metaMin)"
                } else {
                    runtimeText = ""
                }

                ratingText = (details.ratingText ?? "")
            } else if let info = await TMDBService.shared.getMovieInfo(for: channel.name) {
                title = info.title
                year = info.year ?? ""
                overview = info.overview
                director = ""
                cast = ""
                tagline = ""
                genres = ""
                countries = ""
                runtimeText = ""
                ratingText = ""
            } else {
                title = channel.name
                overview = lm.strings.metaNoInfo
                director = ""
                cast = ""
                tagline = ""
                genres = ""
                countries = ""
                runtimeText = ""
                ratingText = ""
            }

            var posterURL: URL?
            if let path = await TMDBService.shared.getPosterURL(for: channel.name) {
                posterURL = path
            } else if let logoStr = channel.logo, let url = URL(string: logoStr) {
                posterURL = url
            }

            if let url = posterURL {
                let img = await ImageLoader.shared.load(url: url)
                guard !Task.isCancelled else { return }
                cachedImage = img
            }
            isLoading = false
        }
    }
}

