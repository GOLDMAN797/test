import Foundation

/// All timing/retry constants for PlayerManager in one place.
/// Changing a value here affects the whole player — no magic numbers spread across the file.
enum PlayerConstants {
    // MARK: – Channel switching
    /// Minimum interval between two channel switches to avoid UI jank
    static let minSwitchInterval: TimeInterval = 0.20
    /// Brief cooldown after a switch before another is allowed
    static let channelSwitchCooldown: TimeInterval = 0.35

    // MARK: – Startup timeouts
    /// How long to wait for a live stream to start before giving up / retrying
    static let liveStartupTimeout: TimeInterval = 3.5
    /// How long to wait for an archive / VOD item to start
    static let archiveStartupTimeout: TimeInterval = 15.0

    // MARK: – Live retry
    /// Delay before the first live-stream retry attempt
    static let liveRetryDelay: TimeInterval = 0.60
    /// Maximum number of automatic live-stream retry attempts
    static let maxLiveRetries: Int = 2

    // MARK: – User-agent fallback
    /// Maximum number of different User-Agent strings to try
    static let maxUserAgentFallbacks: Int = 3
}
