import Foundation

/// Reads both binary plist (legacy) and JSON (current) for backward compatibility.
enum FileStorage {

    private static var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    // MARK: – Sync read
    // Tries JSON first, falls back to binary plist (old format), auto-migrates on success.

    static func load<T: Codable>(_ type: T.Type, filename: String) -> T? {
        let url = documentsURL.appendingPathComponent(filename)
        guard let data = try? Data(contentsOf: url) else { return nil }

        // Try JSON first (current format)
        if let decoded = try? JSONDecoder().decode(type, from: data) {
            return decoded
        }

        // Fallback: binary plist written by previous version — migrate to JSON
        if let decoded = try? PropertyListDecoder().decode(type, from: data) {
            if let migrated = try? JSONEncoder().encode(decoded) {
                try? migrated.write(to: url, options: .atomic)
            }
            return decoded
        }

        return nil
    }

    // MARK: – Async write

    static func save<T: Encodable>(_ value: T, filename: String) {
        let url = documentsURL.appendingPathComponent(filename)
        Task.detached(priority: .background) {
            guard let data = try? JSONEncoder().encode(value) else { return }
            try? data.write(to: url, options: .atomic)
        }
    }

    // MARK: – Sync write (app backgrounding)

    static func saveSync<T: Encodable>(_ value: T, filename: String) {
        let url = documentsURL.appendingPathComponent(filename)
        guard let data = try? JSONEncoder().encode(value) else { return }
        try? data.write(to: url, options: .atomic)
    }

    static func delete(filename: String) {
        let url = documentsURL.appendingPathComponent(filename)
        try? FileManager.default.removeItem(at: url)
    }
}
