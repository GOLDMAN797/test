import Foundation
import AVKit

final class PlayerMetadataService {
    static let shared = PlayerMetadataService()

    func createMetadata(title: String, subtitle: String, description: String) -> [AVMetadataItem] {
        var items: [AVMetadataItem] = []
        
        let titleItem = AVMutableMetadataItem()
        titleItem.identifier = .commonIdentifierTitle
        titleItem.value = title as NSString
        titleItem.extendedLanguageTag = "und"
        items.append(titleItem)
        
        if !subtitle.isEmpty {
            let subItem = AVMutableMetadataItem()
            subItem.identifier = .iTunesMetadataTrackSubTitle
            subItem.value = subtitle as NSString
            subItem.extendedLanguageTag = "und"
            items.append(subItem)
        }
        
        if !description.isEmpty {
            let descItem = AVMutableMetadataItem()
            descItem.identifier = .commonIdentifierDescription
            descItem.value = description as NSString
            descItem.extendedLanguageTag = "und"
            items.append(descItem)
        }
        
        let genreItem = AVMutableMetadataItem()
        genreItem.identifier = .quickTimeMetadataGenre
        genreItem.value = title as NSString
        genreItem.extendedLanguageTag = "und"
        items.append(genreItem)
        
        return items
    }
}
