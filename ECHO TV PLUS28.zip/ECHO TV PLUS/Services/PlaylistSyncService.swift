import Foundation

struct PlaylistSyncService {
    
    static func normalizedName(_ s: String) -> String {
        s.lowercased()
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
            .filter { $0.isLetter || $0.isNumber }
    }

    static func channelKey(_ c: Channel) -> String {
        let epg = (c.epgId ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let url = c.url.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let name = normalizedName(c.name)
        let group = normalizedName(c.group ?? "")
        return "\(epg)|\(url)|\(name)|\(group)"
    }

    static func fuzzyKey(_ c: Channel) -> String {
        let epg = (c.epgId ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if !epg.isEmpty { return "epg:\(epg)" }
        let name = normalizedName(c.name)
        let group = normalizedName(c.group ?? "")
        return "ng:\(name)|\(group)"
    }
    
    static func mergeChannels(existing: [Channel], fetched: [Channel]) -> [Channel] {
        var merged: [Channel] = []
        merged.reserveCapacity(fetched.count + existing.count)

        var strongSeen = Set<String>()
        var fuzzySeen = Set<String>()

        func appendIfUnique(_ c: Channel) {
            let sKey = channelKey(c)
            let fKey = fuzzyKey(c)
            guard !strongSeen.contains(sKey), !fuzzySeen.contains(fKey) else { return }
            strongSeen.insert(sKey)
            fuzzySeen.insert(fKey)
            merged.append(c)
        }

        for ch in fetched { appendIfUnique(ch) }
        for ch in existing { appendIfUnique(ch) }

        return merged
    }
}
