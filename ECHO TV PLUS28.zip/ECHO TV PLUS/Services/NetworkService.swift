import Foundation

actor NetworkService {
    static let shared = NetworkService()

    private let defaultMaxRetries = 2
    private let retryBaseDelay: UInt64 = 700_000_000

    private lazy var session: URLSession = {
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 20
        cfg.timeoutIntervalForResource = 120
        cfg.waitsForConnectivity = true
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        cfg.urlCache = URLCache.shared
        return URLSession(configuration: cfg)
    }()

    func fetchData(
        from url: URL,
        headers: [String: String] = [:],
        cachePolicy: URLRequest.CachePolicy = .reloadIgnoringLocalCacheData,
        retries: Int? = nil
    ) async throws -> Data {
        let maxAttempts = retries ?? defaultMaxRetries
        var attempt = 0
        var lastError: Error?

        while attempt <= maxAttempts {
            do {
                var request = URLRequest(url: url, cachePolicy: cachePolicy, timeoutInterval: 20)
                for (k, v) in headers {
                    request.setValue(v, forHTTPHeaderField: k)
                }

                let (data, response) = try await session.data(for: request)
                if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                    throw URLError(.badServerResponse)
                }
                return data
            } catch {
                lastError = error
                if attempt == maxAttempts { break }
                let delay = retryBaseDelay * UInt64(attempt + 1)
                try? await Task.sleep(nanoseconds: delay)
                attempt += 1
            }
        }

        throw lastError ?? URLError(.cannotLoadFromNetwork)
    }

    func downloadToTemp(
        from url: URL,
        headers: [String: String] = [:],
        cachePolicy: URLRequest.CachePolicy = .reloadIgnoringLocalCacheData,
        retries: Int? = nil
    ) async throws -> (localURL: URL, response: URLResponse) {
        let maxAttempts = retries ?? defaultMaxRetries
        var attempt = 0
        var lastError: Error?

        while attempt <= maxAttempts {
            do {
                var request = URLRequest(url: url, cachePolicy: cachePolicy, timeoutInterval: 240)
                for (k, v) in headers {
                    request.setValue(v, forHTTPHeaderField: k)
                }

                let (localURL, response) = try await session.download(for: request)
                if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                    throw URLError(.badServerResponse)
                }
                return (localURL, response)
            } catch {
                lastError = error
                if attempt == maxAttempts { break }
                let delay = retryBaseDelay * UInt64(attempt + 1)
                try? await Task.sleep(nanoseconds: delay)
                attempt += 1
            }
        }

        throw lastError ?? URLError(.cannotLoadFromNetwork)
    }
}
