import Foundation
import Combine

struct SavedMovie: Codable, Identifiable {
    // FIX: id = url so it's stable across encode/decode cycles (was "let id = UUID()" — a bug)
    var id: String { url }
    let url: String
    let title: String
    let watchedTime: Double
    let duration: Double?
    let savedDate: Date

    // FIX: Optional — hide progress bar when duration is unknown (was hardcoded 0.6)
    var progress: Double? {
        guard let d = duration, d > 0 else { return nil }
        return min(1.0, watchedTime / d)
    }

    var remainingText: String {
        // FIX: both strings now go through LanguageManager (was hardcoded "Продолжить")
        let lm = LanguageManager.shared
        guard let d = duration, d > watchedTime + 60 else { return lm.strings.btnStartOver }
        let mins = Int(ceil((d - watchedTime) / 60))
        return "\(mins) \(lm.strings.minutesLeft)"
    }
}

@MainActor
final class PlaybackHistoryService: ObservableObject {
    static let shared = PlaybackHistoryService()

    private let storageFile = "movie_history_v2.plist"
    private let legacyKey   = "movie_history_v2"        // old UserDefaults key for migration

    @Published private(set) var items: [SavedMovie] = []

    private init() { load() }

    // MARK: – Load

    private func load() {
        // New file-based storage
        if let saved = FileStorage.load([SavedMovie].self, filename: storageFile) {
            items = saved.sorted { $0.savedDate > $1.savedDate }
            return
        }
        // One-time migration from UserDefaults
        if let data = UserDefaults.standard.data(forKey: legacyKey),
           let decoded = try? JSONDecoder().decode([SavedMovie].self, from: data) {
            items = decoded.sorted { $0.savedDate > $1.savedDate }
            persist()
            UserDefaults.standard.removeObject(forKey: legacyKey)
        }
    }

    // MARK: – Persist (async / background — no main-thread block)

    private func persist() {
        FileStorage.save(items, filename: storageFile)
    }

    // MARK: – Public API

    func getSavedTime(for url: String) -> Double {
        items.first(where: { $0.url == url })?.watchedTime ?? 0
    }

    func remove(url: String) {
        let trimmed = url.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        items.removeAll { $0.url == trimmed }
        persist()
    }

    func saveProgress(url: String, title: String, time: Double, duration: Double?) {
        guard time > 15 else { return }
        items.removeAll { $0.url == url }
        let item = SavedMovie(url: url, title: title, watchedTime: time,
                              duration: duration, savedDate: Date())
        items.insert(item, at: 0)
        if items.count > 12 { items = Array(items.prefix(12)) }
        persist()
    }

    // FIX: now actually filters — hides movies watched to >= 95%
    func getContinueWatching() -> [SavedMovie] {
        items.filter { movie in
            guard let p = movie.progress else { return true }
            return p < 0.95
        }
    }
}
