import Foundation
import SwiftUI
import Combine

struct PosterCacheItem: Codable, Sendable {
    let url: URL
    let timestamp: Date
}

actor CacheStore {
    private var storage: [String: PosterCacheItem] = [:]
    private let maxItems = 1500

    func get(_ key: String) -> URL? {
        storage[key]?.url
    }

    func set(_ key: String, url: URL) {
        storage[key] = PosterCacheItem(url: url, timestamp: Date())
        enforceLimit()
    }

    private func enforceLimit() {
        if storage.count > maxItems {
            let sorted = storage.sorted { $0.value.timestamp < $1.value.timestamp }
            let toRemove = sorted.prefix(maxItems / 5).map { $0.key }
            for k in toRemove { storage.removeValue(forKey: k) }
        }
    }

    func removeAll() {
        storage.removeAll()
    }

    func snapshot() -> [String: PosterCacheItem] {
        storage
    }

    func replace(with data: [String: PosterCacheItem]) {
        storage = data
        enforceLimit()
    }
}

actor NetworkGate {
    private var activeCount = 0
    private let maxConcurrent: Int
    private var waiting: [CheckedContinuation<Void, Never>] = []

    init(maxConcurrent: Int = 4) {
        self.maxConcurrent = maxConcurrent
    }

    func acquire() async {
        if activeCount < maxConcurrent {
            activeCount += 1
            return
        }
        await withCheckedContinuation { cont in
            waiting.append(cont)
        }
        activeCount += 1
    }

    func release() {
        activeCount = max(0, activeCount - 1)
        if !waiting.isEmpty {
            let next = waiting.removeFirst()
            next.resume()
        }
    }
}

actor InFlightRequests {
    private var tasks: [String: Task<URL?, Never>] = [:]

    func task(for key: String) -> Task<URL?, Never>? {
        tasks[key]
    }

    func set(_ key: String, task: Task<URL?, Never>) {
        tasks[key] = task
    }

    func remove(_ key: String) {
        tasks.removeValue(forKey: key)
    }
}

struct MovieInfoResult {
    let title: String
    let overview: String
    let year: String?
}

struct MovieDetailsResult: Sendable {
    let title: String
    let overview: String
    let year: String?
    let director: String?
    let cast: [String]
    let tagline: String?
    let genres: [String]
    let countries: [String]
    let runtimeMinutes: Int?
    let ratingText: String?
}

@MainActor
final class TMDBService: ObservableObject {
    static let shared = TMDBService()

    private let kinopoiskApiKey: String = {
        guard let key = Bundle.main.object(forInfoDictionaryKey: "KinopoiskApiKey") as? String else { return "" }
        return key
    }()

    private let tmdbApiKey: String = {
        guard let key = Bundle.main.object(forInfoDictionaryKey: "TMDBApiKey") as? String else { return "" }
        return key
    }()

    private let cacheFileName = "posters_cache_v2.json"
    private let oldCacheFileName = "posters_cache.json"
    private let cacheStore = CacheStore()
    private let networkGate = NetworkGate(maxConcurrent: 4)
    private let inFlight = InFlightRequests()

    private let snapshotQueue = DispatchQueue(label: "tmdb.cache.snapshot", qos: .userInitiated)
    private var cachedSnapshot: [String: PosterCacheItem] = [:]

    init() {
        Task { [weak self] in
            await self?.loadCacheFromDisk()
        }
    }

    func getPosterURL(for rawName: String) async -> URL? {
        let year = extractYear(from: rawName)
        let cleanedName = cleanName(rawName)

        let cacheKey: String
        if let y = year {
            cacheKey = "\(cleanedName)_\(y)"
        } else {
            cacheKey = cleanedName
        }

        if let cachedURL = getCachedByKeySync(cacheKey) {
            return cachedURL
        }

        if cleanedName.isEmpty { return nil }

        if let existing = await inFlight.task(for: cacheKey) {
            return await existing.value
        }

        let task = Task<URL?, Never> { @MainActor in
            // Kinopoisk
            if let kpURL = await self.searchKinopoiskAPI(query: cleanedName, year: year) {
                await self.saveToCache(key: cacheKey, url: kpURL)
                return kpURL
            }

            // TMDB movie search
            if let tmdbRU = await self.smartSearchTMDB(query: cleanedName, year: year, language: "ru-RU") {
                await self.saveToCache(key: cacheKey, url: tmdbRU)
                return tmdbRU
            }
            if let tmdbEN = await self.smartSearchTMDB(query: cleanedName, year: year, language: "en-US") {
                await self.saveToCache(key: cacheKey, url: tmdbEN)
                return tmdbEN
            }

            // TMDB multi search fallback (movie + tv)
            if let multiRU = await self.smartSearchTMDBMulti(query: cleanedName, year: year, language: "ru-RU") {
                await self.saveToCache(key: cacheKey, url: multiRU)
                return multiRU
            }
            if let multiEN = await self.smartSearchTMDBMulti(query: cleanedName, year: year, language: "en-US") {
                await self.saveToCache(key: cacheKey, url: multiEN)
                return multiEN
            }

            // If title has trailing short tag (e.g. "sdr", "rhs") try without last word
            let parts = cleanedName.split(separator: " ")
            if parts.count >= 2, let last = parts.last, last.count <= 4 {
                let trimmed = parts.dropLast().joined(separator: " ")
                if let tmdb = await self.smartSearchTMDB(query: String(trimmed), year: year, language: "en-US") {
                    await self.saveToCache(key: cacheKey, url: tmdb)
                    return tmdb
                }
                if let multi = await self.smartSearchTMDBMulti(query: String(trimmed), year: year, language: "en-US") {
                    await self.saveToCache(key: cacheKey, url: multi)
                    return multi
                }
            }

            return nil
        }

        await inFlight.set(cacheKey, task: task)
        let result = await task.value
        await inFlight.remove(cacheKey)
        return result
    }

    func getCachedURL(for rawName: String) -> URL? {
        let year = extractYear(from: rawName)
        let cleanedName = cleanName(rawName)

        let cacheKey: String
        if let y = year {
            cacheKey = "\(cleanedName)_\(y)"
        } else {
            cacheKey = cleanedName
        }

        return getCachedByKeySync(cacheKey)
    }

    func getMovieInfo(for rawName: String) async -> MovieInfoResult? {
        let year = extractYear(from: rawName)
        let cleanedName = cleanName(rawName)
        if cleanedName.isEmpty { return nil }

        if let kp = await searchKinopoiskInfo(query: cleanedName, year: year) { return kp }
        if let tmdbRU = await searchTMDBInfo(query: cleanedName, year: year, language: "ru-RU") { return tmdbRU }
        if let tmdbEN = await searchTMDBInfo(query: cleanedName, year: year, language: "en-US") { return tmdbEN }
        return nil
    }

    func getMovieDetails(for rawName: String) async -> MovieDetailsResult? {
        let year = extractYear(from: rawName)
        let cleanedName = cleanName(rawName)
        if cleanedName.isEmpty { return nil }

        if let kp = await fetchKinopoiskDetails(query: cleanedName, year: year) {
            return kp
        }

        if let tmdbRU = await fetchTMDBDetails(query: cleanedName, year: year, language: "ru-RU") {
            return tmdbRU
        }
        if let tmdbEN = await fetchTMDBDetails(query: cleanedName, year: year, language: "en-US") {
            return tmdbEN
        }

        return nil
    }

    private func fetchKinopoiskDetails(query: String, year: String?) async -> MovieDetailsResult? {
        guard !kinopoiskApiKey.isEmpty else { return nil }

        guard let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://kinopoiskapiunofficial.tech/api/v2.1/films/search-by-keyword?keyword=\(encodedQuery)") else { return nil }

        var request = URLRequest(url: url)
        request.setValue(kinopoiskApiKey, forHTTPHeaderField: "X-API-KEY")
        request.timeoutInterval = 4.0

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200,
                  let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let films = json["films"] as? [[String: Any]], !films.isEmpty else { return nil }

            let match: [String: Any]
            if let y = year,
               let exact = films.first(where: { String(describing: $0["year"] ?? "") == y }) {
                match = exact
            } else {
                match = films[0]
            }

            let filmIdAny = match["filmId"] ?? match["filmID"] ?? match["id"]
            if let filmId = filmIdAny as? Int {
                return await fetchKinopoiskByFilmId(filmId, fallbackTitle: query)
            }
            if let s = filmIdAny as? String, let filmId = Int(s) {
                return await fetchKinopoiskByFilmId(filmId, fallbackTitle: query)
            }

            return nil
        } catch {
            return nil
        }
    }

    private func fetchKinopoiskByFilmId(_ filmId: Int, fallbackTitle: String) async -> MovieDetailsResult? {
        guard let detailsURL = URL(string: "https://kinopoiskapiunofficial.tech/api/v2.2/films/\(filmId)") else { return nil }

                let detailsRequest: URLRequest = {
                    var r = URLRequest(url: detailsURL)
                    r.setValue(kinopoiskApiKey, forHTTPHeaderField: "X-API-KEY")
                    r.timeoutInterval = 4.0
                    return r
                }()

                let staffURL = URL(string: "https://kinopoiskapiunofficial.tech/api/v1/staff?filmId=\(filmId)")

                async let detailsTask: (Data, URLResponse) = URLSession.shared.data(for: detailsRequest)
                async let staffTask: (Data, URLResponse)? = {
                    guard let staffURL else { return nil }
                    var req = URLRequest(url: staffURL)
                    req.setValue(kinopoiskApiKey, forHTTPHeaderField: "X-API-KEY")
                    req.timeoutInterval = 4.0
                    return try? await URLSession.shared.data(for: req)
                }()

        do {
            let (detailsData, detailsResp) = try await detailsTask
            guard let http = detailsResp as? HTTPURLResponse, http.statusCode == 200,
                  let djson = try JSONSerialization.jsonObject(with: detailsData) as? [String: Any] else { return nil }

            let title = (djson["nameRu"] as? String) ?? (djson["nameOriginal"] as? String) ?? (djson["nameEn"] as? String) ?? fallbackTitle
            let overview = (djson["description"] as? String) ?? ""

            let yearStr: String? = {
                if let y = djson["year"] as? Int { return String(y) }
                if let y = djson["year"] as? String { return y }
                return nil
            }()

            let tagline: String? = (djson["slogan"] as? String)

            let runtimeMinutes: Int? = {
                if let len = djson["filmLength"] as? Int { return len }
                if let len = djson["filmLength"] as? String, let i = Int(len) { return i }
                return nil
            }()

            let genres: [String] = (djson["genres"] as? [[String: Any]])?.compactMap { $0["genre"] as? String } ?? []
            let countries: [String] = (djson["countries"] as? [[String: Any]])?.compactMap { $0["country"] as? String } ?? []

            let ratingKP: String? = {
                if let r = djson["ratingKinopoisk"] as? Double { return String(format: "%.1f", r) }
                if let r = djson["ratingKinopoisk"] as? String { return r }
                return nil
            }()

            var director: String? = nil
            var cast: [String] = []

            if let staffPair = await staffTask,
               let staffArr = try? JSONSerialization.jsonObject(with: staffPair.0) as? [[String: Any]] {

                let directors = staffArr.filter {
                    let prof = ($0["professionKey"] as? String) ?? ""
                    return prof.uppercased() == "DIRECTOR"
                }
                director = directors.compactMap { ($0["nameRu"] as? String) ?? ($0["nameEn"] as? String) }.first

                let actors = staffArr.filter {
                    let prof = ($0["professionKey"] as? String) ?? ""
                    return prof.uppercased() == "ACTOR"
                }
                cast = Array(actors.compactMap { ($0["nameRu"] as? String) ?? ($0["nameEn"] as? String) }.prefix(10))
            }

            let ratingText: String? = {
                if let rk = ratingKP, !rk.isEmpty { return "Рейтинг: KP \(rk)" }
                return nil
            }()

            return MovieDetailsResult(
                title: title,
                overview: overview,
                year: yearStr,
                director: director,
                cast: cast,
                tagline: tagline,
                genres: genres,
                countries: countries,
                runtimeMinutes: runtimeMinutes,
                ratingText: ratingText
            )
        } catch {
            return nil
        }
    }

    private func fetchTMDBDetails(query: String, year: String?, language: String) async -> MovieDetailsResult? {
        guard !tmdbApiKey.isEmpty else { return nil }
        guard let movieId = await searchTMDBMovieId(query: query, year: year, language: language) else { return nil }

        let urlString = "https://api.themoviedb.org/3/movie/\(movieId)?api_key=\(tmdbApiKey)&language=\(language)&append_to_response=credits"
        guard let url = URL(string: urlString) else { return nil }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }

            let title = (json["title"] as? String) ?? query
            let overview = (json["overview"] as? String) ?? ""

            let yearStr: String? = {
                guard let release = json["release_date"] as? String, release.count >= 4 else { return nil }
                return String(release.prefix(4))
            }()

            let runtimeMinutes: Int? = json["runtime"] as? Int
            let tagline: String? = (json["tagline"] as? String)
            let genres: [String] = (json["genres"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
            let countries: [String] = (json["production_countries"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []

            let voteAverage: String? = {
                if let v = json["vote_average"] as? Double { return String(format: "%.1f", v) }
                return nil
            }()

            var director: String? = nil
            var cast: [String] = []

            if let credits = json["credits"] as? [String: Any] {
                if let crew = credits["crew"] as? [[String: Any]] {
                    director = crew.first(where: { ($0["job"] as? String) == "Director" })?["name"] as? String
                }
                if let castArr = credits["cast"] as? [[String: Any]] {
                    cast = Array(castArr.compactMap { $0["name"] as? String }.prefix(10))
                }
            }

            let ratingText: String? = {
                if let tm = voteAverage, !tm.isEmpty { return "Рейтинг: TMDB \(tm)" }
                return nil
            }()

            return MovieDetailsResult(
                title: title,
                overview: overview,
                year: yearStr,
                director: director,
                cast: cast,
                tagline: tagline,
                genres: genres,
                countries: countries,
                runtimeMinutes: runtimeMinutes,
                ratingText: ratingText
            )
        } catch {
            return nil
        }
    }

    private func searchTMDBMovieId(query: String, year: String?, language: String) async -> Int? {
        guard let encodedName = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }

        var urlString = "https://api.themoviedb.org/3/search/movie?api_key=\(tmdbApiKey)&query=\(encodedName)&language=\(language)&page=1&include_adult=false"
        if let y = year { urlString += "&primary_release_year=\(y)" }
        guard let url = URL(string: urlString) else { return nil }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let results = json["results"] as? [[String: Any]],
                  let m = results.first,
                  let id = m["id"] as? Int else { return nil }
            return id
        } catch {
            return nil
        }
    }

    private func searchKinopoiskInfo(query: String, year: String?) async -> MovieInfoResult? {
        guard let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://kinopoiskapiunofficial.tech/api/v2.1/films/search-by-keyword?keyword=\(encodedQuery)") else { return nil }
        var request = URLRequest(url: url)
        request.setValue(kinopoiskApiKey, forHTTPHeaderField: "X-API-KEY")
        request.timeoutInterval = 4.0

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200,
                  let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let films = json["films"] as? [[String: Any]], !films.isEmpty else { return nil }

            let match: [String: Any]
            if let y = year, let exact = films.first(where: { String(describing: $0["year"] ?? "") == y }) {
                match = exact
            } else {
                match = films[0]
            }

            let title = (match["nameRu"] as? String) ?? (match["nameEn"] as? String) ?? query
            let overview = (match["description"] as? String) ?? ""
            let y = (match["year"] as? String)
            return MovieInfoResult(title: title, overview: overview, year: y)
        } catch {
            return nil
        }
    }

    private func searchTMDBInfo(query: String, year: String?, language: String) async -> MovieInfoResult? {
        guard let encodedName = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }

        var urlString = "https://api.themoviedb.org/3/search/movie?api_key=\(tmdbApiKey)&query=\(encodedName)&language=\(language)&page=1&include_adult=false"
        if let y = year { urlString += "&primary_release_year=\(y)" }
        guard let url = URL(string: urlString) else { return nil }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let results = json["results"] as? [[String: Any]],
                  let m = results.first else { return nil }

            let title = (m["title"] as? String) ?? query
            let overview = (m["overview"] as? String) ?? ""
            let release = (m["release_date"] as? String)
            let y: String? = release?.prefix(4).isEmpty == false ? String(release!.prefix(4)) : nil
            return MovieInfoResult(title: title, overview: overview, year: y)
        } catch {
            return nil
        }
    }

    func clearCache() {
        snapshotQueue.sync { cachedSnapshot.removeAll() }
        Task { await cacheStore.removeAll() }

        if let url = getCacheFileURL(name: cacheFileName) { try? FileManager.default.removeItem(at: url) }
        if let oldUrl = getCacheFileURL(name: oldCacheFileName) { try? FileManager.default.removeItem(at: oldUrl) }
    }

    private func getCachedByKeySync(_ key: String) -> URL? {
        snapshotQueue.sync { cachedSnapshot[key]?.url }
    }

    private func searchKinopoiskAPI(query: String, year: String?) async -> URL? {
        guard !kinopoiskApiKey.isEmpty else { return nil }

        guard let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://kinopoiskapiunofficial.tech/api/v2.1/films/search-by-keyword?keyword=\(encodedQuery)") else { return nil }

        var request = URLRequest(url: url)
        request.setValue(kinopoiskApiKey, forHTTPHeaderField: "X-API-KEY")
        request.timeoutInterval = 4.0

        await networkGate.acquire()
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            await networkGate.release()

            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { return nil }

            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let films = json["films"] as? [[String: Any]] else { return nil }

            var bestMatch = films.first
            if let y = year, let exactMatch = films.first(where: { String(describing: $0["year"] ?? "") == y }) {
                bestMatch = exactMatch
            }

            if let match = bestMatch, let posterURL = match["posterUrl"] as? String {
                return URL(string: posterURL)
            }
            return nil
        } catch {
            await networkGate.release()
            return nil
        }
    }

    private func smartSearchTMDB(query: String, year: String?, language: String) async -> URL? {
        if let y = year, let exact = await searchTMDBAPI(query: query, year: y, language: language) { return exact }
        return await searchTMDBAPI(query: query, year: nil, language: language)
    }

    private func smartSearchTMDBMulti(query: String, year: String?, language: String) async -> URL? {
        if let y = year, let exact = await searchTMDBMultiAPI(query: query, year: y, language: language) { return exact }
        return await searchTMDBMultiAPI(query: query, year: nil, language: language)
    }

    private func searchTMDBAPI(query: String, year: String?, language: String) async -> URL? {
        guard !tmdbApiKey.isEmpty else { return nil }
        guard let encodedName = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }

        var urlString = "https://api.themoviedb.org/3/search/movie?api_key=\(tmdbApiKey)&query=\(encodedName)&language=\(language)&page=1&include_adult=false"
        if let y = year { urlString += "&primary_release_year=\(y)" }
        guard let url = URL(string: urlString) else { return nil }

        var request = URLRequest(url: url)
        request.timeoutInterval = 4.0

        await networkGate.acquire()
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            await networkGate.release()

            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { return nil }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let results = json["results"] as? [[String: Any]] else { return nil }

            guard let match = results.first(where: { $0["poster_path"] is String }),
                  let posterPath = match["poster_path"] as? String else { return nil }

            return URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)")
        } catch {
            await networkGate.release()
            return nil
        }
    }

    private func searchTMDBMultiAPI(query: String, year: String?, language: String) async -> URL? {
        guard !tmdbApiKey.isEmpty else { return nil }
        guard let encodedName = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }

        var urlString = "https://api.themoviedb.org/3/search/multi?api_key=\(tmdbApiKey)&query=\(encodedName)&language=\(language)&page=1&include_adult=false"
        // TMDB multi doesn't have a strict "primary_release_year" for all media types; we keep it broad.

        guard let url = URL(string: urlString) else { return nil }

        var request = URLRequest(url: url)
        request.timeoutInterval = 4.0

        await networkGate.acquire()
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            await networkGate.release()

            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { return nil }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let results = json["results"] as? [[String: Any]] else { return nil }

            // Prefer movie/tv, ignore person
            let candidates = results.filter {
                let type = ($0["media_type"] as? String) ?? ""
                return type != "person" && ($0["poster_path"] as? String) != nil
            }

            guard let match = candidates.first,
                  let posterPath = match["poster_path"] as? String else { return nil }

            return URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)")
        } catch {
            await networkGate.release()
            return nil
        }
    }

    private func extractYear(from text: String) -> String? {
        let pattern = "(?<!\\d)(19|20)\\d{2}(?!\\d|x|p)"
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
        let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
        guard let lastMatch = matches.last, let range = Range(lastMatch.range, in: text) else { return nil }
        return String(text[range])
    }

    private func cleanName(_ name: String) -> String {
        var n = name.lowercased()
        n = n.replacingOccurrences(of: "\\[.*?\\]", with: "", options: .regularExpression)
        n = n.replacingOccurrences(of: "\\(.*?\\)", with: "", options: .regularExpression)

        // Remove season/episode markers
        n = n.replacingOccurrences(of: "\\b[s]\\d{1,2}[e]\\d{1,3}(?:[e-]\\d{1,3})?\\b", with: "", options: .regularExpression)
        n = n.replacingOccurrences(of: "\\b\\d{1,2}x\\d{1,3}\\b", with: "", options: .regularExpression)
        n = n.replacingOccurrences(of: "\\b[e]\\d{1,3}\\b", with: "", options: .regularExpression)

        // Strip leading index like "1 " but keep real year-titles like "1917"
        n = n.replacingOccurrences(of: "^\\s*(?!19\\d{2}\\b)(?!20\\d{2}\\b)\\d{1,3}\\s*[-.)]?\\s+", with: "", options: .regularExpression)

        if let y = extractYear(from: name) {
            n = n.replacingOccurrences(of: "\\b\(y)\\b", with: "", options: .regularExpression)
        }

        let garbage = [
            "4k", "hdr", "hdr10", "dv", "sdr", "fhd", "uhd", "1080p", "720p", "480p", "2160p",
            "hevc", "x264", "x265", "h\\.264", "h\\.265", "avc", "xvid", "divx",
            "web-dl", "webrip", "bluray", "bdrip", "brrip", "dvdrip", "hdtv", "pdtv", "rip", "remux", "proper",
            "rus", "eng", "dub", "sub", "multi",
            "atmos", "truehd", "dts", "aac", "ac3", "dd5\\.1", "dd7\\.1", "flac",
            "rhs", "imax", "extended", "uncut", "theatrical", "director", "directors", "cut"
        ]
        for pattern in garbage {
            n = n.replacingOccurrences(of: "\\b\(pattern)\\b", with: "", options: .regularExpression)
        }

        n = n.replacingOccurrences(of: ".", with: " ")
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: ":", with: " ")
            .replacingOccurrences(of: "-", with: " ")

        while n.contains("  ") { n = n.replacingOccurrences(of: "  ", with: " ") }
        return n.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func saveToCache(key: String, url: URL) async {
        await cacheStore.set(key, url: url)
        let safeCopy = await cacheStore.snapshot()
        snapshotQueue.sync { cachedSnapshot = safeCopy }
        saveCacheToDisk(data: safeCopy)
    }

    private func saveCacheToDisk(data: [String: PosterCacheItem]) {
        guard let url = getCacheFileURL(name: cacheFileName) else { return }
        try? JSONEncoder().encode(data).write(to: url)
    }

    private func loadCacheFromDisk() async {
        if let url = getCacheFileURL(name: cacheFileName),
           let data = try? Data(contentsOf: url),
           let cacheV2 = try? JSONDecoder().decode([String: PosterCacheItem].self, from: data) {

            let cutoff = Date().addingTimeInterval(-30 * 86400)
            let freshCache = cacheV2.filter { $0.value.timestamp > cutoff }

            await cacheStore.replace(with: freshCache)
            snapshotQueue.sync { cachedSnapshot = freshCache }
            return
        }

        if let oldUrl = getCacheFileURL(name: oldCacheFileName),
           let data = try? Data(contentsOf: oldUrl),
           let oldCache = try? JSONDecoder().decode([String: String].self, from: data) {

            var upgradedCache: [String: PosterCacheItem] = [:]
            for (key, urlString) in oldCache {
                if let u = URL(string: urlString) {
                    upgradedCache[key] = PosterCacheItem(url: u, timestamp: Date())
                }
            }

            await cacheStore.replace(with: upgradedCache)
            snapshotQueue.sync { cachedSnapshot = upgradedCache }
            saveCacheToDisk(data: upgradedCache)
            try? FileManager.default.removeItem(at: oldUrl)
        }
    }

    private func getCacheFileURL(name: String) -> URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(name)
    }
}
