import SwiftUI
import Combine

struct SearchResult: Identifiable {
    var id: String { "\(playlistName)|\(channel.url)|\(channel.id)" }
    let channel: Channel
    let playlistName: String

    let searchName: String
    let searchGroup: String
    let searchPlaylist: String

    init(channel: Channel, playlistName: String) {
        self.channel = channel
        self.playlistName = playlistName

        self.searchName = channel.name.lowercased()
        self.searchGroup = (channel.group ?? "").lowercased()
        self.searchPlaylist = playlistName.lowercased()
    }
}

struct SearchView: View {
    @State private var localSearchText = ""
    @State private var filteredResults: [SearchResult] = []
    @State private var searchCancellable: AnyCancellable?
    @State private var searchIndex: [SearchResult] = []
    @State private var indexBuildToken = UUID()
    @State private var searchToken = UUID()

    @State private var selectedChannelForAdd: Channel?
    @State private var showAddToPlaylistDialog = false

    @ObservedObject var playlistManager: PlaylistManager
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var favoritesManager: FavoritesManager
    @ObservedObject var lm = LanguageManager.shared

    private static let columns = [
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40),
        GridItem(.flexible(), spacing: 40)
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 40) {
                HStack(spacing: 20) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 30))
                        .foregroundColor(.white.opacity(0.6))

                    TextField(lm.strings.searchPlaceholder, text: $localSearchText)
                        .font(.system(size: 30, weight: .medium))
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                }
                .padding(.vertical, 20)
                .padding(.horizontal, 30)
                .background(Color.white.opacity(0.1))
                .cornerRadius(12)
                .onChange(of: localSearchText) { _, newValue in
                    searchCancellable?.cancel()

                    if newValue.isEmpty {
                        filteredResults = []
                        return
                    }

                    searchCancellable = Just(newValue)
                        .delay(for: .milliseconds(250), scheduler: RunLoop.main)
                        .sink { searchText in
                            performSearch(searchText)
                        }
                }

                if localSearchText.isEmpty {
                    emptyStateView(icon: "magnifyingglass", text: lm.strings.searchStart)
                } else if filteredResults.isEmpty {
                    emptyStateView(icon: "questionmark.folder", text: lm.strings.searchNoResult)
                } else {
                    LazyVGrid(columns: Self.columns, spacing: 60) {
                        ForEach(filteredResults) { item in
                            Button {
                                let channels = filteredResults.map { $0.channel }
                                playerManager.setup(with: channels)
                                playerManager.playChannel(item.channel)
                            } label: {
                                SearchChannelCard(
                                    channel: item.channel,
                                    playlistName: item.playlistName,
                                    isFavorite: favoritesManager.isFavorite(item.channel),
                                    epgManager: playlistManager.epgManager
                                )
                            }
                            .buttonStyle(.card)
                            .contextMenu {
                                Button(
                                    favoritesManager.isFavorite(item.channel) ? lm.strings.ctxRemoveFav : lm.strings.ctxAddFav,
                                    systemImage: favoritesManager.isFavorite(item.channel) ? "heart.slash" : "heart"
                                ) {
                                    favoritesManager.toggleFavorite(item.channel)
                                }

                                Button(lm.strings.ctxAddPlaylist, systemImage: "text.badge.plus") {
                                    selectedChannelForAdd = item.channel
                                    showAddToPlaylistDialog = true
                                }

                                Button(lm.strings.ctxPlay, systemImage: "play.fill") {
                                    let channels = filteredResults.map { $0.channel }
                                    playerManager.setup(with: channels)
                                    playerManager.playChannel(item.channel)
                                }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 80)
            .padding(.bottom, 80)
            .padding(.top, 60)
        }
        .confirmationDialog(
            lm.strings.dialogAddChannel,
            isPresented: $showAddToPlaylistDialog,
            titleVisibility: .visible
        ) {
            if let channel = selectedChannelForAdd {
                ForEach(playlistManager.playlists) { playlist in
                    Button(playlist.name) {
                        playlistManager.addChannel(channel, to: playlist.id)
                        selectedChannelForAdd = nil
                    }
                }
            }
            Button(lm.strings.cancel, role: .cancel) {
                selectedChannelForAdd = nil
            }
        }
        .onAppear {
            rebuildSearchIndex()
        }
        .onChange(of: playlistManager.playlists) { _, _ in
            rebuildSearchIndex()
            if !localSearchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                performSearch(localSearchText)
            }
        }
        .onExitCommand {
            searchCancellable?.cancel()
        }
    }

    private func rebuildSearchIndex() {
        let token = UUID()
        indexBuildToken = token
        let playlistsSnapshot = playlistManager.playlists

        // FIX: unified to Task.detached (consistent with rest of codebase)
        Task.detached(priority: .userInitiated) {
            var items: [SearchResult] = []
            items.reserveCapacity(playlistsSnapshot.reduce(0) { $0 + $1.channels.count })
            for playlist in playlistsSnapshot {
                let name = playlist.name
                for channel in playlist.channels {
                    items.append(SearchResult(channel: channel, playlistName: name))
                }
            }
            await MainActor.run {
                guard self.indexBuildToken == token else { return }
                self.searchIndex = items
            }
        }
    }

    private func performSearch(_ searchText: String) {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { filteredResults = []; return }

        let token = UUID()
        searchToken = token
        let snapshot = searchIndex

        // FIX: unified to Task.detached; improved relevance sort (prefix matches first)
        Task.detached(priority: .userInitiated) {
            let lowercaseQuery = query.lowercased()

            let filtered = snapshot.filter { item in
                item.searchName.contains(lowercaseQuery) ||
                item.searchGroup.contains(lowercaseQuery) ||
                item.searchPlaylist.contains(lowercaseQuery)
            }

            // Sort: exact prefix matches first, then alphabetical
            let sorted = Array(filtered.prefix(200)).sorted { a, b in
                let aPrefix = a.searchName.hasPrefix(lowercaseQuery)
                let bPrefix = b.searchName.hasPrefix(lowercaseQuery)
                if aPrefix != bPrefix { return aPrefix }
                return a.channel.name.localizedCaseInsensitiveCompare(b.channel.name) == .orderedAscending
            }

            await MainActor.run {
                guard self.searchToken == token else { return }
                self.filteredResults = sorted
            }
        }
    }

    private func emptyStateView(icon: String, text: String) -> some View {
        VStack(spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 80))
                .foregroundColor(.white.opacity(0.1))
                .padding(.top, 100)

            Text(text)
                .font(.title3)
                .foregroundColor(.white.opacity(0.3))
        }
    }
}

struct SearchChannelCard: View {
    let channel: Channel
    let playlistName: String
    let isFavorite: Bool
    @ObservedObject var epgManager: EPGManager

    @State private var cachedEPG: String = ""

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)

            HStack(spacing: 14) {
                logoBlock

                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 8) {
                        Text(channel.name)
                            .font(.system(size: 22, weight: .bold))
                            .lineLimit(1)
                            .foregroundColor(.white)

                        if isFavorite {
                            Image(systemName: "heart.fill")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }

                    Text(playlistName)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white.opacity(0.65))
                        .lineLimit(1)

                    Text(cachedEPG)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.white.opacity(0.72))
                        .lineLimit(1)
                }

                Spacer(minLength: 0)
            }
            .padding(16)
        }
        .frame(height: 190)
        .onAppear {
            updateCachedEPG()
        }
        .onChange(of: epgManager.minuteTick) { _, _ in
            updateCachedEPG()
        }
        .onChange(of: epgManager.epgDataTick) { _, _ in
            updateCachedEPG()
        }
    }

    @ViewBuilder
    private var logoBlock: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white.opacity(0.06))

            Image(systemName: channel.isMovie ? "film" : "tv")
                .font(.system(size: 28))
                .foregroundColor(.white.opacity(0.25))
        }
        .frame(width: 98, height: 98)
    }

    private func updateCachedEPG() {
        cachedEPG = epgManager.getCurrentAndNextProgram(for: channel).current
    }
}
