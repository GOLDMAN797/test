import Foundation
import Combine
import UIKit
import zlib

@MainActor
final class PlaylistManager: ObservableObject {
    @Published var playlists: [Playlist] = []
    @Published var epgManager = EPGManager()
    @Published var isLoading: Bool = false

    private var saveTask: Task<Void, Never>?
    private var loadingTasks: [UUID: Task<Void, Never>] = [:]
    private var loadRequestIDs: [UUID: UUID] = [:]

    private var activeLoads: Int = 0 {
        didSet { isLoading = activeLoads > 0 }
    }

    private let maxConcurrentLoads = 2
    private var loadQueue: [UUID] = []
    private var queuedPlaylists: [UUID: Playlist] = [:]

    private var epgRefreshTimer: Timer?
    private var backgroundObserver: NSObjectProtocol?

    private let defaultUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
    private lazy var fallbackUserAgents: [String] = [
        defaultUserAgent,
        "Mozilla/5.0 (AppleTV11,1; U; CPU OS 17_2 like Mac OS X; en_us) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "AppleCoreMedia/1.0.0.21D61 (Apple TV; U; CPU OS 17_2 like Mac OS X; en_us)",
        "Mozilla/5.0 (Linux; Android 9; WinkBox 2 Build/PSV1.210329.021; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.147 Mobile Safari/537.36",
        "Wink/1.31.1"
    ]
    private let maxUserAgentFallbacks = 4

    init() {
        URLCache.shared.memoryCapacity = 50 * 1024 * 1024
        URLCache.shared.diskCapacity   = 200 * 1024 * 1024

        loadPlaylists()
        setupBackgroundSaveObserver()

        Task {
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            startEPGAutoRefresh()
        }
    }

    deinit {
        loadingTasks.values.forEach { $0.cancel() }
        saveTask?.cancel()
        epgRefreshTimer?.invalidate()
        if let obs = backgroundObserver {
            NotificationCenter.default.removeObserver(obs)
        }
    }

    private func setupBackgroundSaveObserver() {
        backgroundObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in self?.forceSave() }
        }
    }

    // MARK: – Save / Load

    func forceSave() {
        saveTask?.cancel()
        saveTask = nil
        FileStorage.saveSync(playlists, filename: "playlists.plist")
    }

    func savePlaylists() {
        FileStorage.save(playlists, filename: "playlists.plist")
    }

    func loadPlaylists() {
        if let decoded = FileStorage.load([Playlist].self, filename: "playlists.plist") {
            playlists = decoded
            return
        }
        if let data = UserDefaults.standard.data(forKey: "SavedPlaylists"),
           let decoded = try? JSONDecoder().decode([Playlist].self, from: data) {
            playlists = decoded
            savePlaylists()
            UserDefaults.standard.removeObject(forKey: "SavedPlaylists")
        }
    }

    func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 300_000_000)
            guard !Task.isCancelled else { return }
            savePlaylists()
        }
    }

    // MARK: – EPG

    func startEPGAutoRefresh() {
        refreshAllEPG()
        epgRefreshTimer?.invalidate()
        epgRefreshTimer = Timer.scheduledTimer(withTimeInterval: 3600, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.refreshAllEPG() }
        }
    }

    private func refreshAllEPG() {
        for playlist in playlists {
            if let url = playlist.epgURL, !url.isEmpty {
                epgManager.fetchEPG(url: url)
            } else if let url = playlist.embeddedEPGUrl, !url.isEmpty {
                epgManager.fetchEPG(url: url)
            }
        }
    }

    // MARK: – CRUD

    func addPlaylist(name: String, m3uURL: String, epgURL: String?) {
        let cleanM3U = m3uURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanM3U.isEmpty, URL(string: cleanM3U) != nil else {
            ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
            return
        }
        let newPlaylist = Playlist(name: name, m3uURL: cleanM3U, epgURL: epgURL)
        playlists.append(newPlaylist)
        scheduleSave()
        fetchChannels(for: newPlaylist)
        if let url = epgURL, !url.isEmpty { epgManager.fetchEPG(url: url) }
    }

    func updatePlaylist(playlist: Playlist, newName: String, newM3U: String, newEPG: String) {
        guard let index = playlists.firstIndex(where: { $0.id == playlist.id }) else { return }
        let oldM3U = playlists[index].m3uURL
        playlists[index].name   = newName
        playlists[index].m3uURL = newM3U
        playlists[index].epgURL = newEPG
        scheduleSave()
        if oldM3U != newM3U { fetchChannels(for: playlists[index]) }
        if !newEPG.isEmpty {
            epgManager.fetchEPG(url: newEPG)
        } else if let embedded = playlists[index].embeddedEPGUrl, !embedded.isEmpty {
            epgManager.fetchEPG(url: embedded)
        }
    }

    func deletePlaylist(_ playlist: Playlist) {
        if let task = loadingTasks[playlist.id] {
            task.cancel()
            loadingTasks.removeValue(forKey: playlist.id)
            if activeLoads > 0 { activeLoads -= 1 }
        }
        loadRequestIDs.removeValue(forKey: playlist.id)
        queuedPlaylists.removeValue(forKey: playlist.id)
        loadQueue.removeAll { $0 == playlist.id }
        playlists.removeAll { $0.id == playlist.id }
        forceSave()
        launchQueuedIfNeeded()
    }

    func addChannel(_ channel: Channel, to playlistId: UUID) {
        guard let index = playlists.firstIndex(where: { $0.id == playlistId }) else { return }
        if playlists[index].channels.contains(where: { $0.id == channel.id || $0.url == channel.url }) { return }
        playlists[index].channels.append(channel)
        playlists[index].lastUpdated = Date()
        scheduleSave()
    }

    // MARK: – Fetch queue

    func fetchChannels(for playlist: Playlist) {
        queuedPlaylists[playlist.id] = playlist
        if !loadQueue.contains(playlist.id) { loadQueue.append(playlist.id) }
        launchQueuedIfNeeded()
    }

    private func launchQueuedIfNeeded() {
        while activeLoads < maxConcurrentLoads, !loadQueue.isEmpty {
            let playlistId = loadQueue.removeFirst()
            guard let playlist = queuedPlaylists[playlistId] else { continue }
            guard let url = URL(string: playlist.m3uURL) else {
                queuedPlaylists.removeValue(forKey: playlistId)
                continue
            }
            loadingTasks[playlist.id]?.cancel()
            loadingTasks.removeValue(forKey: playlist.id)

            let requestID = UUID()
            loadRequestIDs[playlist.id] = requestID
            activeLoads += 1

            let task = Task { [weak self] in
                guard let self else { return }
                await self.fetchChannelsAsync(playlistId: playlist.id, url: url, requestID: requestID)
            }
            loadingTasks[playlist.id] = task
        }
    }

    private func fetchChannelsAsync(playlistId: UUID, url: URL, requestID: UUID) async {
        defer {
            if loadRequestIDs[playlistId] == requestID {
                loadingTasks.removeValue(forKey: playlistId)
            }
            if activeLoads > 0 { activeLoads -= 1 }
            launchQueuedIfNeeded()
        }

        guard let index = playlists.firstIndex(where: { $0.id == playlistId }) else { return }
        let existingCount = playlists[index].channels.count
        let uas = uniqueUserAgents()
        let maxUA = min(maxUserAgentFallbacks, uas.count)
        var lastParsed: (channels: [Channel], embedded: String?)?

        for i in 0..<maxUA {
            guard !Task.isCancelled, loadRequestIDs[playlistId] == requestID else { return }
            do {
                let (localURL, _) = try await NetworkService.shared.downloadToTemp(
                    from: url, headers: ["User-Agent": uas[i]]
                )
                defer { try? FileManager.default.removeItem(at: localURL) }

                let parseURL = try maybeGunzipPlaylist(localURL)
                defer { if parseURL != localURL { try? FileManager.default.removeItem(at: parseURL) } }

                let parsed = try await Task.detached(priority: .userInitiated) {
                    try await M3UParser.parse(url: parseURL)
                }.value

                guard !Task.isCancelled, loadRequestIDs[playlistId] == requestID else { return }
                if parsed.channels.isEmpty, existingCount > 0 {
                    lastParsed = (parsed.channels, parsed.embeddedEPG)
                    continue
                }
                lastParsed = (parsed.channels, parsed.embeddedEPG)
                break
            } catch { continue }
        }

        guard let result = lastParsed else {
            ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
            return
        }
        guard !Task.isCancelled, loadRequestIDs[playlistId] == requestID else { return }
        guard let idx = playlists.firstIndex(where: { $0.id == playlistId }) else { return }

        if result.channels.isEmpty, playlists[idx].channels.count > 0 {
            ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
            return
        }

        playlists[idx].channels       = PlaylistSyncService.mergeChannels(existing: playlists[idx].channels, fetched: result.channels)
        playlists[idx].embeddedEPGUrl = result.embedded
        playlists[idx].lastUpdated    = Date()
        scheduleSave()

        if (playlists[idx].epgURL?.isEmpty ?? true), let embedded = result.embedded, !embedded.isEmpty {
            epgManager.fetchEPG(url: embedded)
        }
    }

    func refreshAndClearCache(for playlist: Playlist) {
        if let url = playlist.epgURL, !url.isEmpty {
            epgManager.fetchEPG(url: url, forceRefresh: true)
        } else if let url = playlist.embeddedEPGUrl, !url.isEmpty {
            epgManager.fetchEPG(url: url, forceRefresh: true)
        }
        fetchChannels(for: playlist)
    }

    func refreshAllPlaylists() {
        guard !playlists.isEmpty else { return }
        epgManager.clearAll()
        for playlist in playlists {
            fetchChannels(for: playlist)
            if let url = playlist.epgURL, !url.isEmpty {
                epgManager.fetchEPG(url: url, forceRefresh: true)
            } else if let url = playlist.embeddedEPGUrl, !url.isEmpty {
                epgManager.fetchEPG(url: url, forceRefresh: true)
            }
        }
    }

    // MARK: – Helpers

    private func uniqueUserAgents() -> [String] {
        var seen = Set<String>(); var out: [String] = []
        for ua in fallbackUserAgents {
            let t = ua.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !t.isEmpty else { continue }
            if seen.insert(t).inserted { out.append(t) }
        }
        return out
    }

    private func maybeGunzipPlaylist(_ url: URL) throws -> URL {
        if !(try isGzipMagic(url)) { return url }

        let outURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("m3u")

        guard let gz = gzopen(url.path, "rb") else { throw URLError(.cannotOpenFile) }
        defer { gzclose(gz) }

        guard let out = fopen(outURL.path, "wb") else { throw URLError(.cannotCreateFile) }
        defer { fclose(out) }

        let bufferSize = 64 * 1024
        let buf = UnsafeMutablePointer<UInt8>.allocate(capacity: bufferSize)
        defer { buf.deallocate() }

        var wroteAny = false
        while true {
            let readCount = gzread(gz, buf, UInt32(bufferSize))
            if readCount > 0 {
                wroteAny = true
                _ = fwrite(buf, 1, Int(readCount), out)
            } else if readCount == 0 {
                break
            } else {
                throw URLError(.cannotDecodeContentData)
            }
        }

        if !wroteAny { throw URLError(.cannotDecodeContentData) }
        return outURL
    }

    private func isGzipMagic(_ url: URL) throws -> Bool {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        let data = try h.read(upToCount: 2) ?? Data()
        return data.count == 2 && data[0] == 0x1f && data[1] == 0x8b
    }
}
