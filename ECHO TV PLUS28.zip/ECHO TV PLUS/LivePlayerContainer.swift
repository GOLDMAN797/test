import SwiftUI
import AVKit
import Network

struct LivePlayerContainer: UIViewControllerRepresentable {
    let player: AVPlayer?
    @ObservedObject var playerManager: PlayerManager
    @ObservedObject var favoritesManager: FavoritesManager
    @ObservedObject var epgManager: EPGManager
    @Binding var showArchive: Bool

    func makeUIViewController(context: Context) -> NativeLivePlayerViewController {
        let controller = playerManager.obtainLiveController()
        controller.player = player
        controller.showsPlaybackControls = true
        controller.allowsPictureInPicturePlayback = true
        controller.requiresLinearPlayback = playerManager.isLive
        controller.transportBarIncludesTitleView = true
        controller.playerManager = playerManager

        setupChannelList(for: controller)
        updateCustomControls(controller)
        return controller
    }

    func updateUIViewController(_ uiViewController: NativeLivePlayerViewController, context: Context) {
        if uiViewController.player != player {
            uiViewController.player = player
        }
        uiViewController.playerManager = playerManager
        uiViewController.requiresLinearPlayback = playerManager.isLive
        uiViewController.allowsPictureInPicturePlayback = true

        if uiViewController.customInfoViewControllers.isEmpty {
            setupChannelList(for: uiViewController)
        }

        updateCustomControls(uiViewController)
    }

    private func setupChannelList(for controller: AVPlayerViewController) {
        if #available(tvOS 15.0, *) {
            let channelView = NativeChannelListView(
                channels: playerManager.playlistChannels,
                playerManager: playerManager,
                epgManager: epgManager
            )
            let infoVC = UIHostingController(rootView: channelView)
            infoVC.view.backgroundColor = .clear
            infoVC.preferredContentSize = CGSize(width: 600, height: 1080)
            infoVC.title = "Channels"
            controller.customInfoViewControllers = [infoVC]
        }
    }

    func updateCustomControls(_ controller: AVPlayerViewController) {
        let lm = LanguageManager.shared
        var actions: [UIAction] = []

        if let currentChannel = playerManager.currentChannel {
            let isFav = favoritesManager.isFavorite(currentChannel)
            let favAction = UIAction(
                title: isFav ? lm.strings.ctxRemoveFav : lm.strings.ctxAddFav,
                image: UIImage(systemName: isFav ? "heart.fill" : "heart")
            ) { [weak favoritesManager] _ in
                favoritesManager?.toggleFavorite(currentChannel)
                self.updateCustomControls(controller)
            }
            actions.append(favAction)

            if currentChannel.hasArchive {
                let archiveAction = UIAction(
                    title: lm.strings.metaArchive,
                    image: UIImage(systemName: "archivebox")
                ) { _ in
                    self.showArchive = true
                }
                actions.append(archiveAction)
            }
        }

        let muteAction = UIAction(
            title: playerManager.isMuted ? lm.strings.ctxUnmute : lm.strings.ctxMute,
            image: UIImage(systemName: playerManager.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
        ) { [weak playerManager] _ in
            playerManager?.toggleMute()
            self.updateCustomControls(controller)
        }
        actions.append(muteAction)

        controller.transportBarCustomMenuItems = actions
    }
}

final class NativeLivePlayerViewController: AVPlayerViewController {
    weak var playerManager: PlayerManager?

    private let monitor = NWPathMonitor()

    override var preferredFocusedView: UIView? { nil }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNetworkMonitor()
    }

    deinit {
        monitor.cancel()
    }

    private func setupNetworkMonitor() {
        monitor.pathUpdateHandler = { [weak self] path in
            guard let currentItem = self?.player?.currentItem else { return }

            DispatchQueue.main.async {
                if path.usesInterfaceType(.wiredEthernet) {
                    currentItem.preferredPeakBitRate = 0
                } else if path.usesInterfaceType(.wifi) {
                    currentItem.preferredPeakBitRate = 10_000_000
                }
            }
        }
        monitor.start(queue: DispatchQueue.global(qos: .background))
    }

    override func pressesBegan(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        guard let manager = playerManager else {
            super.pressesBegan(presses, with: event)
            return
        }

        for press in presses {
            switch press.type {
            case .leftArrow, .rightArrow:
                if isFocusOnControls() {
                    super.pressesBegan(presses, with: event)
                    return
                }

                if press.type == .leftArrow { manager.previousChannel() }
                if press.type == .rightArrow { manager.nextChannel() }
                return
            case .menu:
                handleMenuPress(manager: manager, presses: presses, event: event)
                return
            default:
                super.pressesBegan(presses, with: event)
                return
            }
        }
        super.pressesBegan(presses, with: event)
    }

    private func handleMenuPress(manager: PlayerManager, presses: Set<UIPress>, event: UIPressesEvent?) {
        if showsPlaybackControls {
            super.pressesBegan(presses, with: event)
        } else {
            customInfoViewControllers = []
            manager.dismissPlayerUI()
        }
    }

    private func isFocusOnControls() -> Bool {
        guard let window = view.window,
              let focusedItem = UIFocusSystem.focusSystem(for: window)?.focusedItem as? UIView else { return false }
        if focusedItem === view { return false }
        return focusedItem is UIControl || focusedItem is UITableViewCell || focusedItem is UICollectionViewCell
    }
}
