import SwiftUI

struct DigitalClockView: View {
    @ObservedObject var lm = LanguageManager.shared
    
    var body: some View {
        TimelineView(.periodic(from: .now, by: 60.0)) { context in
            Text(formatDate(context.date))
                .font(.system(size: 28, weight: .light, design: .default))
                .foregroundColor(.white.opacity(0.6))
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        let localeID = (lm.current == .ru) ? "ru_RU" : "en_US"
        formatter.locale = Locale(identifier: localeID)
        
        formatter.dateFormat = "EEEE d MMMM  HH:mm"
        
        let string = formatter.string(from: date)
        return string.capitalized
    }
}
