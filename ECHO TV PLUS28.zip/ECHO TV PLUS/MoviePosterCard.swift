import SwiftUI

struct MoviePosterCard: View {
    let channel: Channel
    
    @State private var posterURL: URL?
    @State private var isImageLoaded = false
    @State private var showInfoSheet = false
    
    @EnvironmentObject var epgManager: EPGManager

    private func safeURL(_ string: String?) -> URL? {
        guard let s = string, !s.isEmpty else { return nil }
        if let u = URL(string: s) { return u }
        if let encoded = s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            return URL(string: encoded)
        }
        return nil
    }

    var body: some View {
        Color.clear
            .aspectRatio(2 / 3, contentMode: .fit)
            .overlay {
                ZStack {
                    Color.white.opacity(0.1)

                    if let url = posterURL {
                        GeometryReader { geo in
                            OptimizedPosterView(
                                url: url,
                                width: geo.size.width,
                                height: geo.size.height
                            )
                            .position(x: geo.size.width / 2, y: geo.size.height / 2)
                            .onAppear { isImageLoaded = true }
                        }
                    } else {
                        fallbackView
                    }

                    VStack {
                        Spacer()
                        ZStack(alignment: .bottom) {
                            LinearGradient(
                                colors: [.black.opacity(0.9), .clear],
                                startPoint: .bottom,
                                endPoint: .top
                            )
                            .frame(height: 30)

                            Text(channel.name)
                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                                .lineLimit(1)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 8)
                                .padding(.bottom, 12)
                                .shadow(radius: 2)
                        }
                    }
                }
                .clipped()
            }
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .contentShape(Rectangle())
            .onLongPressGesture(minimumDuration: 0.5) {
                showInfoSheet = true
            }
            .sheet(isPresented: $showInfoSheet) {
                ChannelInfoSheet(channel: channel, epgManager: epgManager)
            }
            .task(id: channel.id) {
                if let cached = TMDBService.shared.getCachedURL(for: channel.name) {
                    self.posterURL = cached
                    return
                }

                if let logoUrl = safeURL(channel.logo) {
                    self.posterURL = logoUrl
                } else {
                    self.posterURL = nil
                }

                try? await Task.sleep(nanoseconds: 200_000_000)
                if Task.isCancelled { return }

                if let tmdbPoster = await TMDBService.shared.getPosterURL(for: channel.name) {
                    self.posterURL = tmdbPoster
                }
            }
    }

    var fallbackView: some View {
        ZStack {
            Color.white.opacity(0.05)
            VStack(spacing: 10) {
                Image(systemName: "film")
                    .font(.system(size: 40))
                    .foregroundColor(.white.opacity(0.2))

                if posterURL == nil {
                    Text(channel.name)
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.4))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
            }
        }
    }
}

struct ChannelInfoSheet: View {
    let channel: Channel
    @ObservedObject var epgManager: EPGManager
    @Environment(\.dismiss) var dismiss
    @StateObject private var lm = LanguageManager.shared
    
    @State private var displayTitle: String = ""
    @State private var displayDescription: String = ""
    @State private var isLoading: Bool = true

    var body: some View {
        ZStack {
            Color.black.opacity(0.6)
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 30) {
                if isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(1.5)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    VStack(alignment: .leading, spacing: 16) {
                        Text(displayTitle)
                            .font(.system(size: 48, weight: .bold))
                            .foregroundColor(.white)
                            .lineLimit(1)
                        
                        Text(channel.isMovie ? lm.strings.metaMovie.uppercased() : lm.strings.actionInfoChannel.uppercased())
                            .font(.system(size: 20, weight: .heavy))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color.pink.opacity(0.8))
                            .cornerRadius(8)
                            .foregroundColor(.white)
                        
                        ScrollView {
                            Text(displayDescription)
                                .font(.system(size: 28, weight: .regular))
                                .foregroundColor(.white.opacity(0.8))
                                .lineSpacing(8)
                                .multilineTextAlignment(.leading)
                                .padding(.bottom, 40)
                        }
                    }
                    .padding(.top, 40)
                }
            }
            .padding(60)
            
            VStack {
                HStack {
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.white.opacity(0.8))
                    }
                    .buttonStyle(.plain)
                    .padding(40)
                }
                Spacer()
            }
        }
        .onAppear {
            displayTitle = lm.strings.loadingMovieInfo
        }
        .task {
            await loadInfo()
        }
    }
    
    private func loadInfo() async {
        if channel.isMovie {
            if let info = await TMDBService.shared.getMovieInfo(for: channel.name) {
                let yearStr = info.year != nil ? " (\(info.year!))" : ""
                displayTitle = info.title + yearStr
                displayDescription = info.overview.isEmpty ? lm.strings.movieNoDescription : info.overview
            } else {
                displayTitle = channel.name
                displayDescription = lm.strings.movieInfoNotFound
            }
        } else {
            let now = Date()
            let programs = epgManager.getPrograms(for: channel)
            
            if let currentProg = programs.first(where: { $0.start <= now && $0.stop > now }) {
                displayTitle = currentProg.title
                displayDescription = currentProg.desc ?? lm.strings.epgNoDescription
            } else {
                displayTitle = channel.name
                displayDescription = lm.strings.epgNoInfo
            }
        }
        
        withAnimation(.easeIn(duration: 0.3)) {
            isLoading = false
        }
    }
}
