import Foundation

struct M3UParser {

    nonisolated static func parse(url: URL) async throws -> (channels: [Channel], embeddedEPG: String?) {
        var channels: [Channel] = []
        var embeddedEPG: String? = nil

        var currentName: String?
        var currentLogo: String?
        var currentGroup: String?
        var currentEPGId: String?
        var currentUA: String?
        var currentReferer: String?
        var currentCatchupType: String?
        var currentCatchupSource: String?
        var currentCatchupDays: String?

        for try await rawLine in url.lines {
            let trimmed = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { continue }

            if trimmed.hasPrefix("#EXTM3U") {
                embeddedEPG =
                    extractAttributeFlexible(line: trimmed, key: "url-tvg") ??
                    extractAttributeFlexible(line: trimmed, key: "x-tvg-url")
                continue
            }

            if trimmed.hasPrefix("#EXTVLCOPT:") {
                let optLine = String(trimmed.dropFirst("#EXTVLCOPT:".count)).trimmingCharacters(in: .whitespacesAndNewlines)
                let lower = optLine.lowercased()

                func value(after prefix: String) -> String {
                    String(optLine.dropFirst(prefix.count)).trimmingCharacters(in: .whitespacesAndNewlines)
                }

                if lower.hasPrefix("http-user-agent=") {
                    currentUA = value(after: "http-user-agent=")
                    continue
                }
                if lower.hasPrefix("user-agent=") {
                    currentUA = value(after: "user-agent=")
                    continue
                }

                if lower.hasPrefix("http-referrer=") {
                    currentReferer = value(after: "http-referrer=")
                    continue
                }
                if lower.hasPrefix("http-referer=") {
                    currentReferer = value(after: "http-referer=")
                    continue
                }
                if lower.hasPrefix("referrer=") {
                    currentReferer = value(after: "referrer=")
                    continue
                }
                if lower.hasPrefix("referer=") {
                    currentReferer = value(after: "referer=")
                    continue
                }

                continue
            }

            if trimmed.hasPrefix("#EXTINF:") {
                currentName = nil
                currentLogo = extractAttributeFlexible(line: trimmed, key: "tvg-logo")
                currentGroup = extractAttributeFlexible(line: trimmed, key: "group-title")
                currentEPGId = extractAttributeFlexible(line: trimmed, key: "tvg-id")

                currentCatchupType = extractAttributeFlexible(line: trimmed, key: "catchup")
                currentCatchupSource = extractAttributeFlexible(line: trimmed, key: "catchup-source")
                currentCatchupDays = extractAttributeFlexible(line: trimmed, key: "catchup-days") ??
                                    extractAttributeFlexible(line: trimmed, key: "tvg-rec")

                if let commaIndex = trimmed.lastIndex(of: ",") {
                    currentName = String(trimmed[trimmed.index(after: commaIndex)...]).trimmingCharacters(in: .whitespaces)
                } else {
                    currentName = currentGroup ?? "Unknown Channel"
                }
                continue
            }

            if trimmed.hasPrefix("#") { continue }

            guard let name = currentName else { continue }
            defer {
                currentName = nil
                currentLogo = nil
                currentGroup = nil
                currentEPGId = nil
                currentUA = nil
                currentReferer = nil
                currentCatchupType = nil
                currentCatchupSource = nil
                currentCatchupDays = nil
            }

            guard let u = URL(string: trimmed), u.scheme != nil else { continue }

            let channel = Channel(
                name: name,
                url: trimmed,
                group: currentGroup,
                logo: currentLogo,
                epgId: currentEPGId,
                userAgent: currentUA,
                referer: currentReferer,
                catchupType: currentCatchupType,
                catchupSource: currentCatchupSource,
                catchupDays: currentCatchupDays
            )
            channels.append(channel)
        }

        return (channels, embeddedEPG)
    }

    nonisolated(unsafe) private static let attrRegexCache = NSCache<NSString, NSRegularExpression>()

    nonisolated private static func extractAttributeFlexible(line: String, key: String) -> String? {
        let quotedPattern = "\\b\(NSRegularExpression.escapedPattern(for: key))\\s*=\\s*\"([^\"]+)\""
        if let value = extract(line: line, pattern: quotedPattern) { return value }

        let unquotedPattern = "\\b\(NSRegularExpression.escapedPattern(for: key))\\s*=\\s*([^\\s,]+)"
        return extract(line: line, pattern: unquotedPattern)
    }

    nonisolated private static func extract(line: String, pattern: String) -> String? {
        let regex: NSRegularExpression
        if let cached = attrRegexCache.object(forKey: pattern as NSString) {
            regex = cached
        } else {
            guard let compiled = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
            regex = compiled
            attrRegexCache.setObject(regex, forKey: pattern as NSString)
        }

        let range = NSRange(line.startIndex..., in: line)
        guard let match = regex.firstMatch(in: line, range: range),
              let valueRange = Range(match.range(at: 1), in: line) else { return nil }
        return String(line[valueRange]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
