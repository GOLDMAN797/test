import Foundation
import AVKit
import Combine
import UIKit

struct ArchiveItem: Identifiable, Equatable {
    let id = UUID()
    let url: URL
    let title: String
    let description: String?
}

@MainActor
final class PlayerManager: ObservableObject {
    enum PlayerMode: Equatable {
        case live
        case archive
    }

    @Published var mode: PlayerMode = .live
    @Published var player: AVQueuePlayer?
    @Published var currentChannel: Channel?
    @Published var showPlayer: Bool = false
    @Published var isLive: Bool = true
    @Published var isMuted: Bool = false
    @Published var isPiPActive: Bool = false
    @Published var showResumeAlert: Bool = false
    @Published var pendingResumeTime: Double = 0
    @Published var activeArchive: ArchiveItem?

    enum PlaybackState: Equatable {
        case idle, opening, buffering, playing, failed, closing
    }

    @Published private(set) var playbackState: PlaybackState = .idle

    var allChannels: [Channel] = []
    var playlistChannels: [Channel] = []

    private var queuedNextChannelID: String?

    private let audioSession: AVAudioSession = .sharedInstance()
    private var stopSubject = PassthroughSubject<Void, Never>()
    private var cancellables = Set<AnyCancellable>()

    private lazy var pipDelegateProxy = PiPDelegateProxy(manager: self)
    private var retainedLiveController: NativeLivePlayerViewController?
    private var retainedMovieController: NativeMoviePlayerViewController?
    private var pendingPiPRestoreCompletion: ((Bool) -> Void)?

    private let channelSwitchCooldown: TimeInterval = PlayerConstants.channelSwitchCooldown
    private let minSwitchInterval: TimeInterval = PlayerConstants.minSwitchInterval
    private let liveStartupTimeout: TimeInterval = PlayerConstants.liveStartupTimeout
    private let archiveStartupTimeout: TimeInterval = PlayerConstants.archiveStartupTimeout
    private let liveRetryDelay: TimeInterval = PlayerConstants.liveRetryDelay
    private let maxLiveRetries = PlayerConstants.maxLiveRetries

    private var isTransitioning = false
    private var pendingChannelSwitch: (channel: Channel, isArchive: Bool)?
    private var transitionToken = UUID()
    private var lastSwitchTime: CFTimeInterval = 0
    private var lastPlayStartTime: CFTimeInterval = 0
    private var lastMetadata: (channelName: String, currentProgram: String, nextProgram: String)?
    private var liveRetryCount: Int = 0
    private var liveRetryToken = UUID()

    private var timeControlObserver: AnyCancellable?
    private var statusObserver: AnyCancellable?
    private var seekableObserver: NSKeyValueObservation?
    private var stalledObserver: AnyCancellable?
    private var failedObserver: AnyCancellable?

    private var startupTimeoutWorkItem: DispatchWorkItem?
    private var switchUnlockWorkItem: DispatchWorkItem?

    private let defaultUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15"
    private let winkUserAgent = "WINK/1.0"

    private lazy var fallbackUserAgents: [String] = [
        defaultUserAgent,
        winkUserAgent,
        "Mozilla/5.0 (AppleTV11,1; U; CPU OS 17_2 like Mac OS X; en_us) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "AppleCoreMedia/1.0.0.21D61 (Apple TV; U; CPU OS 17_2 like Mac OS X; en_us)"
    ]

    private let maxUserAgentFallbacks = PlayerConstants.maxUserAgentFallbacks
    private var userAgentRetryCount: Int = 0

    private var uaByHost: [String: String] = [:]
    private var itemUAInfo: [ObjectIdentifier: (host: String, ua: String, channelId: String)] = [:]

    init() {
        stopSubject
            .debounce(for: .milliseconds(150), scheduler: DispatchQueue.main)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.performStop(fullReset: true)
            }
            .store(in: &cancellables)

        NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.handleMemoryWarning()
            }
        }
    }

    private func handleMemoryWarning() {
        if !showPlayer {
            cleanupPlayer()
        }
        uaByHost.removeAll()
        itemUAInfo.removeAll()
    }

    func setup(with channels: [Channel]) {
        allChannels = channels
        playlistChannels = channels
    }

    func loadArchive(url: URL, title: String, description: String? = nil, channel: Channel? = nil) {
        cleanupPlayer()

        mode = .archive
        isLive = false
        showResumeAlert = false
        activeArchive = ArchiveItem(url: url, title: title, description: description)

        showPlayer = true
        playbackState = .buffering

        var headers: [String: String] = [:]
        if let ch = channel {
            headers["User-Agent"] = resolveUserAgent(for: ch, overrideIndex: nil)
            if let ref = ch.referer, !ref.isEmpty {
                headers["Referer"] = ref
            }
        } else {
            headers["User-Agent"] = defaultUserAgent
        }

        var assetOptions: [String: Any] = [:]
        assetOptions["AVURLAssetHTTPHeaderFieldsKey"] = headers
        assetOptions[AVURLAssetPreferPreciseDurationAndTimingKey] = true

        let asset = AVURLAsset(url: url, options: assetOptions)
        let item = AVPlayerItem(asset: asset)
        item.automaticallyPreservesTimeOffsetFromLive = false
        if #available(tvOS 14.0, *) {
            item.canUseNetworkResourcesForLiveStreamingWhilePaused = false
        }
        item.preferredForwardBufferDuration = 10
        item.preferredPeakBitRate = 0

        let lm = LanguageManager.shared
        let safeDescription = description ?? ""
        let subtitle = safeDescription.isEmpty ? lm.strings.metaArchive : safeDescription.replacingOccurrences(of: "\n", with: " ")

        item.externalMetadata = PlayerMetadataService.shared.createMetadata(title: title, subtitle: subtitle, description: safeDescription)

        player = AVQueuePlayer(playerItem: item)
        player?.actionAtItemEnd = .pause
        player?.automaticallyWaitsToMinimizeStalling = false
        setupPlayerObservers()
        setupItemObservers(for: item, isLive: false)

        player?.playImmediately(atRate: 1.0)
        applyStartupTimeout(forArchive: true)
    }

    func returnToLive() {
        guard let channel = currentChannel else { return }
        activeArchive = nil
        mode = .live
        playChannel(channel, forceRestart: true)
    }

    private func host(for channel: Channel) -> String? {
        URL(string: channel.url)?.host?.lowercased()
    }

    private func resolveUserAgent(for channel: Channel, overrideIndex: Int?) -> String {
        if let ua = channel.userAgent, !ua.isEmpty {
            return ua
        }

        if let idx = overrideIndex, idx >= 0, idx < fallbackUserAgents.count {
            return fallbackUserAgents[idx]
        }

        if let h = host(for: channel), let cached = uaByHost[h], !cached.isEmpty {
            return cached
        }

        return fallbackUserAgents.first ?? defaultUserAgent
    }

    private func registerUAInfo(for item: AVPlayerItem, channel: Channel, resolvedUA: String) {
        guard let h = host(for: channel), !h.isEmpty else { return }
        itemUAInfo[ObjectIdentifier(item)] = (host: h, ua: resolvedUA, channelId: channel.id)
    }

    private func commitUserAgentForCurrentItemIfNeeded() {
        guard mode == .live, isLive else { return }
        guard let channel = currentChannel else { return }
        guard channel.userAgent?.isEmpty ?? true else { return }
        guard let item = player?.currentItem else { return }

        let key = ObjectIdentifier(item)
        guard let info = itemUAInfo[key] else { return }
        uaByHost[info.host] = info.ua
        userAgentRetryCount = 0
    }

    private func nextUserAgentOverrideIndex(for currentUA: String) -> Int? {
        if fallbackUserAgents.isEmpty { return nil }
        if userAgentRetryCount >= maxUserAgentFallbacks { return nil }

        var start = 0
        if let idx = fallbackUserAgents.firstIndex(of: currentUA) {
            start = idx + 1
        }

        while start < fallbackUserAgents.count, fallbackUserAgents[start] == currentUA {
            start += 1
        }

        guard start < fallbackUserAgents.count else { return nil }
        return start
    }

    private func attemptUserAgentRecoveryIfPossible() -> Bool {
        guard mode == .live, isLive else { return false }
        guard let channel = currentChannel else { return false }
        guard channel.userAgent?.isEmpty ?? true else { return false }
        guard host(for: channel) != nil else { return false }
        guard let item = player?.currentItem else { return false }

        let info = itemUAInfo[ObjectIdentifier(item)]
        let currentUA = info?.ua ?? resolveUserAgent(for: channel, overrideIndex: nil)
        guard let nextIdx = nextUserAgentOverrideIndex(for: currentUA) else { return false }

        userAgentRetryCount += 1
        playChannel(channel, forceRestart: true, userAgentOverrideIndex: nextIdx)
        return true
    }

    private func createPlayerItem(for channel: Channel, userAgentOverrideIndex: Int? = nil) -> AVPlayerItem {
        let isLiveStream = !channel.isMovie
        guard let url = URL(string: channel.url) else {
            return AVPlayerItem(url: URL(fileURLWithPath: ""))
        }

        let resolvedUA = resolveUserAgent(for: channel, overrideIndex: userAgentOverrideIndex)

        var headers: [String: String] = [:]
        headers["User-Agent"] = resolvedUA
        if let ref = channel.referer, !ref.isEmpty {
            headers["Referer"] = ref
        }

        var assetOptions: [String: Any] = [:]
        if !headers.isEmpty { assetOptions["AVURLAssetHTTPHeaderFieldsKey"] = headers }
        if !isLiveStream { assetOptions[AVURLAssetPreferPreciseDurationAndTimingKey] = true }

        let asset = AVURLAsset(url: url, options: assetOptions)
        let item = AVPlayerItem(asset: asset)

        if isLiveStream {
            if #available(tvOS 14.0, *) {
                item.canUseNetworkResourcesForLiveStreamingWhilePaused = true
            }
            item.preferredForwardBufferDuration = 2
            item.automaticallyPreservesTimeOffsetFromLive = true
            item.preferredPeakBitRate = 0
        } else {
            if #available(tvOS 14.0, *) {
                item.canUseNetworkResourcesForLiveStreamingWhilePaused = false
            }
            item.preferredForwardBufferDuration = 10
            item.automaticallyPreservesTimeOffsetFromLive = false
        }

        let lm = LanguageManager.shared
        let initialSubtitle: String
        if isLiveStream {
            initialSubtitle = lm.strings.metaLoading
        } else if let group = channel.group, !group.isEmpty {
            initialSubtitle = group
        } else {
            initialSubtitle = lm.strings.metaMovie
        }

        item.externalMetadata = PlayerMetadataService.shared.createMetadata(
            title: channel.name,
            subtitle: initialSubtitle,
            description: ""
        )

        registerUAInfo(for: item, channel: channel, resolvedUA: resolvedUA)
        return item
    }

    private func pruneQueueToCurrent() {
        guard let player, let currentItem = player.currentItem else { return }
        for item in player.items() where item !== currentItem {
            itemUAInfo.removeValue(forKey: ObjectIdentifier(item))
            player.remove(item)
        }
    }

    private func preloadAdjacentChannels() {
        guard mode == .live, isLive, showPlayer else { return }
        guard let player, player.currentItem != nil else { return }
        guard !playlistChannels.isEmpty, let current = currentChannel else {
            queuedNextChannelID = nil
            return
        }
        guard let idx = playlistChannels.firstIndex(where: { $0.id == current.id }) else {
            queuedNextChannelID = nil
            return
        }

        let nextIdx = (idx + 1) % playlistChannels.count
        let nextChannel = playlistChannels[nextIdx]

        pruneQueueToCurrent()

        guard nextChannel.id != current.id, let currentItem = player.currentItem else {
            queuedNextChannelID = nil
            return
        }

        let nextItem = createPlayerItem(for: nextChannel, userAgentOverrideIndex: nil)
        if player.canInsert(nextItem, after: currentItem) {
            player.insert(nextItem, after: currentItem)
            queuedNextChannelID = nextChannel.id
        } else {
            itemUAInfo.removeValue(forKey: ObjectIdentifier(nextItem))
            queuedNextChannelID = nil
        }
    }

    private func canFastAdvance(to channel: Channel, isArchive: Bool, forceRestart: Bool) -> Bool {
        guard !forceRestart, !isArchive else { return false }
        guard mode == .live, isLive, !channel.isMovie else { return false }
        guard showPlayer, !showResumeAlert else { return false }
        guard let player else { return false }
        guard queuedNextChannelID == channel.id else { return false }
        let items = player.items()
        guard items.count >= 2 else { return false }
        return true
    }

    private func fastAdvance(to channel: Channel, thisTransition: UUID) {
        guard let player else { return }

        invalidateLiveRetry()
        cancelItemObservers()

        currentChannel = channel
        showPlayer = true
        showResumeAlert = false
        lastMetadata = nil

        player.isMuted = isMuted
        player.actionAtItemEnd = .none

        player.advanceToNextItem()

        guard let newItem = player.currentItem else {
            isTransitioning = false
            playbackState = .failed
            ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
            return
        }

        setupItemObservers(for: newItem, isLive: true)

        guard showPlayer, currentChannel?.id == channel.id, transitionToken == thisTransition else {
            isTransitioning = false
            playbackState = .idle
            return
        }

        player.play()
        applyStartupTimeout(forArchive: false)
        preloadAdjacentChannels()

        switchUnlockWorkItem?.cancel()
        let unlock = DispatchWorkItem { [weak self] in self?.isTransitioning = false }
        switchUnlockWorkItem = unlock
        DispatchQueue.main.asyncAfter(deadline: .now() + channelSwitchCooldown, execute: unlock)

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) { [weak self] in
            guard let self, self.transitionToken == thisTransition, let pending = self.pendingChannelSwitch else { return }
            self.pendingChannelSwitch = nil
            self.playChannel(pending.channel, isArchive: pending.isArchive)
        }
    }

    func playChannel(_ channel: Channel, isArchive: Bool = false, forceRestart: Bool = false, userAgentOverrideIndex: Int? = nil) {
        let isSameChannel = (currentChannel?.id == channel.id)
        if !isSameChannel {
            userAgentRetryCount = 0
        }

        if currentChannel?.isMovie == true {
            saveCurrentProgress()
        }

        mode = .live
        activeArchive = nil

        let now = CACurrentMediaTime()
        if !forceRestart && now - lastSwitchTime < minSwitchInterval {
            pendingChannelSwitch = (channel, isArchive)
            return
        }
        lastSwitchTime = now

        if !forceRestart && currentChannel?.id == channel.id && player != nil && !isArchive { return }

        if isTransitioning && !forceRestart {
            pendingChannelSwitch = (channel, isArchive)
            return
        }

        isTransitioning = true
        transitionToken = UUID()
        let thisTransition = transitionToken
        playbackState = .opening
        lastPlayStartTime = CACurrentMediaTime()

        if canFastAdvance(to: channel, isArchive: isArchive, forceRestart: forceRestart) {
            isLive = true
            fastAdvance(to: channel, thisTransition: thisTransition)
            return
        }

        isLive = !channel.isMovie

        invalidateLiveRetry()
        cancelItemObservers()

        currentChannel = channel
        showPlayer = true
        showResumeAlert = false
        lastMetadata = nil

        do {
            try audioSession.setCategory(.playback, mode: .moviePlayback)
            try audioSession.setActive(true)
        } catch {}

        if !isLive {
            let savedTime = PlaybackHistoryService.shared.getSavedTime(for: channel.url)
            if savedTime > 10 {
                pendingResumeTime = savedTime
                showResumeAlert = true
            }
        }

        queuedNextChannelID = nil
        pruneQueueToCurrent()

        let targetItem = createPlayerItem(for: channel, userAgentOverrideIndex: userAgentOverrideIndex)

        if !isLive {
            Task { [weak self] in
                guard let self, let rawName = self.currentChannel?.name else { return }
                let info = await TMDBService.shared.getMovieInfo(for: rawName)
                await MainActor.run {
                    guard self.currentChannel?.id == channel.id else { return }
                    if let fetched = info {
                        self.updateMetadata(channelName: fetched.title, currentProgram: fetched.year ?? "", nextProgram: fetched.overview)
                    }
                }
            }
        }

        if player == nil {
            player = AVQueuePlayer(playerItem: targetItem)
            player?.allowsExternalPlayback = true
            setupPlayerObservers()
        } else {
            player?.pause()
            player?.removeAllItems()
            if player?.canInsert(targetItem, after: nil) == true {
                player?.insert(targetItem, after: nil)
            }
        }

        player?.actionAtItemEnd = isLive ? .none : .pause
        player?.isMuted = isMuted

        setupItemObservers(for: targetItem, isLive: isLive)

        guard showPlayer, currentChannel?.id == channel.id, transitionToken == thisTransition else {
            isTransitioning = false
            playbackState = .idle
            return
        }

        if showResumeAlert {
            player?.pause()
        } else {
            player?.play()
        }

        applyStartupTimeout(forArchive: false)
        preloadAdjacentChannels()

        switchUnlockWorkItem?.cancel()
        let unlock = DispatchWorkItem { [weak self] in self?.isTransitioning = false }
        switchUnlockWorkItem = unlock
        DispatchQueue.main.asyncAfter(deadline: .now() + channelSwitchCooldown, execute: unlock)

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.30) { [weak self] in
            guard let self, self.transitionToken == thisTransition, let pending = self.pendingChannelSwitch else { return }
            self.pendingChannelSwitch = nil
            self.playChannel(pending.channel, isArchive: pending.isArchive)
        }
    }

    func updateMetadata(channelName: String, currentProgram: String, nextProgram: String) {
        guard showPlayer, playbackState != .closing, playbackState != .idle else { return }
        if mode == .archive { return }
        lastMetadata = (channelName, currentProgram, nextProgram)
        guard let item = player?.currentItem else { return }
        item.externalMetadata = PlayerMetadataService.shared.createMetadata(title: channelName, subtitle: currentProgram, description: nextProgram)
    }

    private func setupPlayerObservers() {
        guard let player = player, timeControlObserver == nil else { return }
        timeControlObserver = player.publisher(for: \.timeControlStatus)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] status in
                guard let self else { return }
                switch status {
                case .playing:
                    self.cancelStartupTimeout()
                    self.playbackState = .playing
                    self.commitUserAgentForCurrentItemIfNeeded()
                case .waitingToPlayAtSpecifiedRate:
                    if self.playbackState != .opening { self.playbackState = .buffering }
                case .paused:
                    if ![.closing, .idle, .failed].contains(self.playbackState), !self.showResumeAlert {
                        self.playbackState = .buffering
                    }
                @unknown default:
                    break
                }
            }
    }

    private func setupItemObservers(for item: AVPlayerItem, isLive: Bool) {
        cancelItemObservers()

        statusObserver = item.publisher(for: \.status)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] status in
                guard let self else { return }
                if status == .readyToPlay {
                    if self.playbackState == .opening { self.playbackState = .buffering }
                    if !self.isLive { self.checkArchiveSeekability(item: item) }
                } else if status == .failed {
                    self.cancelStartupTimeout()
                    if self.attemptUserAgentRecoveryIfPossible() {
                        return
                    }
                    self.playbackState = .failed
                    self.isTransitioning = false
                    ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
                }
            }

        if !isLive {
            seekableObserver = item.observe(\.seekableTimeRanges, options: [.new]) { [weak self] i, _ in
                guard let self else { return }
                if !i.seekableTimeRanges.isEmpty {
                    Task { @MainActor in self.objectWillChange.send() }
                }
            }
        }

        if isLive, let channel = currentChannel {
            installLiveRecoveryObservers(for: item, channel: channel)
        }
    }

    private func checkArchiveSeekability(item: AVPlayerItem) {
        if !item.seekableTimeRanges.isEmpty,
           item.duration.seconds.isFinite,
           item.duration.seconds > 0 {
            objectWillChange.send()
        }
    }

    private func invalidateLiveRetry() {
        liveRetryToken = UUID()
        liveRetryCount = 0
    }

    private func installLiveRecoveryObservers(for item: AVPlayerItem, channel: Channel) {
        let cid = channel.id

        stalledObserver = NotificationCenter.default.publisher(for: .AVPlayerItemPlaybackStalled, object: item)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                guard let self, self.isLive, self.currentChannel?.id == cid else { return }
                self.scheduleLiveRetry(channel: channel)
            }

        failedObserver = NotificationCenter.default.publisher(for: .AVPlayerItemFailedToPlayToEndTime, object: item)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                guard let self, self.isLive, self.currentChannel?.id == cid else { return }
                self.scheduleLiveRetry(channel: channel)
            }
    }

    private func scheduleLiveRetry(channel: Channel) {
        guard currentChannel?.id == channel.id, liveRetryCount < maxLiveRetries else { return }
        liveRetryCount += 1
        let token = UUID()
        liveRetryToken = token

        Task { @MainActor [weak self] in
            guard let self else { return }
            try? await Task.sleep(nanoseconds: UInt64(liveRetryDelay * 1_000_000_000))
            guard self.liveRetryToken == token, self.currentChannel?.id == channel.id else { return }

            self.player?.play()
            try? await Task.sleep(nanoseconds: 600_000_000)
            guard self.liveRetryToken == token, self.currentChannel?.id == channel.id else { return }

            if self.player?.timeControlStatus != .playing {
                self.playChannel(channel, forceRestart: true)
            }
        }
    }

    func nextChannel() { changeChannel(offset: 1) }
    func previousChannel() { changeChannel(offset: -1) }

    private func changeChannel(offset: Int) {
        guard !playlistChannels.isEmpty,
              let current = currentChannel,
              let idx = playlistChannels.firstIndex(where: { $0.id == current.id }) else { return }
        guard !isTransitioning else { return }

        let nextIdx = (idx + offset + playlistChannels.count) % playlistChannels.count
        playChannel(playlistChannels[nextIdx])
    }

    func toggleMute() {
        isMuted.toggle()
        player?.isMuted = isMuted
    }

    func stop() {
        stopSubject.send()
    }

    private func performStop(fullReset: Bool = true, keepInterface: Bool = false) {
        pendingPiPRestoreCompletion?(false)
        pendingPiPRestoreCompletion = nil
        isPiPActive = false

        let inStartupWindow = (CACurrentMediaTime() - lastPlayStartTime) < 1.0
        if playbackState == .opening || (isTransitioning && inStartupWindow) {
            playbackState = .closing
            transitionToken = UUID()
            pendingChannelSwitch = nil
            isTransitioning = false
            invalidateLiveRetry()
            cleanupPlayer()
            if fullReset { currentChannel = nil }
            if !keepInterface { showPlayer = false }
            showResumeAlert = false
            playbackState = .idle
            return
        }

        if !isLive { saveCurrentProgress() }

        playbackState = .closing
        cleanupPlayer()

        do {
            try audioSession.setActive(false, options: .notifyOthersOnDeactivation)
        } catch {}

        if fullReset { currentChannel = nil }
        if !keepInterface { showPlayer = false }

        showResumeAlert = false
        isTransitioning = false
        pendingChannelSwitch = nil
        playbackState = .idle
    }

    func resumeVideo() {
        player?.seek(to: CMTime(seconds: pendingResumeTime, preferredTimescale: 600))
        player?.play()
        showResumeAlert = false
        applyStartupTimeout(forArchive: !isLive)
    }

    func startOver() {
        player?.seek(to: .zero)
        player?.play()
        showResumeAlert = false
        applyStartupTimeout(forArchive: !isLive)
    }

    private func applyStartupTimeout(forArchive: Bool = false) {
        startupTimeoutWorkItem?.cancel()
        let timeout = forArchive ? archiveStartupTimeout : liveStartupTimeout
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            if [.opening, .buffering].contains(self.playbackState),
               self.player?.timeControlStatus != .playing {
                if self.attemptUserAgentRecoveryIfPossible() {
                    return
                }
                if let c = self.currentChannel, self.isLive, self.liveRetryCount < self.maxLiveRetries {
                    self.scheduleLiveRetry(channel: c)
                } else {
                    self.playbackState = .failed
                    ErrorManager.shared.showError(LanguageManager.shared.strings.errorPlaybackFailed)
                }
            }
        }
        startupTimeoutWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + timeout, execute: work)
    }

    private func cancelStartupTimeout() {
        startupTimeoutWorkItem?.cancel()
        startupTimeoutWorkItem = nil
    }

    private func cleanupPlayer() {
        cancelStartupTimeout()
        switchUnlockWorkItem?.cancel()
        switchUnlockWorkItem = nil

        cancelItemObservers()
        timeControlObserver?.cancel()
        timeControlObserver = nil

        queuedNextChannelID = nil
        itemUAInfo.removeAll()
        userAgentRetryCount = 0

        retainedLiveController?.player = nil
        retainedMovieController?.player = nil

        player?.pause()
        player?.removeAllItems()
        player = nil
    }

    private func cancelItemObservers() {
        statusObserver?.cancel()
        statusObserver = nil
        seekableObserver?.invalidate()
        seekableObserver = nil

        stalledObserver?.cancel()
        failedObserver?.cancel()
        stalledObserver = nil
        failedObserver = nil
    }


        private func saveCurrentProgress() {
            guard !isLive, let current = currentChannel, let p = player, let item = p.currentItem else { return }
            let watched = p.currentTime().seconds
            let dur = item.duration.seconds.isFinite && item.duration.seconds > 0 ? item.duration.seconds : nil
            PlaybackHistoryService.shared.saveProgress(
                url: current.url,
                title: current.name,
                time: watched,
                duration: dur
            )
        }

    func obtainLiveController() -> NativeLivePlayerViewController {
        if let vc = retainedLiveController {
            configurePiP(on: vc)
            vc.playerManager = self
            return vc
        }
        let vc = NativeLivePlayerViewController()
        vc.playerManager = self
        configurePiP(on: vc)
        retainedLiveController = vc
        return vc
    }

    func obtainMovieController() -> NativeMoviePlayerViewController {
        if let vc = retainedMovieController {
            configurePiP(on: vc)
            vc.playerManager = self
            return vc
        }
        let vc = NativeMoviePlayerViewController()
        vc.playerManager = self
        configurePiP(on: vc)
        retainedMovieController = vc
        return vc
    }

    private func configurePiP(on controller: AVPlayerViewController) {
        controller.allowsPictureInPicturePlayback = true
        #if os(iOS)
        if #available(iOS 14.0, *) {
            controller.canStartPictureInPictureAutomaticallyFromInline = true
        }
        #endif
        controller.delegate = pipDelegateProxy
    }

    func dismissPlayerUI() {
        showResumeAlert = false
        if isPiPActive {
            showPlayer = false
        } else {
            stop()
        }
    }

    private func pipWillStart() {
        isPiPActive = true
    }

    private func pipDidStart() {
        isPiPActive = true
        retainedLiveController?.customInfoViewControllers = []
        if showPlayer {
            showPlayer = false
        }
    }

    private func pipDidStop() {
        isPiPActive = false
        if !showPlayer {
            stop()
        }
    }

    private func pipFailedToStart() {
        isPiPActive = false
    }

    private func handlePiPRestore(completion: @escaping (Bool) -> Void) {
        pendingPiPRestoreCompletion = completion
        isPiPActive = true
        showPlayer = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            guard let self else { return }
            let c = self.pendingPiPRestoreCompletion
            self.pendingPiPRestoreCompletion = nil
            c?(true)
        }
    }

    private final class PiPDelegateProxy: NSObject, AVPlayerViewControllerDelegate {
        weak var manager: PlayerManager?

        init(manager: PlayerManager) {
            self.manager = manager
            super.init()
        }

        func playerViewControllerShouldAutomaticallyDismissAtPictureInPictureStart(_ playerViewController: AVPlayerViewController) -> Bool {
            Task { @MainActor in
                self.manager?.pipWillStart()
            }
            return false
        }

        func playerViewControllerWillStartPictureInPicture(_ playerViewController: AVPlayerViewController) {
            Task { @MainActor in
                self.manager?.pipWillStart()
            }
        }

        func playerViewControllerDidStartPictureInPicture(_ playerViewController: AVPlayerViewController) {
            Task { @MainActor in
                self.manager?.pipDidStart()
            }
        }

        func playerViewControllerDidStopPictureInPicture(_ playerViewController: AVPlayerViewController) {
            Task { @MainActor in
                self.manager?.pipDidStop()
            }
        }

        func playerViewController(_ playerViewController: AVPlayerViewController, failedToStartPictureInPictureWithError error: Error) {
            Task { @MainActor in
                self.manager?.pipFailedToStart()
            }
        }

        func playerViewController(
            _ playerViewController: AVPlayerViewController,
            restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void
        ) {
            Task { @MainActor in
                self.manager?.handlePiPRestore(completion: completionHandler)
            }
        }
    }

    func closeArchive() {
        stop()
    }
}
