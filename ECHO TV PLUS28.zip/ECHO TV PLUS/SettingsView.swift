import SwiftUI

struct SettingsView: View {
    @ObservedObject var playlistManager: PlaylistManager
    @ObservedObject var lm = LanguageManager.shared
    
    var onRefreshAll: () -> Void

    @State private var showAppInfo = false
    @State private var showAddSheet = false
    @State private var showBackgroundSheet = false
    @State private var playlistToEdit: Playlist?
    @State private var playlistToDelete: Playlist?

    private static let titleFontSize: CGFloat = 22
    private static let headerFontSize: CGFloat = 24

    var body: some View {
        ScrollView {
            VStack(spacing: 50) {
                HStack(spacing: 70) {
                    
                    Button(action: {
                        lm.toggleLanguage()
                    }) {
                        HStack(spacing: 12) {
                            Image(systemName: "globe")
                                .font(.system(size: 38))
                            Text(lm.strings.languageBtn)
                                .font(.system(size: Self.titleFontSize, weight: .semibold))
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .buttonStyle(.glass)
                    .frame(height: 70)
                    
                    Button(action: { showAddSheet = true }) {
                        HStack(spacing: 12) {
                            Image(systemName: "plus")
                                .font(.system(size: 38))
                            Text(lm.strings.addPlaylistBtn)
                                .font(.system(size: Self.titleFontSize, weight: .semibold))
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .buttonStyle(.glass)
                    .frame(height: 70)

                    Button(action: { showBackgroundSheet = true }) {
                        HStack(spacing: 12) {
                            Image(systemName: "photo")
                                .font(.system(size: 38))
                            Text(lm.strings.backgroundBtn)
                                .font(.system(size: Self.titleFontSize, weight: .semibold))
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .buttonStyle(.glass)
                    .frame(height: 70)

                    Button(action: { showAppInfo = true }) {
                        HStack(spacing: 12) {
                            Image(systemName: "info.circle")
                                .font(.system(size: 38))
                            Text(lm.strings.appInfoBtn)
                                .font(.system(size: Self.titleFontSize, weight: .semibold))
                        }
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .buttonStyle(.glass)
                    .frame(height: 70)
                }
                .padding(.horizontal, 40)
                .padding(.top, 60)

                if !playlistManager.playlists.isEmpty {
                    VStack(alignment: .leading, spacing: 20) {
                        HStack {
                            Text(lm.strings.playlistsHeader)
                                .font(.system(size: Self.headerFontSize, weight: .semibold))
                                .foregroundColor(.white.opacity(0.5))
                                .padding(.leading, 10)
                            Spacer()
                        }

                        LazyVStack(spacing: 20) {
                            ForEach(playlistManager.playlists) { playlist in
                                PlaylistSettingsRow(
                                    playlist: playlist,
                                    onRefresh: { playlistManager.refreshAndClearCache(for: playlist) },
                                    onEdit: { playlistToEdit = playlist },
                                    onDelete: { playlistToDelete = playlist }
                                )
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 40)
            .padding(.bottom, 40)
        }
        .fullScreenCover(isPresented: $showAppInfo) {
            AppInfoView()
        }
        .fullScreenCover(isPresented: $showAddSheet) {
            PlaylistFormView(mode: .add, playlistManager: playlistManager)
        }
        .fullScreenCover(isPresented: $showBackgroundSheet) {
            ChangeBackgroundSheet()
        }
        .fullScreenCover(item: $playlistToEdit) { playlist in
            PlaylistFormView(mode: .edit(playlist), playlistManager: playlistManager)
        }
        .alert(item: $playlistToDelete) { playlist in
            Alert(
                title: Text(lm.strings.deleteTitle),
                message: Text("\(lm.strings.deleteMessage) '\(playlist.name)'?"),
                primaryButton: .destructive(Text(lm.strings.deleteConfirm)) {
                    playlistManager.deletePlaylist(playlist)
                },
                secondaryButton: .cancel(Text(lm.strings.cancel))
            )
        }
    }
}

struct PlaylistSettingsRow: View {
    let playlist: Playlist
    var onRefresh: () -> Void
    var onEdit: () -> Void
    var onDelete: () -> Void
    
    @ObservedObject var lm = LanguageManager.shared

    private static let iconSize: CGFloat = 40
    private static let titleFontSize: CGFloat = 30
    private static let subtitleFontSize: CGFloat = 20

    var body: some View {
        HStack {
            HStack(spacing: 24) {
                Image(systemName: "tv")
                    .font(.system(size: Self.iconSize, weight: .light))
                    .foregroundColor(.white.opacity(0.7))

                VStack(alignment: .leading, spacing: 6) {
                    Text(playlist.name)
                        .font(.system(size: Self.titleFontSize, weight: .bold))
                        .foregroundColor(.white)
                    Text("\(playlist.channels.count) \(lm.strings.channelsCount)")
                        .font(.system(size: Self.subtitleFontSize, weight: .medium))
                        .foregroundColor(.white.opacity(0.4))
                }
            }

            Spacer()

            HStack(spacing: 40) {
                Button(action: onRefresh) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 30, weight: .medium))
                }
                .buttonStyle(RowActionButtonStyle(isDestructive: false))

                Button(action: onEdit) {
                    Image(systemName: "pencil.line")
                        .font(.system(size: 30, weight: .medium))
                }
                .buttonStyle(RowActionButtonStyle(isDestructive: false))

                Button(action: onDelete) {
                    Image(systemName: "trash")
                        .font(.system(size: 30, weight: .medium))
                }
                .buttonStyle(RowActionButtonStyle(isDestructive: true))
            }
            .padding(.trailing, 20)
        }
        .padding(.horizontal, 40)
        .padding(.vertical, 60)
        .background(.ultraThinMaterial)
    }
}

struct RowActionButtonStyle: ButtonStyle {
    var isDestructive: Bool
    @Environment(\.isFocused) var isFocused

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(width: 80, height: 80)
            .background(isFocused ? (isDestructive ? Color.red : Color.white) : Color.white.opacity(0.1))
            .foregroundColor(isFocused ? (isDestructive ? .white : .black) : (isDestructive ? .red : .white.opacity(0.8)))
            .clipShape(Circle())
            .scaleEffect(isFocused ? 1.15 : 1.0)
            .animation(.easeOut(duration: 0.2), value: isFocused)
    }
}

struct LabeledInputBlock: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    var isActive: Bool

    private static let labelFontSize: CGFloat = 20
    private static let fieldFontSize: CGFloat = 32

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(label.uppercased())
                .font(.system(size: Self.labelFontSize, weight: .medium))
                .foregroundColor(.white.opacity(0.4))
                .padding(.leading, 4)

            TextField(placeholder, text: $text)
                .padding(.horizontal, 5)
                .padding(.vertical, 5)
                .font(.system(size: Self.fieldFontSize, weight: .medium))
        }
    }
}

struct ChangeBackgroundSheet: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var lm = LanguageManager.shared
    @State private var tempURL: String = ""

    enum Field: Hashable { case url }
    @FocusState private var focusedField: Field?

    private static let headerFontSize: CGFloat = 40
    private static let windowWidth: CGFloat = 1000

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                Text(lm.strings.backgroundTitle)
                    .font(.system(size: Self.headerFontSize, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 50)
                    .padding(.bottom, 40)

                VStack(spacing: 30) {
                    LabeledInputBlock(
                        label: lm.strings.backgroundLabel,
                        placeholder: lm.strings.backgroundPlaceholder,
                        text: $tempURL,
                        isActive: focusedField == .url
                    )
                    .focused($focusedField, equals: .url)
                }
                .padding(.horizontal, 60)
                .padding(.bottom, 50)

                HStack(spacing: 40) {
                    Button(action: {
                        let safeURL = tempURL
                        Task { @MainActor in
                            await BackgroundManager.shared.updateBackground(with: safeURL)
                            dismiss()
                        }
                    }) {
                        Text(lm.strings.save).padding(.horizontal, 20)
                    }

                    Button(action: { dismiss() }) {
                        Text(lm.strings.cancel).padding(.horizontal, 20)
                    }
                }
                .padding(.horizontal, 60)
                .padding(.bottom, 50)
            }
            .frame(width: Self.windowWidth)
            .background(.ultraThinMaterial)
            .cornerRadius(16)
        }
        .onAppear {
            tempURL = BackgroundManager.shared.customURL
            focusedField = .url
        }
    }
}

struct AppInfoView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var lm = LanguageManager.shared

    private let iconColumnWidth: CGFloat = 50

    var body: some View {
        ZStack {
            Color.black.opacity(0.4)
                .background(.ultraThinMaterial)
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 50) {
                    HStack {
                        VStack(alignment: .leading, spacing: 20) {
                            Text(lm.strings.infoHeaderTitle)
                                .font(.system(size: 60, weight: .heavy, design: .rounded))
                                .foregroundColor(.white)
                            Text(lm.strings.infoHeaderSubtitle)
                                .font(.system(size: 32, weight: .medium))
                                .foregroundColor(.white.opacity(0.8))
                        }
                        Spacer()
                        Button(action: { dismiss() }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 60))
                        }
                        .buttonStyle(.glass)
                    }
                    .padding(.bottom, 10)

                    InfoSectionView(
                        icon: "lock.shield",
                        title: lm.strings.secPrivacyTitle,
                        content: AnyView(
                            VStack(alignment: .leading, spacing: 30) {
                                Text(lm.strings.secPrivacyDesc)
                                    .font(.system(size: 28))
                                    .foregroundColor(.white.opacity(0.9))
                                Divider().background(Color.white.opacity(0.3))
                                BulletPoint(icon: "appletv.fill", text: lm.strings.secPrivacyPoint1)
                                BulletPoint(icon: "snowflake", text: lm.strings.secPrivacyPoint2)
                            }
                            .padding(.vertical, 10)
                        )
                    )

                    InfoSectionView(
                        icon: "play.display",
                        title: lm.strings.secNavTitle,
                        content: AnyView(
                            VStack(alignment: .leading, spacing: 30) {
                                Text(lm.strings.secNavDesc)
                                    .font(.system(size: 28))
                                    .foregroundColor(.white.opacity(0.9))
                                Divider().background(Color.white.opacity(0.3))

                                VStack(alignment: .leading, spacing: 20) {
                                    HStack(spacing: 20) {
                                        Image(systemName: "tv")
                                            .font(.system(size: 30))
                                            .foregroundColor(.white)
                                            .frame(width: iconColumnWidth, alignment: .center)

                                        Text(lm.strings.secNavLiveTitle)
                                            .font(.system(size: 30, weight: .bold))
                                            .foregroundColor(.white)
                                    }

                                    BulletPoint(icon: "arrow.left.and.right", text: lm.strings.secNavLiveLR)
                                    BulletPoint(icon: "arrow.up.and.down", text: lm.strings.secNavLiveUD)
                                }
                                .padding(.vertical, 10)

                                VStack(alignment: .leading, spacing: 20) {
                                    HStack(spacing: 20) {
                                        Image(systemName: "film")
                                            .font(.system(size: 30))
                                            .foregroundColor(.white)
                                            .frame(width: iconColumnWidth, alignment: .center)

                                        Text(lm.strings.secNavVodTitle)
                                            .font(.system(size: 30, weight: .bold))
                                            .foregroundColor(.white)
                                    }

                                    BulletPoint(icon: "10.arrow.trianglehead.clockwise", text: lm.strings.secNavVodLR)
                                    BulletPoint(icon: "arrow.up.and.down", text: lm.strings.secNavVodUD)
                                }
                            }
                        )
                    )

                    InfoSectionView(
                        icon: "hands.and.sparkles",
                        title: lm.strings.secFeatTitle,
                        content: AnyView(
                            VStack(alignment: .leading, spacing: 30) {
                                Text(lm.strings.secFeatDesc)
                                    .font(.system(size: 28))
                                    .foregroundColor(.white)
                                Divider().background(Color.white.opacity(0.3))

                                IconTextRow(icon: "heart", text: lm.strings.secFeatFav)
                                IconTextRow(icon: "clock", text: lm.strings.secFeatHist)
                                IconTextRow(icon: "movieclapper", text: lm.strings.secFeatPoster)
                                IconTextRow(icon: "checklist", text: lm.strings.secFeatEpg)
                            }
                        )
                    )

                    InfoSectionView(
                        icon: "slider.horizontal.3",
                        title: lm.strings.secToolTitle,
                        content: AnyView(
                            VStack(alignment: .leading, spacing: 30) {
                                Text(lm.strings.secToolDesc)
                                    .font(.system(size: 28))
                                    .foregroundColor(.white)
                                Divider().background(Color.white.opacity(0.3))

                                IconTextRow(icon: "magnifyingglass", text: lm.strings.secToolSearch)
                                IconTextRow(icon: "arrow.clockwise", text: lm.strings.secToolUpdate)
                                IconTextRow(icon: "pencil.line", text: lm.strings.secToolEdit)
                                IconTextRow(icon: "gauge.with.dots.needle.67percent", text: lm.strings.secToolSmooth)
                            }
                        )
                    )

                    InfoSectionView(
                        icon: "text.document",
                        title: lm.strings.secM3uTitle,
                        content: AnyView(
                            VStack(alignment: .leading, spacing: 30) {
                                Text(lm.strings.secM3uDesc)
                                    .font(.system(size: 28))
                                    .foregroundColor(.white)
                                Divider().background(Color.white.opacity(0.3))

                                BulletPoint(text: lm.strings.secM3uPoint1)
                                BulletPoint(text: lm.strings.secM3uPoint2)

                                VStack(alignment: .leading, spacing: 20) {
                                    Text(lm.strings.secM3uExample)
                                        .font(.system(size: 24, weight: .bold))
                                        .foregroundColor(.white.opacity(0.5))

                                    Text("""
                                    #EXTM3U tvg-url="https://epg.example.com/xmltv.xml"

                                    #EXTINF:-1 tvg-id="1tv" group-title="Федеральные", Первый Канал
                                    https://server.com/live/1tv/index.m3u8

                                    #EXTINF:-1 group-title="movie", Интерстеллар [2014]
                                    https://server.com/vod/interstellar.mkv
                                    """)
                                    .font(.system(size: 24, design: .monospaced))
                                    .foregroundColor(.green.opacity(0.8))
                                    .padding(30)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(Color.white.opacity(0.1))
                                    .cornerRadius(16)
                                }
                                
                                .padding(.top, 15)
                            }
                        )
                    )
                    InfoSectionView(
                        icon: "exclamationmark.circle",
                        title: lm.strings.secImportantTitle,
                        content: AnyView(
                            VStack(alignment: .leading, spacing: 30) {
                                Text(lm.strings.secImportantDesc)
                                    .font(.system(size: 28))
                                    .foregroundColor(.white.opacity(0.9))
                                Divider().background(Color.white.opacity(0.3))

                                VStack(alignment: .leading, spacing: 20) {
                                    HStack(spacing: 20) {
                                        Image(systemName: "server.rack")
                                            .font(.system(size: 30))
                                            .foregroundColor(.white)
                                            .frame(width: iconColumnWidth, alignment: .center)

                                        Text(lm.strings.secLicenseTitle)
                                            .font(.system(size: 30, weight: .bold))
                                            .foregroundColor(.white)
                                    }

                                    BulletPoint(text: lm.strings.secLicenseDesc)
                                    
                                }
                                .padding(.vertical, 10)

                                VStack(alignment: .leading, spacing: 20) {
                                    HStack(spacing: 20) {
                                        Image(systemName: "hand.raised")
                                            .font(.system(size: 30))
                                            .foregroundColor(.white)
                                            .frame(width: iconColumnWidth, alignment: .center)

                                        Text(lm.strings.secDisclaimerTitle)
                                            .font(.system(size: 30, weight: .bold))
                                            .foregroundColor(.white)
                                    }

                                    BulletPoint(text: lm.strings.secDisclaimerDesc)
                                }
                            }
                        )
                    )

                    Spacer(minLength: 40)

                    Text(lm.strings.versionText)
                        .font(.system(size: 26))
                        .foregroundColor(.white.opacity(0.4))
                        .frame(maxWidth: .infinity)
                }
                .padding(80)
            }
        }
    }
}

struct InfoSectionView: View {
    let icon: String
    let title: String
    let content: AnyView
    @Environment(\.isFocused) var isFocused

    var body: some View {
        VStack(alignment: .leading, spacing: 30) {
            HStack(alignment: .center, spacing: 25) {
                Image(systemName: icon)
                    .font(.system(size: 55, weight: .regular))
                    .foregroundColor(.white)
                    .frame(width: 70, alignment: .center)

                Text(title)
                    .font(.system(size: 48, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
            }

            content
                .padding(.leading, 10)
        }
        .padding(50)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(isFocused ? Color.white.opacity(0.2) : Color.white.opacity(0.05))
        .cornerRadius(30)
        .scaleEffect(isFocused ? 1.02 : 1.0)
        .animation(.easeOut(duration: 0.2), value: isFocused)
        .focusable(true)
    }
}

struct IconTextRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .center, spacing: 25) {
            Image(systemName: icon)
                .font(.system(size: 35, weight: .regular))
                .foregroundColor(.white)
                .frame(width: 70, alignment: .center)

            Text(text)
                .font(.system(size: 28))
                .foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

struct BulletPoint: View {
    var icon: String? = nil
    var color: Color = .white
    var iconSize: CGFloat = 32
    let text: String

    var body: some View {
        HStack(alignment: .center, spacing: 20) {
            if let iconName = icon {
                Image(systemName: iconName)
                    .font(.system(size: iconSize, weight: .semibold))
                    .foregroundColor(color)
                    .frame(width: 50, alignment: .center)
            } else {
                ZStack {
                    Circle()
                        .fill(color)
                        .frame(width: 10, height: 10)
                }
                .frame(width: 50, alignment: .center)
            }

            Text(text)
                .font(.system(size: 28))
                .foregroundColor(.white.opacity(0.9))
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
