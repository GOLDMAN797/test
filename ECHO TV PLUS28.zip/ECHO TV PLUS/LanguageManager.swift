import SwiftUI
import Combine

enum AppLanguage: String {
    case en
    case ru
}

// MARK: – Grouped string namespaces
// Each struct covers one functional area of the app.
// Adding a new language means implementing all 7 structs — no field can be missed silently.

struct CommonStrings {
    var cancel: String
    var save: String
    var loading: String
    var appTitle: String
}

struct PlaylistStrings {
    var addPlaylistBtn: String
    var playlistsHeader: String
    var channelsCount: String
    var deleteTitle: String
    var deleteMessage: String
    var deleteConfirm: String
    var addFormTitle: String
    var editFormTitle: String
    var labelName: String
    var placeholderName: String
    var labelM3U: String
    var placeholderM3U: String
    var labelEPG: String
    var placeholderEPG: String
    var emptyPlaylists: String
    var btnUpdateAllAndClear: String
    var cacheCleared: String
}

struct PlayerStrings {
    var alertPlaybackTitle: String
    var alertResumeMessage: String
    var btnResume: String
    var btnStartOver: String
    var ctxUnmute: String
    var ctxMute: String
    var metaLoading: String
    var metaMovie: String
    var metaNoInfo: String
    var metaArchive: String
    var btnArchiveMenu: String
    var archiveEmptyDay: String
    var errorPlaybackFailed: String
    var continueWatching: String
    var minutesLeft: String
}

struct EPGStrings {
    var epgNoInfo: String
    var epgNoProgram: String
    var epgNextPrefix: String
    var epgNoDescription: String
    var loadingMovieInfo: String
    var movieInfoNotFound: String
    var movieNoDescription: String
    var metaDuration: String
    var metaMin: String
    var metaGenres: String
    var metaCountries: String
    var metaDirector: String
    var metaCast: String
}

struct UIStrings {
    var languageBtn: String
    var backgroundBtn: String
    var appInfoBtn: String
    var tabPlaylists: String
    var tabSettings: String
    var tabLocal: String
    var sidebarAll: String
    var sidebarFavorites: String
    var searchPlaceholder: String
    var searchStart: String
    var searchNoResult: String
    var backgroundTitle: String
    var backgroundLabel: String
    var backgroundPlaceholder: String
    var ctxRemoveFav: String
    var ctxAddFav: String
    var ctxAddPlaylist: String
    var ctxPlay: String
    var ctxRemoveWatchLater: String
    var dialogAddChannel: String
    var btnEdit: String
    var btnDelete: String
    var actionInfoMovie: String
    var actionInfoChannel: String
    var actionPlay: String
}

struct LocalServerStrings {
    var localLibraryBtn: String
    var localConnectBtn: String
    var localRefreshBtn: String
    var localServersHeader: String
    var localNoServers: String
    var localContinueEmpty: String
    var localConnectTitle: String
    var localEditTitle: String
    var localHostLabel: String
    var localShareLabel: String
    var localUsernameLabel: String
    var localPasswordLabel: String
    var localHostPlaceholder: String
    var localSharePlaceholder: String
    var localUsernamePlaceholder: String
    var localPasswordPlaceholder: String
    var localStatusOnline: String
    var localStatusOffline: String
    var localStatusUnknown: String
    var localErrorFillRequired: String
    var localErrorConnectFailed: String
    var localErrorMissingCredentials: String
    var localErrorLoadFailed: String
    var localDeleteServerTitle: String
    var localDeleteServerMessage: String
    var localCleanupBtn: String
    var localCleanupTitle: String
    var localCleanupClearPosterCache: String
    var localCleanupClearContinue: String
    var localFolderLabel: String
}

struct AppInfoStrings {
    var infoHeaderTitle: String
    var infoHeaderSubtitle: String
    var secPrivacyTitle: String
    var secPrivacyDesc: String
    var secPrivacyPoint1: String
    var secPrivacyPoint2: String
    var secNavTitle: String
    var secNavDesc: String
    var secNavLiveTitle: String
    var secNavLiveLR: String
    var secNavLiveUD: String
    var secNavVodTitle: String
    var secNavVodLR: String
    var secNavVodUD: String
    var secFeatTitle: String
    var secFeatDesc: String
    var secFeatFav: String
    var secFeatHist: String
    var secFeatPoster: String
    var secFeatEpg: String
    var secToolTitle: String
    var secToolDesc: String
    var secToolSearch: String
    var secToolUpdate: String
    var secToolEdit: String
    var secToolSmooth: String
    var secM3uTitle: String
    var secM3uDesc: String
    var secM3uPoint1: String
    var secM3uPoint2: String
    var secM3uExample: String
    var versionText: String
    var secLicenseTitle: String
    var secLicenseDesc: String
    var secDisclaimerTitle: String
    var secDisclaimerDesc: String
    var secImportantTitle: String
    var secImportantDesc: String
}

// MARK: – Flat façade (backwards-compatible)
// All existing call sites use `lm.strings.someKey` — this façade preserves that API
// while the actual strings are now grouped in typed sub-structs above.

struct LocalizedStrings {
    let common: CommonStrings
    let playlist: PlaylistStrings
    let player: PlayerStrings
    let epg: EPGStrings
    let ui: UIStrings
    let local: LocalServerStrings
    let info: AppInfoStrings

    // MARK: Common
    var cancel: String     { common.cancel }
    var save: String       { common.save }
    var loading: String    { common.loading }
    var appTitle: String   { common.appTitle }

    // MARK: Playlist
    var addPlaylistBtn: String     { playlist.addPlaylistBtn }
    var playlistsHeader: String    { playlist.playlistsHeader }
    var channelsCount: String      { playlist.channelsCount }
    var deleteTitle: String        { playlist.deleteTitle }
    var deleteMessage: String      { playlist.deleteMessage }
    var deleteConfirm: String      { playlist.deleteConfirm }
    var addFormTitle: String       { playlist.addFormTitle }
    var editFormTitle: String      { playlist.editFormTitle }
    var labelName: String          { playlist.labelName }
    var placeholderName: String    { playlist.placeholderName }
    var labelM3U: String           { playlist.labelM3U }
    var placeholderM3U: String     { playlist.placeholderM3U }
    var labelEPG: String           { playlist.labelEPG }
    var placeholderEPG: String     { playlist.placeholderEPG }
    var emptyPlaylists: String     { playlist.emptyPlaylists }
    var btnUpdateAllAndClear: String { playlist.btnUpdateAllAndClear }
    var cacheCleared: String       { playlist.cacheCleared }

    // MARK: Player
    var alertPlaybackTitle: String  { player.alertPlaybackTitle }
    var alertResumeMessage: String  { player.alertResumeMessage }
    var btnResume: String           { player.btnResume }
    var btnStartOver: String        { player.btnStartOver }
    var ctxUnmute: String           { player.ctxUnmute }
    var ctxMute: String             { player.ctxMute }
    var metaLoading: String         { player.metaLoading }
    var metaMovie: String           { player.metaMovie }
    var metaNoInfo: String          { player.metaNoInfo }
    var metaArchive: String         { player.metaArchive }
    var btnArchiveMenu: String      { player.btnArchiveMenu }
    var archiveEmptyDay: String     { player.archiveEmptyDay }
    var errorPlaybackFailed: String { player.errorPlaybackFailed }
    var continueWatching: String    { player.continueWatching }
    var minutesLeft: String         { player.minutesLeft }

    // MARK: EPG
    var epgNoInfo: String          { epg.epgNoInfo }
    var epgNoProgram: String       { epg.epgNoProgram }
    var epgNextPrefix: String      { epg.epgNextPrefix }
    var epgNoDescription: String   { epg.epgNoDescription }
    var loadingMovieInfo: String   { epg.loadingMovieInfo }
    var movieInfoNotFound: String  { epg.movieInfoNotFound }
    var movieNoDescription: String { epg.movieNoDescription }
    var metaDuration: String       { epg.metaDuration }
    var metaMin: String            { epg.metaMin }
    var metaGenres: String         { epg.metaGenres }
    var metaCountries: String      { epg.metaCountries }
    var metaDirector: String       { epg.metaDirector }
    var metaCast: String           { epg.metaCast }

    // MARK: UI
    var languageBtn: String          { ui.languageBtn }
    var backgroundBtn: String        { ui.backgroundBtn }
    var appInfoBtn: String           { ui.appInfoBtn }
    var tabPlaylists: String         { ui.tabPlaylists }
    var tabSettings: String          { ui.tabSettings }
    var tabLocal: String             { ui.tabLocal }
    var sidebarAll: String           { ui.sidebarAll }
    var sidebarFavorites: String     { ui.sidebarFavorites }
    var searchPlaceholder: String    { ui.searchPlaceholder }
    var searchStart: String          { ui.searchStart }
    var searchNoResult: String       { ui.searchNoResult }
    var backgroundTitle: String      { ui.backgroundTitle }
    var backgroundLabel: String      { ui.backgroundLabel }
    var backgroundPlaceholder: String { ui.backgroundPlaceholder }
    var ctxRemoveFav: String         { ui.ctxRemoveFav }
    var ctxAddFav: String            { ui.ctxAddFav }
    var ctxAddPlaylist: String       { ui.ctxAddPlaylist }
    var ctxPlay: String              { ui.ctxPlay }
    var ctxRemoveWatchLater: String  { ui.ctxRemoveWatchLater }
    var dialogAddChannel: String     { ui.dialogAddChannel }
    var btnEdit: String              { ui.btnEdit }
    var btnDelete: String            { ui.btnDelete }
    var actionInfoMovie: String      { ui.actionInfoMovie }
    var actionInfoChannel: String    { ui.actionInfoChannel }
    var actionPlay: String           { ui.actionPlay }

    // MARK: Local servers
    var localLibraryBtn: String              { local.localLibraryBtn }
    var localConnectBtn: String              { local.localConnectBtn }
    var localRefreshBtn: String              { local.localRefreshBtn }
    var localServersHeader: String           { local.localServersHeader }
    var localNoServers: String               { local.localNoServers }
    var localContinueEmpty: String          { local.localContinueEmpty }
    var localConnectTitle: String            { local.localConnectTitle }
    var localEditTitle: String               { local.localEditTitle }
    var localHostLabel: String               { local.localHostLabel }
    var localShareLabel: String              { local.localShareLabel }
    var localUsernameLabel: String           { local.localUsernameLabel }
    var localPasswordLabel: String           { local.localPasswordLabel }
    var localHostPlaceholder: String         { local.localHostPlaceholder }
    var localSharePlaceholder: String        { local.localSharePlaceholder }
    var localUsernamePlaceholder: String     { local.localUsernamePlaceholder }
    var localPasswordPlaceholder: String     { local.localPasswordPlaceholder }
    var localStatusOnline: String            { local.localStatusOnline }
    var localStatusOffline: String           { local.localStatusOffline }
    var localStatusUnknown: String           { local.localStatusUnknown }
    var localErrorFillRequired: String       { local.localErrorFillRequired }
    var localErrorConnectFailed: String      { local.localErrorConnectFailed }
    var localErrorMissingCredentials: String { local.localErrorMissingCredentials }
    var localErrorLoadFailed: String         { local.localErrorLoadFailed }
    var localDeleteServerTitle: String       { local.localDeleteServerTitle }
    var localDeleteServerMessage: String     { local.localDeleteServerMessage }
    var localCleanupBtn: String              { local.localCleanupBtn }
    var localCleanupTitle: String            { local.localCleanupTitle }
    var localCleanupClearPosterCache: String { local.localCleanupClearPosterCache }
    var localCleanupClearContinue: String    { local.localCleanupClearContinue }
    var localFolderLabel: String             { local.localFolderLabel }

    // MARK: App Info
    var infoHeaderTitle: String      { info.infoHeaderTitle }
    var infoHeaderSubtitle: String   { info.infoHeaderSubtitle }
    var secPrivacyTitle: String      { info.secPrivacyTitle }
    var secPrivacyDesc: String       { info.secPrivacyDesc }
    var secPrivacyPoint1: String     { info.secPrivacyPoint1 }
    var secPrivacyPoint2: String     { info.secPrivacyPoint2 }
    var secNavTitle: String          { info.secNavTitle }
    var secNavDesc: String           { info.secNavDesc }
    var secNavLiveTitle: String      { info.secNavLiveTitle }
    var secNavLiveLR: String         { info.secNavLiveLR }
    var secNavLiveUD: String         { info.secNavLiveUD }
    var secNavVodTitle: String       { info.secNavVodTitle }
    var secNavVodLR: String          { info.secNavVodLR }
    var secNavVodUD: String          { info.secNavVodUD }
    var secFeatTitle: String         { info.secFeatTitle }
    var secFeatDesc: String          { info.secFeatDesc }
    var secFeatFav: String           { info.secFeatFav }
    var secFeatHist: String          { info.secFeatHist }
    var secFeatPoster: String        { info.secFeatPoster }
    var secFeatEpg: String           { info.secFeatEpg }
    var secToolTitle: String         { info.secToolTitle }
    var secToolDesc: String          { info.secToolDesc }
    var secToolSearch: String        { info.secToolSearch }
    var secToolUpdate: String        { info.secToolUpdate }
    var secToolEdit: String          { info.secToolEdit }
    var secToolSmooth: String        { info.secToolSmooth }
    var secM3uTitle: String          { info.secM3uTitle }
    var secM3uDesc: String           { info.secM3uDesc }
    var secM3uPoint1: String         { info.secM3uPoint1 }
    var secM3uPoint2: String         { info.secM3uPoint2 }
    var secM3uExample: String        { info.secM3uExample }
    var versionText: String          { info.versionText }
    var secLicenseTitle: String      { info.secLicenseTitle }
    var secLicenseDesc: String       { info.secLicenseDesc }
    var secDisclaimerTitle: String   { info.secDisclaimerTitle }
    var secDisclaimerDesc: String    { info.secDisclaimerDesc }
    var secImportantTitle: String    { info.secImportantTitle }
    var secImportantDesc: String     { info.secImportantDesc }
}

// MARK: – LanguageManager

@MainActor
final class LanguageManager: ObservableObject {
    static let shared = LanguageManager()

    private let storageKey = "selectedLanguage"

    @Published private(set) var current: AppLanguage
    @Published private(set) var strings: LocalizedStrings

    private init() {
        let saved = AppLanguage(
            rawValue: UserDefaults.standard.string(forKey: storageKey) ?? AppLanguage.en.rawValue
        ) ?? .en
        self.current = saved
        self.strings = LanguageManager.getStrings(for: saved)
    }

    func toggleLanguage() { setLanguage(current == .en ? .ru : .en) }

    func setLanguage(_ language: AppLanguage) {
        guard current != language else { return }
        current = language
        strings = LanguageManager.getStrings(for: language)
        UserDefaults.standard.set(language.rawValue, forKey: storageKey)
    }

    var currentCode: String { current.rawValue }

    // MARK: – String tables

    static func getStrings(for language: AppLanguage) -> LocalizedStrings {
        switch language {
        case .en: return LocalizedStrings(
            common: CommonStrings(
                cancel: "Cancel", save: "Save",
                loading: "Loading...", appTitle: "ECHO TV+"
            ),
            playlist: PlaylistStrings(
                addPlaylistBtn: "Add Playlist", playlistsHeader: "/ Playlists",
                channelsCount: "channels", deleteTitle: "Delete Playlist?",
                deleteMessage: "Are you sure you want to remove", deleteConfirm: "Delete",
                addFormTitle: "ADD NEW PLAYLIST", editFormTitle: "EDIT PLAYLIST",
                labelName: "Name", placeholderName: "e.g. Sports TV",
                labelM3U: "Playlist URL (M3U)", placeholderM3U: "https://...",
                labelEPG: "EPG URL (Optional)", placeholderEPG: "https://...",
                emptyPlaylists: "No Playlists Found",
                btnUpdateAllAndClear: "Update all and clear cache",
                cacheCleared: "Cache cleared and everything updated"
            ),
            player: PlayerStrings(
                alertPlaybackTitle: "Playback",
                alertResumeMessage: "You have already watched this movie. Do you want to resume?",
                btnResume: "Resume from", btnStartOver: "Start Over",
                ctxUnmute: "Unmute", ctxMute: "Mute",
                metaLoading: "Loading...", metaMovie: "Movie",
                metaNoInfo: "No information", metaArchive: "Archive",
                btnArchiveMenu: "Programs",
                archiveEmptyDay: "No archived programs for the selected date",
                errorPlaybackFailed: "Playback failed. Check the link or try again later.",
                continueWatching: "Continue Watching", minutesLeft: "min left"
            ),
            epg: EPGStrings(
                epgNoInfo: "No information", epgNoProgram: "No program",
                epgNextPrefix: "Next:", epgNoDescription: "Program description is missing in the TV guide",
                loadingMovieInfo: "Loading...", movieInfoNotFound: "Movie information not found",
                movieNoDescription: "Description is missing",
                metaDuration: "Duration:", metaMin: "min", metaGenres: "Genres:",
                metaCountries: "Countries:", metaDirector: "Director:", metaCast: "Cast:"
            ),
            ui: UIStrings(
                languageBtn: "Language: EN", backgroundBtn: "Background",
                appInfoBtn: "App Info", tabPlaylists: "Playlists",
                tabSettings: "Settings", tabLocal: "Local",
                sidebarAll: "All", sidebarFavorites: "Favorites",
                searchPlaceholder: "Search channels...",
                searchStart: "Start typing to search", searchNoResult: "No channels found",
                backgroundTitle: "CHANGE WALLPAPER",
                backgroundLabel: "Image url / Leave empty to use default background",
                backgroundPlaceholder: "...image.jpg (jpeg.png.heic.webp)",
                ctxRemoveFav: "Remove from Favorites", ctxAddFav: "Add to Favorites",
                ctxAddPlaylist: "Add to Playlist", ctxPlay: "Play Now",
                ctxRemoveWatchLater: "Remove from Watch Later",
                dialogAddChannel: "Add channel to playlist",
                btnEdit: "Edit", btnDelete: "Delete",
                actionInfoMovie: "Movie Info", actionInfoChannel: "TV Guide", actionPlay: "Play"
            ),
            local: LocalServerStrings(
                localLibraryBtn: "Local Library", localConnectBtn: "Connect Server",
                localRefreshBtn: "Refresh", localServersHeader: "/ Servers",
                localNoServers: "No servers connected",
                localContinueEmpty: "Nothing here yet",
                localConnectTitle: "CONNECT SERVER", localEditTitle: "EDIT SERVER",
                localHostLabel: "Host", localShareLabel: "Share",
                localUsernameLabel: "Username", localPasswordLabel: "Password",
                localHostPlaceholder: "192.168.1.10", localSharePlaceholder: "Media",
                localUsernamePlaceholder: "user", localPasswordPlaceholder: "password",
                localStatusOnline: "Online", localStatusOffline: "Offline",
                localStatusUnknown: "Unknown",
                localErrorFillRequired: "Please fill required fields.",
                localErrorConnectFailed: "Connection failed. Check your data.",
                localErrorMissingCredentials: "Missing credentials. Edit the server.",
                localErrorLoadFailed: "Failed to load library. Check server status.",
                localDeleteServerTitle: "Delete Server?",
                localDeleteServerMessage: "Are you sure you want to remove",
                localCleanupBtn: "Cleanup", localCleanupTitle: "Cleanup",
                localCleanupClearPosterCache: "Clear poster cache",
                localCleanupClearContinue: "Clear Continue Watching",
                localFolderLabel: "Folder"
            ),
            info: AppInfoStrings(
                infoHeaderTitle: "About App",
                infoHeaderSubtitle: "Created for those who value speed, minimalism, and privacy",
                secPrivacyTitle: "Privacy",
                secPrivacyDesc: "We value your privacy and do not use cloud profiles, registration, or hidden analytics",
                secPrivacyPoint1: "Local on Apple TV: Playlists, history, and favorites are stored strictly on the device",
                secPrivacyPoint2: "You are in control: Delete the app — all local data is deleted. No servers or accounts",
                secNavTitle: "Navigation: Live TV & VOD",
                secNavDesc: "Controls adapt to the viewing scenario for intuitive Siri Remote usage",
                secNavLiveTitle: "Live TV", secNavLiveLR: "Left/Right — Instant channel switching",
                secNavLiveUD: "Up/Down — Additional player menu",
                secNavVodTitle: "Movies (VOD)", secNavVodLR: "Left/Right — Rewind 10 sec",
                secNavVodUD: "Up/Down — Player menu for movies",
                secFeatTitle: "Useful Features",
                secFeatDesc: "Solutions that make viewing intuitive and pleasant",
                secFeatFav: "Global Favorites. One list of favorite channels from all playlists",
                secFeatHist: "Smart History. Up to 10 last watched movies with auto-cleanup",
                secFeatPoster: "Movie Posters. Turns M3U list into a beautiful showcase",
                secFeatEpg: "Built-in EPG. TV guide loads automatically",
                secToolTitle: "Tools & Optimization",
                secToolDesc: "Powerful tools for instant response and stable performance",
                secToolSearch: "Global Search. Instant local search",
                secToolUpdate: "Smart Update. Updates EPG while keeping history",
                secToolEdit: "Editing. Change links without recreating the playlist",
                secToolSmooth: "Smoothness. We recommend 1–5 active playlists",
                secM3uTitle: "The Perfect Playlist",
                secM3uDesc: "Unlock full potential with the correct m3u format",
                secM3uPoint1: "Use group-title=\"Movie\" for poster mode",
                secM3uPoint2: "Specify tvg-id for accurate EPG linking",
                secM3uExample: "Example:", versionText: "Version 1.0.0",
                secLicenseTitle: "Metadata & Artwork",
                secLicenseDesc: "Data provided by TMDB & Kinopoisk Unofficial. The product uses the TMDB API, but is not certified by it",
                secDisclaimerTitle: "Disclaimer",
                secDisclaimerDesc: "No content included. Users are solely responsible for their own playlists",
                secImportantTitle: "Legal Notice",
                secImportantDesc: "Details regarding data sources and content responsibility"
            )
        )

        case .ru: return LocalizedStrings(
            common: CommonStrings(
                cancel: "Отмена", save: "Сохранить",
                loading: "Загрузка...", appTitle: "ЭХО ТВ+"
            ),
            playlist: PlaylistStrings(
                addPlaylistBtn: "Добавить плейлист", playlistsHeader: "/ Плейлисты",
                channelsCount: "каналов", deleteTitle: "Удалить плейлист?",
                deleteMessage: "Вы уверены, что хотите удалить", deleteConfirm: "Удалить",
                addFormTitle: "ДОБАВИТЬ ПЛЕЙЛИСТ", editFormTitle: "РЕДАКТИРОВАТЬ",
                labelName: "Название", placeholderName: "например, Спорт ТВ",
                labelM3U: "Ссылка на плейлист (M3U)", placeholderM3U: "https://...",
                labelEPG: "Ссылка на EPG (Опционально)", placeholderEPG: "https://...",
                emptyPlaylists: "Плейлисты не найдены",
                btnUpdateAllAndClear: "Обновить всё и очистить кэш",
                cacheCleared: "Кэш очищен и всё обновлено"
            ),
            player: PlayerStrings(
                alertPlaybackTitle: "Воспроизведение",
                alertResumeMessage: "Вы уже начали смотреть этот фильм. Хотите продолжить?",
                btnResume: "Продолжить с", btnStartOver: "Сначала",
                ctxUnmute: "Включить звук", ctxMute: "Без звука",
                metaLoading: "Загрузка...", metaMovie: "Фильм",
                metaNoInfo: "Нет информации", metaArchive: "Архив",
                btnArchiveMenu: "Передачи",
                archiveEmptyDay: "Для выбранной даты архивных передач нет",
                errorPlaybackFailed: "Ошибка воспроизведения. Проверьте ссылку или попробуйте позже.",
                continueWatching: "Продолжить просмотр", minutesLeft: "мин осталось"
            ),
            epg: EPGStrings(
                epgNoInfo: "Нет информации", epgNoProgram: "Нет программы",
                epgNextPrefix: "Далее:", epgNoDescription: "Описание передачи отсутствует в телепрограмме",
                loadingMovieInfo: "Загрузка...", movieInfoNotFound: "Информация о фильме не найдена",
                movieNoDescription: "Описание отсутствует",
                metaDuration: "Длительность:", metaMin: "мин", metaGenres: "Жанры:",
                metaCountries: "Страны:", metaDirector: "Режиссер:", metaCast: "В ролях:"
            ),
            ui: UIStrings(
                languageBtn: "Язык: RU", backgroundBtn: "Фон",
                appInfoBtn: "О приложении", tabPlaylists: "Плейлисты",
                tabSettings: "Настройки", tabLocal: "Локально",
                sidebarAll: "Все", sidebarFavorites: "Избранное",
                searchPlaceholder: "Поиск каналов...",
                searchStart: "Начните вводить для поиска", searchNoResult: "Каналы не найдены",
                backgroundTitle: "СМЕНИТЬ ФОН",
                backgroundLabel: "Ссылка на фото / Оставьте поле пустым для сброса",
                backgroundPlaceholder: "...image.jpg (jpeg.png.heic.webp)",
                ctxRemoveFav: "Убрать из избранного", ctxAddFav: "В избранное",
                ctxAddPlaylist: "Добавить в плейлист", ctxPlay: "Смотреть сейчас",
                ctxRemoveWatchLater: "Удалить из Смотреть потом",
                dialogAddChannel: "Добавить канал в плейлист",
                btnEdit: "Изменить", btnDelete: "Удалить",
                actionInfoMovie: "Информация о фильме",
                actionInfoChannel: "Телепрограмма", actionPlay: "Смотреть"
            ),
            local: LocalServerStrings(
                localLibraryBtn: "Локальная библиотека", localConnectBtn: "Подключить сервер",
                localRefreshBtn: "Обновить", localServersHeader: "/ Серверы",
                localNoServers: "Серверы не добавлены",
                localContinueEmpty: "Пока нет просмотров",
                localConnectTitle: "ПОДКЛЮЧИТЬ СЕРВЕР", localEditTitle: "ИЗМЕНИТЬ СЕРВЕР",
                localHostLabel: "Хост", localShareLabel: "Папка",
                localUsernameLabel: "Логин", localPasswordLabel: "Пароль",
                localHostPlaceholder: "192.168.1.10", localSharePlaceholder: "Media",
                localUsernamePlaceholder: "user", localPasswordPlaceholder: "password",
                localStatusOnline: "Онлайн", localStatusOffline: "Оффлайн",
                localStatusUnknown: "Неизвестно",
                localErrorFillRequired: "Заполните обязательные поля.",
                localErrorConnectFailed: "Ошибка подключения. Проверьте данные.",
                localErrorMissingCredentials: "Нет пароля. Измените сервер.",
                localErrorLoadFailed: "Не удалось загрузить библиотеку.",
                localDeleteServerTitle: "Удалить сервер?",
                localDeleteServerMessage: "Вы уверены, что хотите удалить",
                localCleanupBtn: "Очистка", localCleanupTitle: "Очистка",
                localCleanupClearPosterCache: "Очистить кэш постеров",
                localCleanupClearContinue: "Очистить Продолжить просмотр",
                localFolderLabel: "Папка"
            ),
            info: AppInfoStrings(
                infoHeaderTitle: "О приложении",
                infoHeaderSubtitle: "Создано для тех, кто ценит скорость, минимализм и приватность",
                secPrivacyTitle: "Приватность",
                secPrivacyDesc: "Мы ценим вашу приватность и не используем облачные профили, регистрацию и скрытую аналитику",
                secPrivacyPoint1: "Локально на Apple TV: Плейлисты, история и избранное хранятся только в памяти, строго на устройстве",
                secPrivacyPoint2: "Контроль у вас: Удаляете приложение — удаляются и все локальные данные. Никаких серверов и аккаунтов",
                secNavTitle: "Навигация: Live TV и VOD",
                secNavDesc: "Управление адаптируется под сценарий просмотра, чтобы Siri Remote работал интуитивно",
                secNavLiveTitle: "Прямой эфир (Live TV)",
                secNavLiveLR: "Влево/вправо — мгновенное переключение каналов",
                secNavLiveUD: "Вверх/вниз — дополнительное меню плеера",
                secNavVodTitle: "Фильмы (VOD)",
                secNavVodLR: "Влево/вправо — перемотка на 10 сек",
                secNavVodUD: "Вверх/вниз — дополнительное меню плеера для фильма",
                secFeatTitle: "Полезные функции",
                secFeatDesc: "Решения, которые делают просмотр интуитивным и приятным",
                secFeatFav: "Глобальное избранное. Один список любимых каналов из всех плейлистов",
                secFeatHist: "Умная история. До 10 последних просмотренных фильмов с автоочисткой",
                secFeatPoster: "Постеры для фильмов. M3U-список превращается в красивую витрину",
                secFeatEpg: "Встроенный EPG. Программа передач загружается автоматически",
                secToolTitle: "Инструменты и оптимизация",
                secToolDesc: "Мощные инструменты для мгновенного отклика и стабильной работы",
                secToolSearch: "Глобальный поиск. Мгновенный локальный поиск",
                secToolUpdate: "Умное обновление. Обновляет EPG, сохраняя историю",
                secToolEdit: "Редактирование. Меняйте ссылки без пересоздания плейлиста",
                secToolSmooth: "Плавность. Рекомендуем 1–5 активных плейлистов",
                secM3uTitle: "Идеальный плейлист",
                secM3uDesc: "Раскройте полный потенциал плеера с правильным форматом списка m3u",
                secM3uPoint1: "Используйте group-title=\"Movie\" для режима постеров",
                secM3uPoint2: "Указывайте tvg-id для точной привязки EPG",
                secM3uExample: "Пример:", versionText: "Версия 1.0.0",
                secLicenseTitle: "Метаданные и постеры",
                secLicenseDesc: "Данные предоставлены TMDB и Kinopoisk Unofficial. Продукт использует API TMDB, но не сертифицирован им",
                secDisclaimerTitle: "Отказ от ответственности",
                secDisclaimerDesc: "Встроенный контент отсутствует. Пользователь сам несет полную ответственность за свои плейлисты",
                secImportantTitle: "Правовая информация",
                secImportantDesc: "Сведения об источниках данных и ответственности за контент"
            )
        )
        }
    }
}
