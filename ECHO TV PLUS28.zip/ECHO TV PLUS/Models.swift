import Foundation

struct Playlist: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var m3uURL: String
    var epgURL: String?
    var embeddedEPGUrl: String?
    var channels: [Channel] = []
    var lastUpdated: Date = Date()

    var channelCountString: String {
        "\(channels.count) CH"
    }

    static func == (lhs: Playlist, rhs: Playlist) -> Bool {
        lhs.id == rhs.id &&
        lhs.name == rhs.name &&
        lhs.m3uURL == rhs.m3uURL &&
        lhs.epgURL == rhs.epgURL &&
        lhs.embeddedEPGUrl == rhs.embeddedEPGUrl &&
        lhs.channels == rhs.channels
    }
}

struct Channel: Identifiable, Codable, Equatable, Hashable {
    var name: String
    var url: String
    var group: String?
    var logo: String?
    var epgId: String?
    var epgName: String? = nil
    var userAgent: String?
    var referer: String?
    var catchupType: String?
    var catchupSource: String?
    var catchupDays: String?

    var id: String {
        let epg = (epgId ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if !epg.isEmpty { return "epg:\(epg)" }
        return "url:\(url.trimmingCharacters(in: .whitespacesAndNewlines).lowercased())"
    }

    var isMovie: Bool {
        let lowerUrl = url.lowercased()
        let lowerGroup = (group ?? "").lowercased()
        let lowerName = name.lowercased()
        
        // 1. Настоящие видео-файлы (не плейлисты)
        let videoFileExtensions = [".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm", ".ts", ".m4v"]
        if videoFileExtensions.contains(where: { lowerUrl.hasSuffix($0) }) {
            return true
        }
        
        // 2. Явные VOD-группы
        let vodGroupKeywords = ["movie", "vod"]
        if vodGroupKeywords.contains(where: { lowerGroup.contains($0) }) {
            return true
        }
        
        // 3. Год в названии (типично для фильмов)
        if lowerName.contains(#"\(\d{4}\)"#) || lowerName.contains(#"\[\d{4}\]"#) {
            return true
        }
        
        // 4. Исключаем типичные live-признаки
        if lowerUrl.contains(".m3u8") && !lowerGroup.contains("vod") && !lowerGroup.contains("movie") {
            return false
        }
        
        return false
    }
    
    var hasArchive: Bool {
        if let days = catchupDays, days != "0", !days.isEmpty { return true }
        return catchupType != nil || catchupSource != nil
    }

    static func == (lhs: Channel, rhs: Channel) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

struct ArchiveURLBuilder {
    static func build(channel: Channel, program: EPGProgram) -> URL? {
        let startTimestamp = Int64(program.start.timeIntervalSince1970)
        let stopTimestamp = Int64(program.stop.timeIntervalSince1970)
        
        let duration = max(1, stopTimestamp - startTimestamp)
        let nowTimestamp = Int64(Date().timeIntervalSince1970)
        let offset = max(0, nowTimestamp - startTimestamp)

        let base = channel.url.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !base.isEmpty else { return nil }

        // ИСПРАВЛЕНИЕ: Если указан catchup-source, используем его без лишних параметров.
        // Провайдер сам знает, что это архивный запрос — не засоряем URL чужими флагами.
        if let sourceRaw = channel.catchupSource?.trimmingCharacters(in: .whitespacesAndNewlines),
           !sourceRaw.isEmpty {

            let resolved = sourceRaw
                .replacingOccurrences(of: "${start}", with: "\(startTimestamp)")
                .replacingOccurrences(of: "${timestamp}", with: "\(startTimestamp)")
                .replacingOccurrences(of: "${end}", with: "\(stopTimestamp)")
                .replacingOccurrences(of: "${stop}", with: "\(stopTimestamp)")
                .replacingOccurrences(of: "${duration}", with: "\(duration)")
                .replacingOccurrences(of: "${offset}", with: "\(offset)")
                .replacingOccurrences(of: "${utc}", with: "\(startTimestamp)")
                .replacingOccurrences(of: "${now}", with: "\(nowTimestamp)")

            let ctype = (channel.catchupType ?? "").lowercased()

            if ctype == "append" {
                var query = resolved
                if query.hasPrefix("?") || query.hasPrefix("&") { query.removeFirst() }
                let sep = base.contains("?") ? "&" : "?"
                let urlString = base + sep + query
                // Только очищаем live-параметры, НЕ добавляем archive/dvr/timeshift
                return cleanLiveParams(from: urlString)
            }

            // Для кастомного catchup-source: только чистим live-параметры
            return cleanLiveParams(from: resolved)
        }

        // Fallback: стандартное построение URL с timeshift-параметрами
        var urlString = base
        let sep = urlString.contains("?") ? "&" : "?"
        urlString += "\(sep)utc=\(startTimestamp)&lutc=\(startTimestamp)&duration=\(duration)&timeshift=1"
        return sanitizeArchiveURL(urlString)
    }

    /// Убирает только live-специфичные параметры, не добавляя ничего лишнего.
    /// Используется для кастомных catchup-source URL.
    private static func cleanLiveParams(from raw: String) -> URL? {
        guard var comps = URLComponents(string: raw) else {
            return URL(string: raw)
        }
        var items = comps.queryItems ?? []
        let banned = Set(["live", "from_live", "start_live"])
        items.removeAll { banned.contains($0.name.lowercased()) }
        comps.queryItems = items.isEmpty ? nil : items
        return comps.url
    }

    /// Для fallback URL: добавляет archive-флаги и убирает live-параметры.
    private static func sanitizeArchiveURL(_ raw: String) -> URL? {
        guard var comps = URLComponents(string: raw) else {
            return URL(string: raw)
        }

        var items = comps.queryItems ?? []

        func upsert(_ key: String, _ value: String) {
            if let i = items.firstIndex(where: { $0.name.caseInsensitiveCompare(key) == .orderedSame }) {
                items[i].value = value
            } else {
                items.append(URLQueryItem(name: key, value: value))
            }
        }

        upsert("archive", "1")
        upsert("timeshift", "1")
        upsert("dvr", "1")

        let banned = Set(["live", "from_live", "start_live", "edge"])
        items.removeAll { banned.contains($0.name.lowercased()) }

        comps.queryItems = items.isEmpty ? nil : items
        return comps.url
    }
}
