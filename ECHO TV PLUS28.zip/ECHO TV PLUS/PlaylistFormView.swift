import SwiftUI

/// Единая форма для добавления и редактирования плейлиста.
/// Заменяет дублированные AddPlaylistSheet + EditPlaylistSheet.
struct PlaylistFormView: View {

    // MARK: – Mode

    enum Mode {
        case add
        case edit(Playlist)

        var title: String {
            let lm = LanguageManager.shared
            switch self {
            case .add:  return lm.strings.addFormTitle
            case .edit: return lm.strings.editFormTitle
            }
        }
    }

    // MARK: – Props

    let mode: Mode
    @ObservedObject var playlistManager: PlaylistManager
    @ObservedObject private var lm = LanguageManager.shared
    @Environment(\.dismiss) private var dismiss

    // MARK: – State

    @State private var name: String
    @State private var m3uURL: String
    @State private var epgURL: String

    @State private var inputMode: Int = 0
    @State private var xtreamServer: String   = ""
    @State private var xtreamUsername: String = ""
    @State private var xtreamPassword: String = ""

    enum Field: Hashable { case name, m3u, epg, server, username, password }
    @FocusState private var focusedField: Field?

    private static let headerFontSize: CGFloat = 40
    private static let windowWidth: CGFloat = 1000

    // MARK: – Init

    init(mode: Mode, playlistManager: PlaylistManager) {
        self.mode = mode
        self.playlistManager = playlistManager

        switch mode {
        case .add:
            _name    = State(initialValue: "")
            _m3uURL  = State(initialValue: "")
            _epgURL  = State(initialValue: "")
        case .edit(let playlist):
            _name    = State(initialValue: playlist.name)
            _m3uURL  = State(initialValue: playlist.m3uURL)
            _epgURL  = State(initialValue: playlist.epgURL ?? "")
        }
    }

    // MARK: – Computed helpers

    private var saveDisabled: Bool {
        inputMode == 0
            ? m3uURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            : xtreamServer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
              || xtreamUsername.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    // MARK: – Body

    var body: some View {
        ZStack {
            VStack(spacing: 0) {

                // ── Header ──────────────────────────────────────────
                Text(mode.title)
                    .font(.system(size: Self.headerFontSize, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 50)
                    .padding(.bottom, 20)

                // ── Mode picker ─────────────────────────────────────
                Picker("", selection: $inputMode) {
                    Text("M3U Link").tag(0)
                    Text("Xtream Codes").tag(1)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 60)
                .padding(.bottom, 30)

                // ── Fields ───────────────────────────────────────────
                VStack(spacing: 30) {
                    LabeledInputBlock(
                        label: lm.strings.labelName,
                        placeholder: lm.strings.placeholderName,
                        text: $name,
                        isActive: focusedField == .name
                    )
                    .focused($focusedField, equals: .name)

                    if inputMode == 0 {
                        LabeledInputBlock(
                            label: lm.strings.labelM3U,
                            placeholder: lm.strings.placeholderM3U,
                            text: $m3uURL,
                            isActive: focusedField == .m3u
                        )
                        .focused($focusedField, equals: .m3u)

                        LabeledInputBlock(
                            label: lm.strings.labelEPG,
                            placeholder: lm.strings.placeholderEPG,
                            text: $epgURL,
                            isActive: focusedField == .epg
                        )
                        .focused($focusedField, equals: .epg)
                    } else {
                        LabeledInputBlock(
                            label: "Server URL",
                            placeholder: "http://domain.com:8080",
                            text: $xtreamServer,
                            isActive: focusedField == .server
                        )
                        .focused($focusedField, equals: .server)

                        LabeledInputBlock(
                            label: "Username",
                            placeholder: "Login",
                            text: $xtreamUsername,
                            isActive: focusedField == .username
                        )
                        .focused($focusedField, equals: .username)

                        LabeledInputBlock(
                            label: "Password",
                            placeholder: "Password",
                            text: $xtreamPassword,
                            isActive: focusedField == .password
                        )
                        .focused($focusedField, equals: .password)
                    }
                }
                .padding(.horizontal, 60)
                .padding(.bottom, 50)

                // ── Buttons ─────────────────────────────────────────
                HStack(spacing: 40) {
                    Button(action: handleSave) {
                        Text(lm.strings.save).padding(.horizontal, 20)
                    }
                    .disabled(saveDisabled)

                    Button(action: { dismiss() }) {
                        Text(lm.strings.cancel).padding(.horizontal, 20)
                    }
                }
                .padding(.horizontal, 60)
                .padding(.bottom, 50)
            }
            .frame(width: Self.windowWidth)
            .background(.ultraThinMaterial)
            .cornerRadius(16)
        }
    }

    // MARK: – Actions

    private func handleSave() {
        var finalM3U = m3uURL.trimmingCharacters(in: .whitespacesAndNewlines)
        var finalEPG = epgURL.trimmingCharacters(in: .whitespacesAndNewlines)

        if inputMode == 1 {
            var host = xtreamServer.trimmingCharacters(in: .whitespacesAndNewlines)
            if !host.hasPrefix("http") { host = "http://\(host)" }
            if host.hasSuffix("/")     { host = String(host.dropLast()) }

            let user = xtreamUsername.trimmingCharacters(in: .whitespacesAndNewlines)
            let pass = xtreamPassword.trimmingCharacters(in: .whitespacesAndNewlines)
            // Percent-encode credentials so special chars don't break the URL
            let userEnc = user.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? user
            let passEnc = pass.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? pass

            finalM3U = "\(host)/get.php?username=\(userEnc)&password=\(passEnc)&type=m3u_plus"
            finalEPG = "\(host)/xmltv.php?username=\(userEnc)&password=\(passEnc)"
        }

        switch mode {
        case .add:
            playlistManager.addPlaylist(
                name: name.isEmpty ? "New Playlist" : name,
                m3uURL: finalM3U,
                epgURL: finalEPG.isEmpty ? nil : finalEPG
            )

        case .edit(let playlist):
            playlistManager.updatePlaylist(
                playlist: playlist,
                newName: name,
                newM3U: finalM3U,
                newEPG: finalEPG
            )
        }

        dismiss()
    }
}
