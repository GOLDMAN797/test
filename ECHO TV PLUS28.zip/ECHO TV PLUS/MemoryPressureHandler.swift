import UIKit
import Combine

@MainActor
final class MemoryPressureHandler: ObservableObject {
    static let shared = MemoryPressureHandler()

    private var cancellables = Set<AnyCancellable>()

    private init() {
        setupObserver()
    }

    private func setupObserver() {
        NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)
            .sink { _ in
                Task { @MainActor in
                    URLCache.shared.removeAllCachedResponses()
                    await ImageLoader.shared.clearCache()
                }
            }
            .store(in: &cancellables)
    }
}
