import Foundation
import zlib

extension Data {
    nonisolated func maybeGunzip() -> Data {
        guard count >= 2 else { return self }
        let b0 = self[startIndex]
        let b1 = self[index(after: startIndex)]
        guard b0 == 0x1F, b1 == 0x8B else { return self }
        return (try? gunzipped()) ?? self
    }

    nonisolated func gunzipped() throws -> Data {
        if isEmpty { return Data() }

        var stream = z_stream()
        stream.zalloc = nil
        stream.zfree = nil
        stream.opaque = nil

        let windowBits: Int32 = 47
        let streamSize = Int32(MemoryLayout<z_stream>.size)
        let initResult = inflateInit2_(&stream, windowBits, ZLIB_VERSION, streamSize)
        guard initResult == Z_OK else {
            throw NSError(domain: "Gzip", code: Int(initResult))
        }
        defer { inflateEnd(&stream) }

        var output = Data()
        let chunkSize = 64 * 1024
        output.reserveCapacity(Swift.min(count * 2, 4 * 1024 * 1024))

        return try withUnsafeBytes { (srcRaw: UnsafeRawBufferPointer) -> Data in
            guard let srcBase = srcRaw.bindMemory(to: Bytef.self).baseAddress else {
                throw NSError(domain: "Gzip", code: -1)
            }

            stream.next_in = UnsafeMutablePointer<Bytef>(mutating: srcBase)
            stream.avail_in = UInt32(count)

            let outBuffer = UnsafeMutablePointer<UInt8>.allocate(capacity: chunkSize)
            defer { outBuffer.deallocate() }

            while true {
                stream.next_out = outBuffer
                stream.avail_out = UInt32(chunkSize)

                let status = inflate(&stream, Z_NO_FLUSH)

                let produced = chunkSize - Int(stream.avail_out)
                if produced > 0 {
                    output.append(outBuffer, count: produced)
                }

                if status == Z_STREAM_END {
                    return output
                }

                if status != Z_OK {
                    throw NSError(domain: "Gzip", code: Int(status))
                }
            }
        }
    }
}
